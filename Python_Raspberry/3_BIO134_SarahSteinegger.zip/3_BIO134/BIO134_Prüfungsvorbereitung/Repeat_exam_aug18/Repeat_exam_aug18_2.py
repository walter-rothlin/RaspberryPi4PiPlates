# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 19:58:55 2019

@author: sara
"""

# Sara Steinegger
# 20.08.2019

# Repeat exam August 2018



# Question 1
lys = ['g', 't', 's', 'r', 'q', 'c', 's', 'a', 'g']
for element in lys:
    if element != "s":
        print(element)
    else:
        break
    
    

# Question 2
lys = [[5, 2, 3], [2, 4], [5, 9, 3]]
for i in range(len(lys)):
    for j in range(len(lys[i])):
        lys[i][j] += 1
print(lys)



# Question 3
def sum_squares(a):
    s = 0
    for i in range(1,a):
        s += i**2
    return s
print(sum_squares(4))



# Question 4
lys = ['which', 'road', 'leads', 'to', 'Rome']


for i in range(len(lys)):
    s = " ".join(lys[0:len(lys)-i])
    n = len(s)
    print("{0:5d}. {1:.<24s} ?".format(n,s))
    


# Question 5
s = 'Kate, when France is mine and I am yours then yours is France and you are mine'
s = s.split()
d = {}
for i,element in enumerate(s):
    if element not in d.keys():
        d[element] = []
    d[element].append(i)
print(d)



# Question 6
import numpy as np
def reorganize(im):
    x,y = im.shape
    im_new = 1.0*im
    h = int(x/2)
    w = int(y/2)
    im_new[:h,:w] = im[-h:,-w:] # upper left
    im_new[:h,-w:] = im[-h:,:w] # upper right
    im_new[-h:,:w] = im[:h,-w:] # lower left
    im_new[-h:,-w:] = im[:h,:w] # lower right
    #if x%2==0 and y%2==0:
        #im_new[:int(x/2),:int(y/2)] = im[int(x/2):,int(y/2):] # upper left
        #im_new[:int(x/2),int(y/2):] = im[int(x/2):,:int(y/2)] # upper right
        #im_new[int(x/2):,:int(y/2)] = im[:int(x/2),int(y/2):] # lower left
        #im_new[int(x/2):,int(y/2):] = im[:int(x/2),:int(y/2)] # lower right
    #if x%2==1 and y%2==1:
        #print(im[:int(x/2),:int(y/2)])
        #im_new[:int(x/2),:int(y/2)] = im[int(x/2)+1:,int(y/2)+1:] # upper left
        #im_new[:int(x/2),int(y/2)+1:] = im[int(x/2)+1:,:int(y/2)] # upper right
        #im_new[int(x/2)+1:,:int(y/2)] = im[:int(x/2),int(y/2)+1:] # lower left
        #im_new[int(x/2)+1:,int(y/2)+1:] = im[:int(x/2),:int(y/2)] # lower right    
    return im_new

image1 = np.array([[0.2, 0.9, 0.1, 0.6, 0.3, 0.9], \
 [0.3, 0.4, 0.8, 0.2, 0.1, 0.1], [0.7, 0.5, 0.1, 0.3, 0.2, 0.8], \
 [0.2, 0.5, 0.2, 0.1, 0.5, 0.6]])
new_image1 = reorganize(image1)
print('original image 1')
print(image1)
print()
print('new image 1')
print(new_image1)
print()
image2 = np.array([[0.2, 0.3, 0.1, 0.4, 0.6], \
 [0.5, 0.4, 0.7, 0.1, 0.1], [0.8, 0.9, 0.0, 0.4, 0.5]])
new_image2 = reorganize(image2)
print ('original image 2')
print(image2)
print()
print('new image 2')
print(new_image2)

            