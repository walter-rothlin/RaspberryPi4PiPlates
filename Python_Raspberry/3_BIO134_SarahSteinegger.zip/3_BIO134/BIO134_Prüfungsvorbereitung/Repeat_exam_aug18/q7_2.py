# -*- coding: utf-8 -*-

#A new list is made that contains numbers: 100*length + index in the alphabet. In this way,
#only one kind of sorting needs to be performed
#Each subsequent number in the list is moved to the front until the preceeding number is lower
#The original list is changed in the same way as the list with numbers

def special_sort(l):
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    l_numb = []
    for word in l:
        l_numb.append(100*len(word) + alphabet.index(word[0]))
    for i in range(1, len(l_numb)):
        j = i
        while j > 0 and l_numb[j-1] > l_numb[j]:
            #exchange lists at positions j and j-1 (move one to front)
            l_numb_j = l_numb[j]
            l_j = l[j]
            l_numb_jminus1 = l_numb[j-1]
            l_jminus1 = l[j-1]
            l_numb[j] = l_numb_jminus1
            l_numb[j-1] = l_numb_j
            l[j] = l_jminus1
            l[j-1] = l_j
            
            j = j-1
    #printing
    for word in l:
        print(word)
l = ['cows', 'are', 'eating', 'brown', 'grass', 'in', 'the', 'sun']

special_sort(l)