# -*- coding: utf-8 -*-


l = ['g', 't', 's', 'r', 'q', 'c','s', 'a', 'g']
found_s=0
for char in l:
    if char=='s':
        found_s=1;
    if found_s==0:
        print(char)