# -*- coding: utf-8 -*-

import numpy as np

def reorganize(a):

    b=1*a
    hhalf = int(0.5*a.shape[0])
    whalf = int(0.5*a.shape[1])
    b[:hhalf,:whalf] = a[-hhalf:,-whalf:]
    b[-hhalf:,-whalf:] = a[:hhalf,:whalf]
    b[-hhalf:,:whalf] = a[:hhalf,-whalf:]
    b[:hhalf,-whalf:] = a[-hhalf:,:whalf]
    return b
 
image1 = np.array([[0.2, 0.9, 0.1, 0.6, 0.3, 0.9], \
     [0.3, 0.4, 0.8, 0.2, 0.1, 0.1], [0.7, 0.5, 0.1, 0.3, 0.2, 0.8], \
     [0.2, 0.5, 0.2, 0.1, 0.5, 0.6]])
new_image1 = reorganize(image1)
print('original image 1')
print(image1)
print()
print('new image 1')
print(new_image1)
print()

image2 = np.array([[0.2, 0.3, 0.1, 0.4, 0.6], \
     [0.5, 0.4, 0.7, 0.1, 0.1], [0.8, 0.9, 0.0, 0.4, 0.5]])
new_image2 = reorganize(image2)
print ('original image 2')
print(image2)
print()
print('new image 2')
print(new_image2)