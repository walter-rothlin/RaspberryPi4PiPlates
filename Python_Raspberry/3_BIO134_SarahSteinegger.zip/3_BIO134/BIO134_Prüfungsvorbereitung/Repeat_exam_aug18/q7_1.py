# -*- coding: utf-8 -*-

#sort first by length and then alphabetically by a nested loop
def special_sort(l):
    max_len = 0
    for word in l:
        if len(word)>max_len:
            max_len = len(word)
    alphabet= 'abcdefghijklmnopqrstuvwxyz'
    for length in range (max_len+1):
        for letter in alphabet:
            for word in l:
                if len(word) == length and word[0] == letter:
                    print(word)
l = ['cows', 'are', 'eating', 'brown', 'grass', 'in', 'the', 'sun']
special_sort(l)