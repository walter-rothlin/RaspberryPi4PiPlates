# -*- coding: utf-8 -*-

l = ['which', 'road', 'leads', 'to', 'Rome']

for i in range(len(l)):
    if i == 0:
        line = ' '.join(l)
        line_with_points = line
        longest = len(line)
    else:
        line = ' '.join(l[:-i])
        line_with_points = line + ' ' + (longest - len(line)- 1)*'.'
    print('{:5d}. '.format(len(line))+ line_with_points, '?')