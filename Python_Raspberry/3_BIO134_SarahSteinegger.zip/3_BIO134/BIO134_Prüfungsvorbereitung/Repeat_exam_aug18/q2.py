# -*- coding: utf-8 -*-
import copy

lys = [[5, 2, 3], [2, 4], [5, 9, 3]]
lys_new = copy.deepcopy(lys)
for i in range(len(lys)):
    sublist = lys[i]
    for j in range(len(sublist)):
        lys_new[i][j] = lys[i][j]+1
print(lys_new)