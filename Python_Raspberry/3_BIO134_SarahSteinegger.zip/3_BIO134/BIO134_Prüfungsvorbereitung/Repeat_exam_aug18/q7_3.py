# -*- coding: utf-8 -*-

#find the word that should be first, remove it from the list and print it, repeat this len(l) times
def special_sort3(l):

    alpha='abcdefghijklmnopqrstuvwxyz'
    max_len = 0
    for word in l:
        if len(word)>max_len:
            max_len = len(word)
    len_ori = len(l)
    for i in range(len_ori):
        #find the length of the shortest word
        shortest = max_len
        for word in l:
            if len(word)<shortest:
                shortest = len(word)
        #compare the shortest words
        start_letter = 'z'
        for word in l:
            if len(word) == shortest and alpha.index(word[0]) <= alpha.index(start_letter):
                start_letter = word[0]
                first_word = word
        l.remove(first_word)
        print(first_word)
            
l = ['cows', 'are', 'eating', 'brown', 'grass', 'in', 'the', 'sun']
special_sort3(l)