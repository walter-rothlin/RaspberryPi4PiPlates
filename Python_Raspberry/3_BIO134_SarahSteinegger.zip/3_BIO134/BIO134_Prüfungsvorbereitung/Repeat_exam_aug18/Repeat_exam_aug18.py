# -*- coding: utf-8 -*-
"""
Created on Sat Aug 10 19:21:03 2019

@author: sara
"""

# Sara Steinegger
# 10.08.2019

# Repeat exam August 2018



# Question 1
lys = ['g', 't', 's', 'r', 'q', 'c', 's', 'a', 'g']

for i in range(len(lys)):
    if lys[i] != "s":
        print(lys[i])
    else:
        break



# Question 2      
lys = [[5, 2, 3], [2, 4], [5, 9, 3]]
for i,el in enumerate(lys):
    for j in range(len(el)):
        lys[i][j] += 1
print(lys)

lys = [[5, 2, 3], [2, 4], [5, 9, 3]]
lys_new = lys[:]
for i,element in enumerate(lys):
    for j in range(len(element)):
        lys_new[i][j] = lys[i][j]+1
print(lys_new)



# Question 3
def sum_squares(n):
    s = 0
    for i in range(n):
        s += i**2
    return s
print(sum_squares(4))
        


# Question 4
lys = ['which', 'road', 'leads', 'to', 'Rome']

for i in range(len(lys), 0, -1):
    s = ""
    lys_new = lys[:i]
    for word in lys_new:
        s = s + " " + word
    l = len(s) - 1
    p = 25 - len(s) - 1
    print("{:4d}.".format(l) + s + " "+ p*"." + " ?")



# Question 5
s = "Kate, when France is mine and I am yours then yours is France and you are mine"
s_new = s.split()
d = {}

for i in range(len(s_new)):
    if s_new[i] not in d:
        d[s_new[i]] = []
    d[s_new[i]].append(i)
print(d)



# Question 6

# Question 7
def special_sort(lys):
    m = 0
    for word in lys:
        if len(word) > m:
            m = len(word)
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    for i in range(m+1):
        for letter in alphabet:
            for word in lys:
                if len(word)==i and word[0]==letter:
                    print(word)
    
l = ['cows', 'are', 'eating', 'brown', 'grass', 'in', 'the', 'sun']
special_sort(l)




