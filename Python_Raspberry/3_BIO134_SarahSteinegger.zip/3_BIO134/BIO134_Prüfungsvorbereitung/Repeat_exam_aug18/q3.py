# -*- coding: utf-8 -*-

def sum_squares(n):
    summe = 0
    for i in range(n):
        summe += i**2
    return summe
print(sum_squares(4))