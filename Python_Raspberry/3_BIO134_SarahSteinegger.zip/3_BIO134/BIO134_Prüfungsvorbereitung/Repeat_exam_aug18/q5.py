# -*- coding: utf-8 -*-

s = 'Kate, when France is mine and I am yours then yours is France and you are mine'
l = s.split()
d = {}
for i, word in enumerate(l):
    if not word in d:
        d[word] = []
    d[word].append(i)
print(d)