#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 15:26:32 2017

@author: sekiss
"""

#Generate an array y that could be used to plot x2. x should range from 0 to 5 
#and should contain 20 equally spaced numbers. 

import numpy as np
import matplotlib.pyplot as plt

x=np.linspace(0,5,20)
y=x**2

plt.plot(x,y,marker='o')
plt.xlabel('x-values')
plt.ylabel('y-values')
plt.title('X Squared')
plt.show()
