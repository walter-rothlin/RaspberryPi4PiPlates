# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 16:09:23 2019

@author: sara
"""

import numpy as np
im = np.array(
[[[0.7, 0.4, 0.2], [0.5, 0.8, 0.8], [0.1, 0.9, 0.2], [0.3, 0.4, 0.5]],
[[0.7, 0.3, 0.2], [0.4, 0.4, 0.8], [0.1, 0.8, 0.3], [0.9, 0.9, 0.3]]])
threshold = np.array([0.5, 0.4, 0.8])

im_new = np.zeros(shape=(im.shape[0],im.shape[1],im.shape[2]), dtype=float)

for x in range(im.shape[0]):
    for y in range(im.shape[1]):
        for n in range(len(im[x,y])):
            print(n)
            if im[x,y,n] >= threshold[n]:
                im_new[x,y,n] = 1.0
            else:
                im_new[x,y,n] = 0.0
print(im_new)