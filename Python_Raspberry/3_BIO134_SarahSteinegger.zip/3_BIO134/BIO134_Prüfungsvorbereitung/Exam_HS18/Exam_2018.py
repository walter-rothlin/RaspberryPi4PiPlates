# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 14:39:23 2019

@author: sara
"""
# Sara Steinegger
# 19.08.2019

# Exam 2018



# Question 1
s = 'AATGAGCCGTA'
l = []
for i in range(len(s)):
    if len(s[i:i+6]) == 6:
        l.append(s[i:i+6])
print(l)

# solution
l = []
s = 'AATGAGCCGTA'
for i in range(len(s)-6+1):
    l.append(s[i:i+6])
print(l)


# Question 2
en_de = {'it': 'es', 'they': 'sie', 'and': 'und', 'is': 'ist',
 'was': 'war', 'snows': 'schneit', 'cold': 'kalt'}
en = ['it', 'snows', 'and', 'it', 'is', 'cold']
s = ""
for word in en:
    if word in en_de.keys():
        s += en_de[word] + " "
print(s)

# solution
en_de = {'it': 'es', 'they': 'sie', 'and': 'und', 'is': 'ist',
         'was': 'war', 'snows': 'schneit', 'cold': 'kalt'} 
en = ['it', 'snows', 'and', 'it', 'is', 'cold']
sentence = ''
for word in en:
    sentence += en_de[word] + ' '
print(sentence)



# Question 3
def compare(n):
    s = 0
    for i in range(1, n+1):
        s += i**3
    t = 2**n
    if t>s:
        return False
    else:
        return True

for num in [1, 2, 3, 12, 13, 14, 15]:
    if compare(num):
        print(1, end=",")
    else:
        print(0, end=",")
print()

# solution
def compare(n):
    s=0
    for i in range(1,n+1):
        s+=i**3
    t=2**n
    return s>t
for num in [1, 2, 3, 12, 13, 14, 15]:
    if compare(num):
        print(1, end=",")
    else:
        print(0, end=",")


# Question 4
numbers = open("numbers.csv", "r")
num = numbers.readlines()
numbers.close()

for i in range(len(num)):
    n = 0
    num[i] = num[i].strip().split(",")
    for j in range(len(num[i])):
        if int(num[i][j])%2==0:
            n += int(num[i][j])
    print(n)

# solution
fyle = open('numbers.csv')
l = fyle.readlines()
for line in l:
    lline = line.strip().split(',')
    summe = 0
    for num in lline:
        if int(num)%2 == 0:
            summe += int(num)
    print(summe)
fyle.close()


# Question 5
import numpy as np
im = np.array(
[[[0.7, 0.4, 0.2], [0.5, 0.8, 0.8], [0.1, 0.9, 0.2], [0.3, 0.4, 0.5]],
[[0.7, 0.3, 0.2], [0.4, 0.4, 0.8], [0.1, 0.8, 0.3], [0.9, 0.9, 0.3]]])
threshold = np.array([0.5, 0.4, 0.8])

im_new = np.zeros(shape=(im.shape[0],im.shape[1],im.shape[2]), dtype=float)

for x in range(im.shape[0]):
    for y in range(im.shape[1]):
        for n in range(len(im[x,y])):
            print(n)
            if im[x,y,n] >= threshold[n]:
                im_new[x,y,n] = 1.0
            else:
                im_new[x,y,n] = 0.0
print(im_new)



# Question 6
import numpy as np

virus = np.array([3.32, 6.00, 5.23, 0.00, 0.00, 0.92, 2.08, 9.36, 9.96,
11.76, 2.92, 8.44, 1.04, 3.12, 11.40, 6.60, 3.92, 0.92, 1.76, 7.64, 8.84,
11.68, 0.44, 11.92, 1.38, 6.84, 9.68, 4.08, 3.12, 4.00])

yfg = np.array([5.6, 6.3, 4.8, 7.4, 6.9, 9.9, 8.2, 2.4, 1.9, 1.2, 7.3,
2.4, 6.2, 5.2, 0.1, 4.5, 5.0, 8.6, 9.7, 2.6, 4.2, 0.8, 8.5, 8.9, 2.4,
6.0, 3.2, 8.7, 6.8, 5.1])

max_interval = 12

count_list = []
mean_list = []
for i in range(0, max_interval, 2):
    count = 0
    number = 0
    for j, element in enumerate(virus):
        if i<=element and element<i+2:
            count += 1
            number += yfg[j]
    mean = number/count
    count_list.append(count)
    mean_list.append(mean)
counts = np.array(count_list)
means = np.array(mean_list)

print("counts:", count_list)
print("means:", mean_list)
    
            
            
# Question 7
vertices_of_polygons = [[0, 1, 2, 6, 5], [2, 3, 4, 8, 7, 6], [5, 6, 7, 14, 13, 12], [7, 8, 9, 17, 16, 15, 14],
                        [9, 10, 11, 18, 17], [13, 14, 15, 20, 19]]

def neighbors(l):
    direct_neigh = []
    direct_neigh_num = []
    sec_neigh = []
    sec_neigh_num = []
    for i in range(len(l)):
        direct_neigh.append([])
        num1 = 0
        for vertex in l[i]:
            for j in range(len(l)):
                if i!=j and vertex in l[j] and j not in direct_neigh[i]:
                    direct_neigh[i].append(j)
                    num1 += 1
        direct_neigh_num.append(num1)
    for i in range(len(direct_neigh)):
        sec_neigh.append([])
        num2 = 0
        for neigh in direct_neigh[i]:
            for j in range(len(direct_neigh)):
                if i!=j and i not in direct_neigh[j] and neigh in direct_neigh[j] and j not in sec_neigh[i]:
                    sec_neigh[i].append(j)
                    num2 += 1
        sec_neigh_num.append(num2)
    return direct_neigh_num, sec_neigh_num
        
first_neigh, second_neigh = neighbors(vertices_of_polygons)
print(first_neigh)
print(second_neigh)


        