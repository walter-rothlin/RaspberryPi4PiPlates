# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 20:02:50 2019

@author: sara
"""

vertices_of_polygons = [[0, 1, 2, 6, 5], [2, 3, 4, 8, 7, 6], [5, 6, 7, 14, 13, 12], [7, 8, 9, 17, 16, 15, 14],
                        [9, 10, 11, 18, 17], [13, 14, 15, 20, 19]]

def neighbors(l):
    direct_neigh = []
    direct_neigh_num = []
    sec_neigh = []
    sec_neigh_num = []
    for i in range(len(l)):
        direct_neigh.append([])
        num1 = 0
        for vertex in l[i]:
            for j in range(len(l)):
                if i!=j and vertex in l[j] and j not in direct_neigh[i]:
                    direct_neigh[i].append(j)
                    num1 += 1
        direct_neigh_num.append(num1)
    for i in range(len(direct_neigh)):
        sec_neigh.append([])
        num2 = 0
        for neigh in direct_neigh[i]:
            for j in range(len(direct_neigh)):
                if i!=j and i not in direct_neigh[j] and neigh in direct_neigh[j] and j not in sec_neigh[i]:
                    sec_neigh[i].append(j)
                    num2 += 1
        sec_neigh_num.append(num2)
    return direct_neigh_num, sec_neigh_num
        
first_neigh, second_neigh = neighbors(vertices_of_polygons)
print(first_neigh)
print(second_neigh)       
  