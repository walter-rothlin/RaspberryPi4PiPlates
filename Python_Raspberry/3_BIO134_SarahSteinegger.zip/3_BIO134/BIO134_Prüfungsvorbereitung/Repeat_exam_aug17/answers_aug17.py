# -*- coding: utf-8 -*-
"""
Created on Tue Aug 15 16:52:51 2017; modified on Fri Jan 18 2019
 

"""
#1
s1 = 'Love looks not with the'
s2 = 'eyes, but with the mind'

l = []
for i in range(len(s1)):
    l.append(s1[i]+s2[i])
print(l)

#2
names = [['Schmidt', 'Julia'], ['Stierli', 'Paul'], ['Meier', 'Emma']]
names2 = []
for l in names:
    names2.append([l[1],l[0]])
print(names2)

#3
def add_square_roots(n1,n2):
    return n1**0.5+n2**0.5

n1 = add_square_roots(4.0, 9.0)
print(n1)

#4
languages = ['French', 'Swedish', 'Spanish', 'Greek', 'Italian']
for i in range(len(languages)):
    for j in range(i+1,len(languages)):
        print(languages[i], languages[j])
        
#5
s = '55 6, 60 7, 43 2, 610 44'
l = s.split(',')
for t in l:
    lt = t.split()
    n1 = float(lt[0])
    n2 = float(lt[1])
    n3 = n1 / n2
    s1 = '{:5.2f}'.format(n3)
    s1 += ' is '
    s1 += '{:3.0f}'.format(n1)
    s1 += ' divided by '
    s1 += '{:2.0f}'.format(n2)
    print(s1)

#6
l1 = [5, 7, 6, 9]
l2 = l1
for i in range(len(l1)):
    l2[i] = l1[i] + l1[i-1]
print(l2) 

#7
person = {}

person['darwin'] = ['Charles Darwin',
                    '12 February 1809','19 April 1882']
person['shakespeare'] = ['William Shakespeare',
                    '26 April 1564','23 April 1616']
person['cervantes'] = ['Miguel de Cervantes',
                    '29 September 1547','23 April 1616']
person['lincoln'] = ['Abraham Lincoln',
                    '12 February 1809','15 April 1865']
for shortname in person:
    year1 = int(person[shortname][1][-4:])
    year2 = int(person[shortname][2][-4:])
    age = year2 - year1
    person[shortname].append(age)
print(person)
    

#8        
import numpy as np
a = np.array([[3, 5, 8, 3],[4, 3, 1, 7],[4, 5, 2, 6]])
b = 0 * a
l1, l2 = a.shape
for i in range(1,l1):
    for j in range(l2-1):
        b[i,j] = a[i,j] + a[i-1,j+1]
print(b)

import numpy as np
a = np.array([[3, 5, 8, 3],[4, 3, 1, 7],[4, 5, 2, 6]])
b = 0 * a
l1, l2 = a.shape
b[1:l1,:l2-1] = a[1:l1,:l2-1] + a[:l1-1,1:l2]
print(b)

#9
import numpy.random as rd
rd.seed(2)

targ = [6, 6, 3, 3]
l = [0, 0, 0, 0]
counter = 0
while True:
    lnew = l[1:]
    dice = rd.randint(1,7)
    counter += 1
    lnew.append(dice)
    if targ == lnew:
        break
    l = lnew[:]
print(counter)   

#10
def bifurcation_ratios(lys1, Lys2):
    #create dictionary d with ray names as keys and lists of len 3 with sublists of len 3 values.
    #the first sublist contains bifurcation distances before regeneration,
    #the second one after bifurcation and the third one ratios
    #the positions within the sublists correspond to the different fish
    d={}
    for dataray in lys1:
        ray = dataray[1]
        if ray not in d:
            d[ray]=[[0, 0, 0],[0, 0, 0], [0, 0, 0]]
        for i in range(1,4):
            if dataray[0] == i:
                d[ray][0][i-1] = dataray[2]
    for dataray in lys2:
        ray = dataray[1]
        if ray not in d:
            d[ray]=[[0, 0, 0],[0, 0, 0], [0, 0, 0]]
        for i in range(1,4):
            if dataray[0] == i:
                d[ray][1][i-1] = dataray[2]
    
    for ray in d:
        for i in range(3):
            if d[ray][0][i] == 0 and d[ray][1][i] == 0:
                pass
            elif d[ray][0][i] == 0 or d[ray][1][i] == 0:
                d[ray][2][i] = 'NaN'
            else:
                d[ray][2][i] = d[ray][1][i] / d[ray][0][i]
    
    #calculate mean ratios based on d and put them in lys
    lys = []
    for ray in d:
        lys.append([ray])
        if 'NaN' in d[ray][2]:
            lys[-1].append('NaN')
        else:
            tot = 0
            no = 0
            for i in range(3):
                if d[ray][2][i] != 0:
                    tot += d[ray][2][i]
                    no += 1
            lys[-1].append(tot/no)
    lys.sort()      
    return(lys)
    
lys1 = [[1, 'D2', 3.5525], [1, 'D3', 3.7016], [1, 'D4', 5.6241], [1, 'D5', 3.9636], [1, 'D6', 3.6448], [1, 'D7', 3.5776], [1, 'V8', 3.8904], [1, 'V7', 3.8579], [1, 'V6', 4.1142], [1, 'V5', 4.0014], [1, 'V4', 5.3375], [1, 'V3', 4.126], [1, 'V2', 3.5633], [2, 'D2', 3.5639], [2, 'D3', 3.6946], [2, 'D4', 3.5901], [2, 'D5', 3.4061], [2, 'D6', 3.3662], [2, 'D7', 3.3619], [2, 'D8', 3.4112], [2, 'D9', 3.6437], [2, 'V9', 3.5355], [2, 'V8', 3.1529], [2, 'V7', 3.5689], [2, 'V6', 3.488], [2, 'V5', 3.8447], [2, 'V4', 4.0731], [2, 'V3', 4.0097], [2, 'V2', 3.5181], [3, 'D2', 3.84], [3, 'D3', 4.2358], [3, 'D4', 4.027], [3, 'D5', 3.9698], [3, 'D6', 3.7234], [3, 'D7', 3.5911], [3, 'D8', 3.5991], [3, 'D9', 3.7752], [3, 'V9', 3.3995], [3, 'V8', 3.429], [3, 'V7', 3.8568], [3, 'V6', 3.7654], [3, 'V5', 4.0664], [3, 'V4', 4.0378], [3, 'V3', 4.0286], [3, 'V2', 3.9492]]
lys2 = [[1, 'D2', 4.4375], [1, 'D3', 4.1676], [1, 'D4', 4.2237], [1, 'D5', 3.7863], [1, 'D6', 3.6265], [1, 'D7', 3.5433], [1, 'D8', 3.6279], [1, 'V8', 3.5871], [1, 'V7', 3.8158], [1, 'V6', 4.1076], [1, 'V5', 4.2004], [1, 'V4', 4.2792], [1, 'V3', 4.2636], [1, 'V2', 4.2517], [2, 'D2', 4.5185], [2, 'D3', 5.0606], [2, 'D4', 5.2833], [2, 'D5', 5.0305], [2, 'D6', 4.7521], [2, 'D7', 4.5696], [2, 'D8', 4.2063], [2, 'D9', 4.1246], [2, 'V9', 4.1527], [2, 'V8', 4.2942], [2, 'V7', 4.6699], [2, 'V6', 4.8957], [2, 'V5', 5.0001], [2, 'V4', 5.2639], [2, 'V3', 4.8537], [2, 'V2', 4.3889], [3, 'D2', 4.2284], [3, 'D3', 4.1006], [3, 'D4', 4.7386], [3, 'D5', 4.6474], [3, 'D6', 4.3407], [3, 'D7', 4.166], [3, 'D8', 4.1185], [3, 'D9', 5.0535], [3, 'V9', 4.3097], [3, 'V8', 4.1629], [3, 'V7', 4.5007], [3, 'V6', 4.7947], [3, 'V5', 4.7266], [3, 'V4', 4.7662], [3, 'V3', 4.5578], [3, 'V2', 4.1635]]
                
print(bifurcation_ratios(lys1, lys2))       

##alternative without dictionaries (here without function to prevent confusion with function names)
#
##create list with all different ray names
#rays = []
#for dataray in lys1:
#    if dataray[1] not in rays:
#        rays.append(dataray[1])
#for dataray in lys2:
#    if dataray[1] not in rays:
#        rays.append(dataray[1])
#
##for each ray:
##check in which of the fish it is present before and after bifurcation
##check each combination of sublists in lys1 and lys that contain the ray; 
##      calculate ratios if fish numbers are the same (add them up)
##calculate the average ratio in case the ray is present in the same combination of fish before and after bifurcation
#lys = []
#for ray in rays:
#    rattot = 0
#    no = 0
#    found1 = [0, 0, 0] #indicates per fish whether ray is present in lys1
#    found2 = [0, 0, 0] ##indicates per fish whether ray is present in lys2
#    for data1ray in lys1:
#        if data1ray[1] == ray:
#            found1[data1ray[0]-1] = 1
#        for data2ray in lys2:
#            if data2ray[1] == ray:
#                found2[data2ray[0]-1] = 1
#            if data1ray[0] == data2ray[0] and data1ray[1] == ray and data2ray[1] == ray:
#                rattot += data2ray[2] / data1ray[2]
#                no += 1
#    if found1 == found2:
#        lys.append([ray,rattot/no])
#    else:
#        lys.append([ray,'NaN'])
#lys.sort()
#print(lys) 
         
    
            
            
