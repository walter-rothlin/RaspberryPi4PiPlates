# -*- coding: utf-8 -*-
"""
Created on Thu Aug  8 20:58:38 2019

@author: sara
"""

# Sara Steinegger
# 08.08.2019

# Repeat exam BIO134 2017: Programming in Biology



# Question 1
s1 = "Love looks not with the"
s2 = "eyes, but with the mind"

lys = []

for i in range(len(s1)):
    lys.append(s1[i]+s2[i])
print(lys)



# Question 2
names = [['Schmidt', 'Julia'], ['Stierli', 'Paul'], ['Meier', 'Emma']]
names_new = []

for i in range(len(names)):
    names_new.append([names[i][1], names[i][0]])
print(names_new)



# Question 3
def add_square_roots(a,b):
    asr = (a**0.5) + (b**0.5)
    return asr
n1 = add_square_roots(4.0, 9.0)
print(n1)



# Question 4
languages = ['French', 'Swedish', 'Spanish', 'Greek', 'Italian']
languages_new = []
#counter = 0

for i in range(len(languages)):
    for j in range(i+1,len(languages)):
        languages_new.append([languages[i], languages[j]])
        #counter += 1
print(languages_new) 
#print(counter)



# Question 5
s = '55 6, 60 7, 43 2, 610 44'
s = s.split(", ")

s_new = []
for element in s:
    s_new.append(element.split())

for i in range(len(s_new)):
    n1 = int(s_new[i][0])
    n2 = int(s_new[i][1])
    d = float(n1/n2)
    print("{0:5.2f} is {1:3d} divided by {2:2d}".format(d,n1,n2))



# Question 6
l1 = [5, 7, 6, 9]
l2 = len(l1)*[0]
for i in range(len(l1)):
 l2[i] = l1[i] + l1[i-1]
print(l2)

# In der zweiten Zeile des Codes wird eine neue Liste (l2) kreiert, 
# welche gleich viele Elemente enthält wie die Liste l1.
# In der vierten Zeile des Codes kann nun auf die einzelnen Listenelemente
# zugegriffen werden (mittels l2[i]), diesem Listenelement wird ein neuer Wert
# zugeordnet mittels dem "assigment operator"
# (der neue Wert wird aus der Liste l1 mittels l1[i] + l1[i-2] berechnet).

# Der alte Code hat keine solche neue Liste l2 kreiert, sondern die Liste l1
# den namen/die variabel l2 zugeordnet (Eine Liste hat nun zwei Namen -> l1 und l2,
# wenn in l2 etwas geändert wird, wird in l1 ebenfalls etwas geändert!)



# Question 7
person = {}
person['darwin'] = ['Charles Darwin',
 '12 February 1809','19 April 1882']
person['shakespeare'] = ['William Shakespeare',
 '26 April 1564','23 April 1616']
person['cervantes'] = ['Miguel de Cervantes',
 '29 September 1547','23 April 1616']
person['lincoln'] = ['Abraham Lincoln',
 '12 February 1809','15 April 1865']

for element in person:
    d = int(person[element][2][-4:])
    b = int(person[element][1][-4:])
    age = d - b
    person[element].append(age)
print(person)



# Question 8
import numpy as np
a = np.array([[3, 5, 8, 3],[4, 3, 1, 7],[4, 5, 2, 6]])
b = 0 * a
l1, l2 = a.shape

#b[1:,:-1] = a[b[1:,:-1]] + a[b[-1], b[+1]]

#for i in range(1,l1):
    #for j in range(l2-1):
        #b[i,j] = a[i,j] + a[i-1,j+1]
#print(b)



# Question 9
import numpy.random as rd
rd.seed(2)

aim = [6, 6, 3, 3]
dice = []
counter = 0

while dice[-4:] != aim:
    r = rd.randint(1,7)
    dice.append(r)
    counter += 1
print(dice)
print(counter)

