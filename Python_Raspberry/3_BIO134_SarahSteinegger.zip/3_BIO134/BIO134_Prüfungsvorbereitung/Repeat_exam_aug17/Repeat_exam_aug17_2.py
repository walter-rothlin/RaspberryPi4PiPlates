# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 14:59:35 2019

@author: sara
"""

# Sara Steinegger
# 20.08.2019

# Repeat Exam 2017



# Question 1
s1 = 'Love looks not with the'
s2 = 'eyes, but with the mind'
l = [""]*len(s1)
for i in range(len(s1)):
    l[i] = s1[i] + s2[i]
print(l)



#Question 2
names = [['Schmidt', 'Julia'], ['Stierli', 'Paul'], ['Meier', 'Emma']]
names_reverse = []

for sublist in names:
    names_reverse.append([sublist[1], sublist[0]])
print(names_reverse)    



# Question 3
def add_square_roots(a, b):
    return a**0.5 + b**0.5
n1 = add_square_roots(4.0, 9.0)
print(n1)



# Question 4
languages = ['French', 'Swedish', 'Spanish', 'Greek', 'Italian']
combinations = []

for i in range(len(languages)):
    for j in range(i+1, len(languages)):
        print(languages[i], languages[j])



# Question 5
s = '55 6, 60 7, 43 2, 610 44'
l = s.split(",")

for element in l:
    lline = element.split()
    div = int(lline[0])/int(lline[1])
    print("{0:5.2f} is {1:>3s} divided by {2:>2s}".format(div,lline[0],lline[1]))



# Question 6
l1 = [5, 7, 6, 9]
l2 = [0]*len(l1)
for i in range(len(l1)):
    l2[i] = l1[i] + l1[i-1]
print(l2)

# Den Variablen l1 und l2 wurde dieselbe Liste zugewiesen
# ("Beides Namen für dieselbe Liste"). Mit der Schleife, welche eigentlich
# Elemente in l2 verändern sollte, wurden somit auch laufend Elemente
# der l1 verändert.

# Beispiel:
# i = 0
# l2[0] = l1[0] + l1[-1]
# l2[0] = 5 + 9 = 14       --> l1[0] ist jetzt auch 14
# i = 1
# l2[1] = l1[1] + l1[0]    --> l1[0] ist neu 14 und nicht 5
# l2[1] = 7 + 14 = 21      --> Und nicht wie eigentlich vorgesehen 12!!



# Question 7
person = {}
person['darwin'] = ['Charles Darwin', '12 February 1809','19 April 1882']
person['shakespeare'] = ['William Shakespeare', '26 April 1564','23 April 1616']
person['cervantes'] = ['Miguel de Cervantes', '29 September 1547','23 April 1616']
person['lincoln'] = ['Abraham Lincoln', '12 February 1809','15 April 1865']

for i,element in enumerate(person):
    age = int(person[element][2][-4:]) - int(person[element][1][-4:])
    person[element].append(age)
print(person)
 

    
# Question 8
import numpy as np
a = np.array([[3, 5, 8, 3],[4, 3, 1, 7],[4, 5, 2, 6]])
b = 0 * a
l1, l2 = a.shape
for i in range(1,l1):
    for j in range(l2-1):
        b[i,j] = a[i,j] + a[i-1,j+1]
print(b)

import numpy as np
a = np.array([[3, 5, 8, 3],[4, 3, 1, 7],[4, 5, 2, 6]])
b = 0 * a
l1, l2 = a.shape
b[1:l1,:l2-1] = a[1:l1,:l2-1] + a[:l1-1,1:l2]
print(b)   




