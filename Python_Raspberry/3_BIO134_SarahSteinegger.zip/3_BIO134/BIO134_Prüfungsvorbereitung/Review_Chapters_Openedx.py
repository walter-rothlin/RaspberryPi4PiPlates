# -*- coding: utf-8 -*-
"""
Created on Wed Aug 21 14:41:03 2019

@author: sara
"""

# Sara Steinegger
# Review Openedx

# Chapter 2: looping through lists
lys = ["Surely","you're","joking"]
for word in lys:
    print(word, end="*")
print()

lys = [5, 3, 3, 2]
n = 1
for number in lys:
    n *= number
print(n)

lys1 = [5, 6, 2, 9]
lys2 = [3, 8, 3, 6]
lys3 = [0]*3

for i in range(len(lys1)-1):
    lys3[i] = lys1[i]*lys2[i+1]
print(lys3)
    


# Chapter 4 - Lists
# Exercise: Reviewing lists
#l = [3, 2, 4]
l = [38, 38, 46, 46, 13, 24, 3, 54, 18, 47, 4, 42, 8, 66, 50,\
     46, 62, 36, 19, 19, 77, 17, 7, 63, 28, 47, 46, 65, 63, 12,\
     16, 24, 14, 51, 34, 56, 29, 59, 92, 79]
lnew = [0]*len(l)
for i in range(len(l)):
    lnew[i] = l[i]**3
print(lnew)
 
   

# Chatper 5 - Lists 2
# Exercise on building lists
# Auto-checker: Assembling a list
bases = "ACGT"
codons = []
for b1 in bases:
    for b2 in bases:
        for b3 in bases:
            if b1!=b2 and b2!=b3:
                codons.append(b1+b2+b3)
print(sorted(codons)[29])

# Auto-checker: select bases
import copy 
letters = ['z', 'a', 't', 'e', 'z', 'a', 'w', 'r', 'w', 'z', 'g',\
 'i', 's', 'h', 'g', 'f', 'w', 'w', 'u', 'f', 'y', 'n',\
 'g', 'l', 'k', 'c', 'o', 'j', 'o', 'y', 'q', 'k', 'w',\
 'z', 'm', 'y', 'a', 'd', 'e', 'y', 'r', 's', 'h', 'm',\
 'x', 'c', 'd', 'b', 'm', 'v', 'o', 'k', 'n', 'e', 'y',\
 'j', 'g', 'i', 'v', 'i', 'x', 'i', 'l', 'b', 'x', 'u',\
 'm', 'd', 'm', 'j', 'v', 'y', 't', 'h', 'b', 'x', 'y',\
 'e', 'm', 'm', 't', 'x']
bases = "acgt"
letters_copy = copy.deepcopy(letters)

for letter in letters_copy:
    if letter not in bases:
        letters.remove(letter)
print(letters)
          
# Exercise enumerate()
lys = ['The', 'sun', 'is', 'shining']
i = 0
for w in lys:
   print(i, w, end=" ")
   i += 1
print()
# Using in range()
lys = ['The', 'sun', 'is', 'shining']
for i in range(len(lys)):
    print(i, lys[i], end=" ")
print()
# Using enumerate()
lys = ['The', 'sun', 'is', 'shining']
for i, word in enumerate(lys):
    print(i, word, end=" ")
print()

# Exercise on looping through lists
#l = [['1', '5', '6'], ['8', '1'], ['5', '4', '4', '2']]
l = [['8', '6', '9'], ['3'], ['8', '3'], ['8', '4', '1', '2'], ['9', '5'], ['5', '9', '7'], ['4', '8', '8', '2'], ['6', '3', '3', '4'], ['8', '4', '3'], ['3', '6', '1', '2'], ['4', '9', '6', '4'], ['3', '7', '4'], ['5', '6'], ['9', '1'], ['2', '5'], ['3'], ['6', '8', '9'], ['7', '5'], ['8', '4', '1'], ['6', '6'], ['4'], ['5', '8', '7'], ['8', '8', '4'], ['5'], ['8', '3'], ['9'], ['4', '9'], ['6', '6', '6'], ['8', '6', '5', '1'], ['5', '7', '3', '6'], ['8', '4', '3', '7'], ['3', '8'], ['9', '2'], ['8', '3', '1', '1'], ['1', '7'], ['1'], ['2', '4', '5', '9'], ['2', '5'], ['9', '7', '1'], ['1'], ['1', '8', '7', '9'], ['5', '1', '3', '1'], ['2', '5', '4', '3'], ['4', '6'], ['5', '5', '2', '7'], ['2', '9'], ['8', '7', '5', '8'], ['7', '5'], ['7'], ['9', '2'], ['7', '1'], ['1', '5', '5', '9'], ['3', '2', '1', '9'], ['5', '9'], ['2'], ['7', '1'], ['6', '6'], ['9', '5'], ['2'], ['7', '9', '1', '4'], ['8', '1'], ['1']]
for sublist in l:
    for i in range(len(sublist)):
        sublist[i] = int(sublist[i])
print(l)
                
 # List of lists 2
l = [[5], [6, 1], [3, 4, 2, 2, 1]]
lnew = []
for sublist in l:
    sum_squares = 0
    for i in range(len(sublist)):
        sublist[i] = sublist[i]**2
        sum_squares += sublist[i]
    lnew.append(sum_squares)
print(l)
print(lnew)               



# Chapter 6 - Dictionaries
# Exercise: genetic code
cdn = {}
cdn['ttt'] = cdn['ttc'] = 'F phenylalanine'
cdn['tta'] = cdn['ttg'] = 'L leucine'
cdn['tct'] = cdn['tcc'] = cdn['tca'] = cdn['tcg'] = 'S serine'
cdn['tat'] = cdn['tac'] = 'Y tyrosine'
cdn['taa'] = cdn['tag'] = '* stop'
cdn['tgt'] = cdn['tgc'] = 'C cysteine'
cdn['tga'] = '* stop'
cdn['tgg'] = 'W tryptophan'
cdn['ctt'] = cdn['ctc'] = cdn['cta'] = cdn['ctg'] = 'L leucine'
cdn['cct'] = cdn['ccc'] = cdn['cca'] = cdn['ccg'] = 'P proline'
cdn['cat'] = cdn['cac'] = 'H histidine'
cdn['caa'] = cdn['cag'] = 'Q glutamine'
cdn['cgt'] = cdn['cgc'] = cdn['cga'] = cdn['cgg'] = 'R arginine'
cdn['att'] = cdn['atc'] = cdn['ata'] = 'I isoleucine'
cdn['atg'] = 'M methionine'
cdn['act'] = cdn['acc'] = cdn['aca'] = cdn['acg'] = 'T threonine'
cdn['aat'] = cdn['aac'] = 'N asparagine'
cdn['aaa'] = cdn['aag'] = 'K lysine'
cdn['agt'] = cdn['agc'] = 'S serine'
cdn['aga'] = cdn['agg'] = 'R arginine'
cdn['gtt'] = cdn['gtc'] = cdn['gta'] = cdn['gtg'] = 'V valine'
cdn['gct'] = cdn['gcc'] = cdn['gca'] = cdn['gcg'] = 'A alanine'
cdn['gat'] = cdn['gac'] = 'D aspartic acid'
cdn['gaa'] = cdn['gag'] = 'E glutamic acid'
cdn['ggt'] = cdn['ggc'] = cdn['gga'] = cdn['ggg'] = 'G glycine'

s = "atgagtaaaggagaagaacttttcactggagttgttccaattcttgttgaattagatggt"

amino_acid = ""
for i in range(0, len(s), 3):
    sequence = ""
    sequence += s[i:i+3]
    amino_acid += cdn[sequence][0]
print(amino_acid)
    
# Exercise: Keys in dictionaries 1
l = ['ediks', 29, 'adnec']
d = {'adcen': 65, 'ikjna': 29, 'ediks': 73, 'zhdis': 76}
lnew = [0]*len(l)
for i, element in enumerate(l):
    if element in d.keys():
        lnew[i] = 1
    else:
        lnew[i] = 0
print(lnew)
 
# Exercise: Keys in dictionaries 2
l = ['nwnnnwwnnd', 'wdnndnnwwn', 45, 'nwwwnwnnnwd', 'dnwndddnw', 'nnnwdwdndd',
     'ndnnwwnwnn', 'nwdnnnnnww', 'dnddwndnd', 'wwnwdnnwdw', 'dwndwnnnd', 17, 
     'nwddwwnnnnw', 'nnwndwwddw', 'wnwnwnwnd', 'wdwwwnnnw', 'nnwnddnnw', 
     'nwdnndwnww', 81, 'wnwwwwwnnnw', 'nwndnnnnnww', 31]
d = {'wnwwwwwnnnw': 48, 'nwndnnnnnww': 97, 'nnwdwdddnw': 63, 'nwndnnnnww': 45,
     'nwdnndnwnww': 39, 'nnwndddnnw': 82, 'wdnndnnwwn': 11, 'nnnwwwwnwdn': 31, 
     'dnwwwnnddw': 66, 'wnwnwnwnd': 89, 'dwdwwdnndww': 17, 'nnwnddnwnww': 80, 
     'dndwwnwwwwd': 94, 'nwwdnnwnd': 88, 'nwnnnwwnnd': 58, 'ndnwwnwwwd': 4, 
     'nwnwdwdnw': 45, 'nwwwnwnnnwd': 70, 'wdnnwnndnnd': 95, 'ndnddnwwwwn': 45, 
     'nwdnndddwd': 7, 'nwdnnnnnww': 5, 'nnwwnddnnwn': 45, 'nndwdnwwwwd': 29, 
     'nnwwdwddnww': 17, 'wnnwnnwnn': 24, 'dnwndddnw': 99, 'wwdnwwwndn': 36, 
     'wwwwwnndwn': 31, 'nwdnndwnww': 43, 'nwnndwwwwnd': 9, 'wdwwnnnnw': 71}
lnew = [0]*len(l)
for i, element in enumerate(l):
    if element in d.keys():
        lnew[i] = 1
    else:
        lnew[i] = 0
print(lnew)

# Exercise: Creating dictionaries 1
births = [['darwin','12 February 1809'],['shakespeare','26 April 1564'],\
          ['cervantes','29 September 1547'],['lincoln','12 February 1809']]
d = {}
for sublist in births:
    d[sublist[0]] = sublist[1]
print(d)

# Exercise: Creating dictionaries 2
births = [['darwin','12 February 1809'],['shakespeare','26 April 1564'],\
          ['cervantes','29 September 1547'],['lincoln','12 February 1809']]
d = {}
for sublist in births:
    if sublist[1] not in d.keys():
        d[sublist[1]]= []
    d[sublist[1]].append(sublist[0])
print(d)

# Exercise: Creating dictionaries 3
person = {}
person['darwin'] = 'Charles Darwin'
person['shakespeare'] = 'William Shakespeare'
person['cervantes'] = 'Miguel de Cervantes'
person['lincoln'] = 'Abraham Lincoln'
person_new = {}
for pers in person:
    person_new[person[pers]] = pers
print(person_new)

# Reffering to values in a list within a dictionary
d = {'Paul': 'Meier', 'Julia': 'Leutenegger', 'Daniel': 'Brunner'}
print(d['Julia'])
d = {'Paul': ['Meier', 20], 'Julia': ['Leutenegger', 23], 'Daniel': ['Brunner', 21]}
print(d["Paul"][1])

# Exercise: Creating dictionaries 4
person = {}

person['darwin'] = ['Charles Darwin','12 February 1809','19 April 1882']
person['shakespeare'] = ['William Shakespeare','26 April 1564','23 April 1616']
person['cervantes'] = ['Miguel de Cervantes','29 September 1547','23 April 1616']
person['lincoln'] = ['Abraham Lincoln','12 February 1809','15 April 1865']
person_new = {}
for per in person:
    if person[per][2] not in person_new.keys():
        person_new[person[per][2]] = []
    person_new[person[per][2]].append(per)
print(person_new)

# Exercise: Creating dictionaries 5
person = {}

person['darwin'] = ['Charles Darwin','12 February 1809','19 April 1882']
person['shakespeare'] = ['William Shakespeare','26 April 1564','23 April 1616']
person['cervantes'] = ['Miguel de Cervantes','29 September 1547','23 April 1616']
person['lincoln'] = ['Abraham Lincoln','12 February 1809','15 April 1865']
person_new = {}
for per in person:
    if person[per][2] not in person_new.keys():
        person_new[person[per][2]] = []
    person_new[person[per][2]].append(person[per][0])
print(person_new)

# Reverse genetic code
cdn = {}
cdn['ttt'] = cdn['ttc'] = 'F phenylalanine'
cdn['tta'] = cdn['ttg'] = 'L leucine'
cdn['tct'] = cdn['tcc'] = cdn['tca'] = cdn['tcg'] = 'S serine'
cdn['tat'] = cdn['tac'] = 'Y tyrosine'
cdn['taa'] = cdn['tag'] = '* stop'
cdn['tgt'] = cdn['tgc'] = 'C cysteine'
cdn['tga'] = '* stop'
cdn['tgg'] = 'W tryptophan'
cdn['ctt'] = cdn['ctc'] = cdn['cta'] = cdn['ctg'] = 'L leucine'
cdn['cct'] = cdn['ccc'] = cdn['cca'] = cdn['ccg'] = 'P proline'
cdn['cat'] = cdn['cac'] = 'H histidine'
cdn['caa'] = cdn['cag'] = 'Q glutamine'
cdn['cgt'] = cdn['cgc'] = cdn['cga'] = cdn['cgg'] = 'R arginine'
cdn['att'] = cdn['atc'] = cdn['ata'] = 'I isoleucine'
cdn['atg'] = 'M methionine'
cdn['act'] = cdn['acc'] = cdn['aca'] = cdn['acg'] = 'T threonine'
cdn['aat'] = cdn['aac'] = 'N asparagine'
cdn['aaa'] = cdn['aag'] = 'K lysine'
cdn['agt'] = cdn['agc'] = 'S serine'
cdn['aga'] = cdn['agg'] = 'R arginine'
cdn['gtt'] = cdn['gtc'] = cdn['gta'] = cdn['gtg'] = 'V valine'
cdn['gct'] = cdn['gcc'] = cdn['gca'] = cdn['gcg'] = 'A alanine'
cdn['gat'] = cdn['gac'] = 'D aspartic acid'
cdn['gaa'] = cdn['gag'] = 'E glutamic acid'
cdn['ggt'] = cdn['ggc'] = cdn['gga'] = cdn['ggg'] = 'G glycine'

aacid = {}
for sequence in cdn:
    if cdn[sequence][2:] not in aacid.keys():
        aacid[cdn[sequence][2:]] = []
    aacid[cdn[sequence][2:]].append(sequence)
print(sorted(aacid["serine"])[1])

# Exercise: Creating strings
#s = 'kenfaeniencdasjsbce'
s = 'ztvnenejsncejajdncalkjalymmxndjfbfbvsjdlfjbbaldkjfnlaqeqwqwplnnnel'
snew = ""
for i in range(0, len(s), 4):
    snew += s[i:i+2]
print(snew)
    
# A riddle
riddle = open("C://Users/sara/Desktop/BIO134_Prüfungsvorbereitung/riddle.txt", "r")
r = riddle.read()
riddle.close()

s = r.partition("*****")[2].partition("#####")[0]
word = ""
             
for letter in s:
    if letter in "abcdefghijklmnopqrstuvwxyz":
        word += letter
print(word)

# Exercise: number formatting
from numpy import pi
p = int(10**6 * pi)
print('{:08d} is an integer'.format(p))
print('{:013.8f} is a float'.format(pi))
print('{:017.8e} is a float in exp notation'.format(pi))

# String formatting
#s = "EzHsPsKyTvKJKqoVzwRavQTzHDtHQyvhrFUIeTBRkSRpJPlLEocbyJBiRlngqmfUKcd"
s = "dlFuBMOzwdejnppmBbTKtUHeCbixgCuKDiMICOPkwpmFPbAFdhvfeBGrooNpW"
sequence= ""
count = 0
for i in range(0, len(s), 10):
    sequence += s[i:i+5].upper()
    sequence += s[i+5:i+10].lower()
    count += len(s[i:i+10])  
print("{0:s}{1:10d}".format(sequence,count))
    


# Chapter 7: Function
# Exercise: writing a function
def average(lys):
    summe = 0
    for i in range(len(l)):
        summe += lys[i]
    mean = summe/len(lys)
    return mean   
l = [5.75, 5.37, 2.45, 8.22, 7.45, 1.89, 3.82, 2.49]
m = average(l)
print(m)

# Exercise: returning more than one variable
def sum_average(lys):
    s = 0
    for i in range(len(lys)):
        s += lys[i]
    m = s/len(lys)
    return s,m    
l = [5.75, 5.37, 2.45, 8.22, 7.45, 1.89, 3.82, 2.49]
summe, mean = sum_average(l)
print(int(summe * mean))    
    
# Exercise: function and printing 1
def test_square(a,b):
    s = a**2
    if s<b:
        print("The square of", a, "is smaller than", b, ".")
    else:
        print("The square of", a, "is not smaller than", b, ".")
test_square(4, 17)
test_square(4, 16)    
    
# Exercise: function and printing 2
def test_square2(a,b):
    s = a**2
    if s<b:
        return True
    #return s<b
a = 4
b = 16
if test_square2(a, b):
  print('The square of {:d} is smaller than {:d}.'.format(a,b))
else:
  print('The square of {:d} is not smaller than {:d}.'.format(a,b))    



# Chapter 9: Overview
# Creating lists
s = 'abcdefghijk'
l = []
for i in range(0, len(s), 4):
    l.append(s[i:i+2])
print(l)

# Creating strings
s = 'abcdefghijk'
snew = ""
for i in range(0, len(s), 4):
    snew += s[i:i+2]
print(snew)
    
# Creating dictionaries
s = 'abcdefghijk'
d = {}

for i in range(0, len(s), 4):
    d[s[i:i+2]] = s[i+2:i+4]
print(d)

# Creating arrays
import numpy as np
anew = np.zeros(shape=(3,4), dtype=float)
for i in range(len(anew)):
    anew[i,i+1] = i+1
print(anew)


















    









