# -*- coding: utf-8 -*-
"""
Created on Fri Aug 16 17:48:06 2019

@author: sara
"""

# Sara Steinegger
# 16.08.2019

# week 8: DNA Damage repair
import numpy as np
import matplotlib.pyplot as plt

x = np.array([0, 5, 15, 30, 60])
y1 = np.array([0, 0, 3, 10, 50])
sd_1 = np.array([0, 0, 2, 4, 9])
y2 = np.array([0, 42, 72, 89, 100])
print(sd_1)

#plt.plot(x, y1, "o")
plt.errorbar(x, y1, yerr=sd_1, marker="o",\
          linestyle="none", label="Embryonic lethality in wild-type")
plt.show()
