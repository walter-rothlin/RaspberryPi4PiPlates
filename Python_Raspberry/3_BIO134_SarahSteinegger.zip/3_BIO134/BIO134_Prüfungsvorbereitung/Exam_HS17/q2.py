# -*- coding: utf-8 -*-

names = {'Schmidt': 'Julia', 'Stierli': 'Paul', 'Meier': 'Emma'}
names_rev = {}
for lastname in names:
    firstname = names[lastname]
    names_rev[firstname] = lastname
print(names_rev)

