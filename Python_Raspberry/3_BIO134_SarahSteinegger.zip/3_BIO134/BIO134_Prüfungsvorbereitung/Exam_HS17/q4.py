# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
fyle = open('weights.csv')
listdata = fyle.readlines()
fyle.close()
x=[]
y=[]
for line in listdata:
    linelist=line.strip().split(',')
    x.append(int(linelist[0]))
    mean = 0
    for i in range(1,len(linelist)):
        mean += int(linelist[i])
    mean = mean / (len(linelist)-1)
    print(mean)
    y.append(mean)
plt.plot(x,y)
plt.savefig('weights.png')
plt.show()

