# -*- coding: utf-8 -*-
"""
Created on Thu Aug 22 10:13:49 2019

@author: sara
"""

# Sara Steinegger
# Exam 2017

# Question 1
#n = 10
n = 9
summe = 0
for i in range(0,n+1,2):
    summe += i
print(summe)

# Question 2
names = {'Schmidt': 'Julia', 'Stierli': 'Paul', 'Meier': 'Emma'}
reverse = {}
for element in names:
    reverse[names[element]]=element
print(reverse)

# Question 3
def maximum(lys):
    maxi = 0
    ind = 0
    for i,number in enumerate(lys):
        if number>maxi:
            maxi = number
            ind = i
    return maxi, i
l = [6, 34, 2, 134, 265, 49]
m = maximum(l)
print(m[0])
print(m[1])

# Question 4
import matplotlib.pyplot as plt

number_fyle = open("weights.csv", "r")
number = number_fyle.readlines()
x = []
y = []

for i in range(len(number)):
    number[i] = number[i].strip().split(",")
    x.append(number[i][0])
    m = 0
    for j in range(1,len(number[i])):
        m += int(number[i][j])
    mean = m/len(number[i])-1
    y.append(mean)
        
plt.plot(x,y)

# Question 5
import numpy as np
a = np.array([[3, 6, 8], [8, 3, 1], [2, 4, 2], [9, 2, 0]])
a[1:,:-1] += 2
print(a)        

# Question 6
lys = [['snow', 'bright'], ['green', 'hat'], ['run', 'stone']]
lnew = []

consonants = "aeiou"
for c in consonants:
    for i, sublist in enumerate(lys):
        for j, word in enumerate(sublist):
            if c in word:
                lys[i][j] = word.replace(c, c.upper())

for i in range(len(lys[0])):
    lnew.append([])
    for j in range(len(lys)):
        lnew[i].append(lys[j][i])
print(lnew)
    
# Question 7
import numpy as np

im = np.array([[0.6, 0.1, 0.4, 0.5, 0.6],
 [0.6, 0.5, 0.9, 0.2, 0.7],
 [0.3, 0.9, 0.7, 0.5, 0.9],
 [0.8, 0.5, 0.4, 0.8, 0.6]])

x,y = im.shape
im_1 = np.zeros(shape=(x+3,y+3), dtype=float)
im_new = 0.1*im_1
im_new[1:-2,1:-2]=im[:,:]
for i in range(1,y+1):
    for j in range(1,x+1):
        #print(im_new[i-1:i+2,j-1:j+2])
        im_1[i,j] = np.min(im_new[i-1:i+2,j-1:j+2])
print(im_1)
      
