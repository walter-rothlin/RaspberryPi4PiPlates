# -*- coding: utf-8 -*-
import numpy as np
def erode(im):
    im_er = 0 * im
    h = im.shape[0]
    w = im.shape[1]
    for i in range(h):
        for j in range(w):
            if i>0 and i<h-1:
                if j == 0:
                    im_er[i,j] = np.min(im[i-1:i+2,j:j+2])
                elif j == w-1:
                    im_er[i,j] = np.min(im[i-1:i+2,j-1:])
                else:
                    im_er[i,j] = np.min(im[i-1:1+2,j-1:j+2])
            elif i == 0:
                if j == 0:
                    im_er[i,j] = np.min(im[0:2,0:2])
                elif j == w-1:
                    im_er[i,j] = np.min(im[0:2,j-1:])
                else:
                    im_er[i,j] = np.min(im[0:2,j-1:j+2])
            elif i == h-1:
                if j == 0:
                    im_er[i,j] = np.min(im[i-1:,0:2])
                elif j == w-1:
                    im_er[i,j] = np.min(im[i-1:,j-1:])
                else:
                    im_er[i,j] = np.min(im[i-1:,j-1:j+2])           
    return im_er
            
im = np.array([[0.6, 0.1, 0.4, 0.5, 0.6],
               [0.6, 0.5, 0.9, 0.2, 0.7],
               [0.3, 0.9, 0.7, 0.5, 0.9],
               [0.8, 0.5, 0.4, 0.8, 0.6]])
print(erode(im))

