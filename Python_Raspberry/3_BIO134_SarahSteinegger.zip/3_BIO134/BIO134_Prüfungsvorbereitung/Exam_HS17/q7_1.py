# -*- coding: utf-8 -*-
import numpy as np

def erode(im):
    im_er = 0 * im
    h = im.shape[0]
    w = im.shape[1]
    for i in range(h):
        for j in range(w):
            mini = i-1
            minj = j-1
            if i == 0:
                mini = 0
            if j == 0:
                minj = 0
            im_er[i,j] = np.min(im[mini:i+2,minj:j+2])    
    return im_er
    
im = np.array([[0.6, 0.1, 0.4, 0.5, 0.6],
               [0.6, 0.5, 0.9, 0.2, 0.7],
               [0.3, 0.9, 0.7, 0.5, 0.9],
               [0.8, 0.5, 0.4, 0.8, 0.6]])
print(erode(im))

