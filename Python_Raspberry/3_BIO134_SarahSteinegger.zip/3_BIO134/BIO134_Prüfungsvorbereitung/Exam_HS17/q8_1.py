# -*- coding: utf-8 -*-

def compare(seq, seqlist):
    scores = []
    for s in seqlist:
        s_end = (len(seq)-1) * '*' #pad sequence with stars, so that sliding at the ends is easier
        s = s_end + s + s_end
        maxscore = 0
        for i in range(len(s) - len(seq) + 1):
            slyce = s[i:i+len(seq)]
            score = 0
            for j in range(len(seq)):
                if seq[j] == slyce[j]:
                    score += 1
            if score>maxscore:
                maxscore = score
        scores.append(maxscore)
    return(scores)

seq = 'ggta'
seqlist = ['gtacct', 'ctccgg', 'ccgctacg']
print(compare(seq, seqlist))

seq = 'ccagcgta'
seqlist = ['cgctttacctgcc', 'ggttagttcatgg', 'atcgttacgcggtata',
           'agcctatagccc']
print(compare(seq, seqlist))
seq = 'ccagcgta'
seqlist = ['cgctttacctgcc', 'ggttagttcatgg',
           'atcgttacgcggtata', 'agcctatagccc']
print(compare(seq, seqlist))
