# -*- coding: utf-8 -*-

def compare(seq, seqlist):
    scores = []
    for s in seqlist:
        maxscore = 0
        for i in range(len(s)):
            shortseq = s[i:i+len(seq)]
            score = 0
            for j in range(len(shortseq)):
                if seq[j] == shortseq[j]:
                    score += 1
            if score>maxscore:
                maxscore = score
        for i in range(len(seq)):
            shortseq = s[0:i]
            for start in range(len(seq)-len(shortseq)+1):
                score = 0
                for j in range(len(shortseq)):
                    if seq[j+start] == shortseq[j]:
                        score += 1
                if score>maxscore:
                    maxscore = score
        scores.append(maxscore)
    return scores

seq = 'ggta'
seqlist = ['gtacct', 'ctccgg', 'ccgctacg']
print(compare(seq, seqlist))

seq = 'ccagcgta'
seqlist = ['cgctttacctgcc', 'ggttagttcatgg', 'atcgttacgcggtata',
           'agcctatagccc']
print(compare(seq, seqlist))
