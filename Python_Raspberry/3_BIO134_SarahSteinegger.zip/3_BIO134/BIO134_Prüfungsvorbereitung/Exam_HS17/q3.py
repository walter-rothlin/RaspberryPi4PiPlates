# -*- coding: utf-8 -*-

def maximum(lyst):
    m = 0
    pos = 0
    for i, num in enumerate(lyst):
        if num>m:
            m = num
            pos = i
    return m,pos
            
l = [6, 34, 2, 134, 265, 49]
m = maximum(l)
print(m[0])
print(m[1])

