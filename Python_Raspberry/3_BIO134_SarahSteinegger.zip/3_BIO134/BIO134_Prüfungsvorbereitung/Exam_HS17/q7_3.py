# -*- coding: utf-8 -*-
import numpy as np

def erode(im):
    h = im.shape[0]
    w = im.shape[1]
    padded = np.zeros([h+3,w+3]) + 1
    padded[1:-2,1:-2] = im
    im_er = 0 * im + 1
    print(im_er)
    for i in range(-1,2):
        for j in range(-1,2):
            sliced = padded[1+i:-2+i,1+j:-2+j]
            im_er[im_er>sliced] = sliced[im_er>sliced]      
    return im_er
            
im = np.array([[0.6, 0.1, 0.4, 0.5, 0.6],
               [0.6, 0.5, 0.9, 0.2, 0.7],
               [0.3, 0.9, 0.7, 0.5, 0.9],
               [0.8, 0.5, 0.4, 0.8, 0.6]])
print(erode(im))
