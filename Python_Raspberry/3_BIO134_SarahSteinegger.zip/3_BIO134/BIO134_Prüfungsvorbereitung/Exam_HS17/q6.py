# -*- coding: utf-8 -*-

lys = [['snow', 'bright'], ['green', 'hat'], ['run', 'stone']]

consonants = 'aeuoi'
for c in consonants:
    for i, short_list in enumerate(lys):
        for j, word in enumerate (short_list):
            lys[i][j] = word.replace(c,c.upper())
lnew = []
for i in range(len(lys[0])):
    lnew.append([])
    for j in range(len(lys)):
        lnew[i].append(lys[j][i])
print(lnew)

