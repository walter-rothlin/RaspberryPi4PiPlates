# -*- coding: utf-8 -*-
"""
Created on Thu Aug 15 18:45:25 2019

@author: sara
"""

# Sara Steinegger
# 15.08.2019

# Exam 2017


# Question 1
#n = 10
n = 9
n1 = 0

for i in range(0, n+1, 2):
    n1 += i
print(n1, "\n")



# Question 2
names = {'Schmidt': 'Julia', 'Stierli': 'Paul',\
         'Meier': 'Emma'}
names_new = {}

for name in names:
    names_new[names[name]] = name
print(names_new, "\n")        



# Question 3
def maximum(lys):
    m = 0
    ind = 0
    for i, el in enumerate(lys):
        if el>m:
            m = el
            ind = i
    return m, ind

l = [6, 34, 2, 134, 265, 49]
m = maximum(l)
print(m[0])
print(m[1])
print()



# Question 4
weights = open("weights.csv", "r")
w = weights.readlines()
weights.close()

for i in range(len(w)):
    w[i] = w[i].strip().split(",")

age = []
mean_weight = []

for element in w:
    m = 0
    for i in range(len(element)):
        if i == 0:
            age.append(int(element[i]))
        else:
            m += int(element[i])
    m = m/4
    mean_weight.append(m)
print(age)
print(mean_weight)
print()



# Question 5
import numpy as np
a = np.array([[3, 6, 8], [8, 3, 1], [2, 4, 2], [9, 2, 0]])
a[1:, :-1] += 2

print(a, "\n")



# Question 6
lys = [['snow', 'bright'], ['green', 'hat'],\
       ['run', 'stone']]

letter = 'aeuoi'
for l in letter:
    for i, element in enumerate(lys):
        for j, word in enumerate (element):
            lys[i][j] = word.replace(l,l.upper())

lnew = []
for i in range(len(lys[0])):
    lnew.append([])
    for j in range(len(lys)):
        lnew[i].append(lys[j][i])
print(lnew)
        
        
            
# Question 7
import numpy as np
im = np.array([[0.6, 0.1, 0.4, 0.5, 0.6],
 [0.6, 0.5, 0.9, 0.2, 0.7],
 [0.3, 0.9, 0.7, 0.5, 0.9],
 [0.8, 0.5, 0.4, 0.8, 0.6]])
#def erode(image):
x = im.shape[0]
y = im.shape[1]
im1 = np.zeros(shape=(x,y), dtype=float)
for i in range(x):
    for i in range(y):
        

    

    
im = np.array([[0.6, 0.1, 0.4, 0.5, 0.6],
 [0.6, 0.5, 0.9, 0.2, 0.7],
 [0.3, 0.9, 0.7, 0.5, 0.9],
 [0.8, 0.5, 0.4, 0.8, 0.6]])
#print(erode(im))

print(im)
print(im.shape)





