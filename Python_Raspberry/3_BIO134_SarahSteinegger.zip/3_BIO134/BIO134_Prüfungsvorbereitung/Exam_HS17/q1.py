# -*- coding: utf-8 -*-

n = 10
summe = 0
for i in range(0,n+1,2):
    summe += i
print(summe)

