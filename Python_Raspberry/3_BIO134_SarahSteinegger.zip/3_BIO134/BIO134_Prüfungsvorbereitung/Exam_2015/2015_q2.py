#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 15:39:32 2017

@author: sekiss
"""

s='The grass is green'

spl=[s[start:start+2] for start in range(0,len(s),2)]
     
print(spl)