# -*- coding: utf-8 -*-
"""
Created on Sun Aug 11 21:10:46 2019

@author: sara
"""

# Sara Steinegger
# 11.08.2019

# Exam 2015



# Question 1
aacids = ["A", "N", "L", "S", "T"]
counter = 0
for acid1 in aacids:
    for acid2 in aacids:
        for acid3 in aacids:
            for acid4 in aacids:
                counter += 1
                print(counter, acid1 + acid2 + acid3 +acid4)



# Question 2
s = "The grass is green"
s1 = []

for i in range(0, len(s), 2):
    s1.append(s[i:i+2])
print(s1)



# Question 3
def multiply10_20(a):
    x1 = a*10
    x2 = a*20
    return (x1, x2)
n=5
print(multiply10_20(n))



# Question 4
seq1={"aaq":[3,5], "aat":[4]}
seq2={"aca": [4,8,9], "aaq":[2]}
seq3 ={}


for element in seq1:
    print(seq1[element])
    if element in seq2.keys():
        seq3[element] = [seq1[element], seq2[element]]
print(seq3)
    
   
    
# Question 5
s = "There is a rat in my kitchen"
s_new = s.split()
c = 0
if len(s_new)%2 == 1:
    s_new.append("")

for i in range(0, len(s_new), 2):
    s1 = s_new[i]
    c += len(s1)
    while len(s1)<7:
        s1 += "."
    s2 = s_new[i+1]
    c += len(s2)
    while len(s2)<7:
        s2 += "."
    print("{0:7s}.{1:7s}. {2:2d}".format(s1, s2, c))
    
    
    
    
    



 
    

    
    
    