#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 16:39:14 2017

@author: sekiss
"""
#Suppose that an ecosystem consisting of foxes(f), chickens(c) and worms(w) 



## set variables: ------------------------------------------------------------
f,c,w=5,30,140
dt=100
t=32
iterations=dt*t

## calculations: -------------------------------------------------------------
for i in range(iterations):
    df= (-0.1/dt)*f + (0.01/dt)*f*c
    dc= (0.001/dt)*c*w - (0.01/dt)*f*c
    dw= (0.2/dt)*w - (0.02/dt)*c*w

    f+=df
    c+=dc
    w+=dw

print('f: ',int(f))
print('c: ',int(c))
print('w: ',int(w))

## results: ------------------------------------------------------------------