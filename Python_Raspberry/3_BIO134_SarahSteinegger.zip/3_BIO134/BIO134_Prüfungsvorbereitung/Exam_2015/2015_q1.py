#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 15:35:00 2017

@author: sekiss
"""

aacids=['A', 'N', 'L', 'S', 'T']
counter=0

for first in aacids:
    for second in aacids:
        for third in aacids:
            for fourth in aacids:
                counter+=1
                print(counter,' ',first+second+third+fourth)