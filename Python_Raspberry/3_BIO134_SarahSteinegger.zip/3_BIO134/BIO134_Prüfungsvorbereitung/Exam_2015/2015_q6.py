#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 15:56:35 2017

@author: sekiss
"""

#Write a function, dilate_part(), that takes two arguments, a two-dimensional 
#array of any size and an n*2 array, both with integers. Change the first array 
#at the positions indicated by the second array as follows: Replace the value 
#by the maximum value of itself and its 4 closest neighbors. If there are less 
#than 4 closest neighbors, take the maximum of the closest neighbors that are present.

import numpy as np

## define variables:
inp1 = np.zeros(shape=(6,8),dtype=int)
inp1[0,6] = 2
inp1[0,7] = 3
inp1[3,0] = 6
inp1[3,1:3] = 8

inp2=np.array([[0,5],[0,7],[2,1],[3,0]])

## calculations:

def dilate_part(inp1,inp2):
#    print('input: \n',inp1)
    
    outp=inp1*1
    shape_x,shape_y=inp1.shape

    
    for element in inp2:
        x=element[0]
        y=element[1]
    
        neighbors=[inp1[x,y]]
        if x>0:
            neighbors.append(inp1[x-1,y])
    #        print('addded left')
        if x<shape_x-1:
            neighbors.append(inp1[x+1,y])
    #        print('addded right')
        if y>0:
            neighbors.append(inp1[x,y-1])
    #        print('addded above')
        if y<shape_y-1:
            neighbors.append(inp1[x,y+1])
    #        print('addded below')
            
    #    print('neighbors: ',neighbors)
        outp[x,y]=max(neighbors)
#    print('\noutput: \n',outp)
    return(outp)
    
    
print(dilate_part(inp1,inp2)) 

