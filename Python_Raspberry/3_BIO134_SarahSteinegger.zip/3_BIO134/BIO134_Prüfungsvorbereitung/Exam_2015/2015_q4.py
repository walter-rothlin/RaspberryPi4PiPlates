#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 15:45:16 2017

@author: sekiss
"""

#Write a program that prints a new dictionary, which contains the keys that are 
#common to seq1 and seq2. The value of a key should be a list with the value of
# seq1 at this key as first element, and the value of seq2 at this key as 
# second element. The program should be general enough that it can also be 
# used if names1 and names2 code other dictionaries with other numbers of
# elements. The output should be:
#
#{'aag': [[3, 5], [2]]}

seq1={'aag': [3,5], 'aat': [4]}
seq2={'aca': [4,8,9], 'aag': [2]}
      
def common_dict(d1,d2):
    com={}
    com_keys= d1.keys() & d2.keys()
    
    for key in com_keys:
        com[key]=[d1[key],d2[key]]
    
    return(com)

com=common_dict(seq1,seq2)
print(com)

