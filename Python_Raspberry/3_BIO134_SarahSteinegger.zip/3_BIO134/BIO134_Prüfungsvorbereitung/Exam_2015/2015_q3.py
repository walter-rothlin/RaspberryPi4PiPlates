#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 15:44:06 2017

@author: sekiss
"""
def multiply10_20(n):
    return(n*10,n*20)
n=5
print (multiply10_20(n))
