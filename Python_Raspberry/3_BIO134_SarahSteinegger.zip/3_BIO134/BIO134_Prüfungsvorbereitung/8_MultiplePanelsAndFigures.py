# -*- coding: utf-8 -*-
"""
Created on Fri Aug 16 19:01:41 2019

@author: sara
"""

# Sara Steinegger
# 16.08.2019

# Multiple panels and figures
import matplotlib.pyplot as plt
plt.figure(1)         # first figure
plt.subplot(211)      # first subplot in first figure (2 rows, 1 column, 1st panel)
plt.plot([1, 2, 1])          
plt.subplot(212)      # the second subplot in the first figure, 2nd panel
plt.plot([3, 2, 1])

plt.figure(2)         # a second figure
plt.plot([4, 5, 6])   # creates a subplot(111) by default
plt.show()