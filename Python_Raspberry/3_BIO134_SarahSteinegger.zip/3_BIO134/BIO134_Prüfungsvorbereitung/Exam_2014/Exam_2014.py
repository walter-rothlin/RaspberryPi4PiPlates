# -*- coding: utf-8 -*-
"""
Created on Wed Aug 14 14:06:24 2019

@author: sara
"""

# Sara Steinegger
# 14.08.2019

# Exam 2014



# Question 1
lyst = ["cats", "dogs", "rabbits", "horses"]

for i in range(len(lyst)):
    print("{:0<2d}".format(i+1), lyst[i])
print()



# Question 2
lyst1 = ["Love", "looks", "not", "with", "the", "eyes"]
lyst2 = ["but", "with", "the", "mind"]

print("Common:")
for i, string in enumerate(lyst1):
    if string in lyst2:
        print(string)
print()


# Question 3
def create_list(a, b):
    l = [a, b]
    return l
    
str1 = "hello"
str2 = "hi"
print(create_list(str1, str2))
print()



# Question 4
names = {}
names["Schmid"] = ["Ueli"]
names["Keller"] = ["Urs", "Vreni"]
names["Stierli"] = ["Martin"]

names_modified = {}

for element in names:
    if len(names[element]) == 1:
        names_modified[element] = names[element]
print(names_modified, "\n")



# Question 5
s = "Your_care_is_gain_of_care,_by_new_care_won"

for i in range(0, len(s), 6):
    s1 = s[i:i+5].lower()
    n = i+1
    if n<10:
        print("{0:d}:{1:.>9s}".format(n, s1))
    if n>=10:
        print("{0:d}:{1:.>8s}".format(n, s1))
