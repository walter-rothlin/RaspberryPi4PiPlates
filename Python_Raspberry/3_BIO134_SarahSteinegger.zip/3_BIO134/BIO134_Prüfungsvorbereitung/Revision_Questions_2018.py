# -*- coding: utf-8 -*-
"""
Created on Sun Aug 18 17:23:18 2019

@author: sara
"""

# Sara Steinegger
# 18.08.2019

# Revision Questions 2018



# Question 1: A string
s = 'The air is blue'
l = []
for i in range(0, len(s), 2):
    l.append(s[i:i+2])
print(l)
# solution
s = 'The air is blue'
l = []
for i in range(0,len(s),2):
    l.append(s[i:i+2])
print (l)



# Question 2: A subset of codons
bases = "ACTG"
codons = []

for b1 in bases:
    for b2 in bases:
        for b3 in bases:
            if (b1==b2 or b2==b3 or b1==b3) and not(b1==b2 and b2==b3):
                codons.append(b1+b2+b3)
print(sorted(codons)[25])
# solution
bases='atcg'
codons=[]
for b1 in bases:
    for b2 in bases:
        for b3 in bases:
            if not (b1==b2 and b2==b3):
                if b1==b2 or b2==b3 or b1==b3:
                    codons.append(b1+b2+b3)
codons=sorted(codons)
print (codons[25])



# Question 3: function
def factorial(a):
    f = 1
    for i in range(1, a+1):
        f *= i
    return f
n = 19
print(factorial(n))
# solution
def factorial(n):
    f=1
    for i in range(1,n+1):
        f*=i
    return f
n=19
print(factorial(n))



# Question 4: Shakespeare
shakespeare = open("shakespeare.txt", "r")
s = shakespeare.readlines()
shakespeare.close()

length = []
word = []
for i in range(len(s)):
    s[i] = s[i].split()
    print("{:4d} {:s}".format(len(s[i]), s[i][1]))
# solution
fyle=open('shakespeare.txt')
text=fyle.readlines()
fyle.close()
for line in text:
    lys=line.split()
    print ('{:4d} '.format(len(lys))+lys[1])



# Question 5: Slicing

# solution    
import numpy as np

def La(prot):
    N = len(prot)
    dprot = np.zeros(N)
    dprot[1:N-1] = -2*prot[1:N-1] + prot[:N-2] + prot[2:] #N could also be left out
    dprot[0] = -prot[0] + prot[1]
    dprot[-1] = -prot[-1] + prot[-2]
    return dprot
    
N = 20
np.random.seed(0)
a = np.zeros(N) + 1 + 0.3 * np.random.rand(N)
print(La(a))


# Question 6: Longest shared sequence
a1 = "MNENLFASFIAPTILGLPAAVLIILFPPLLIPTSKYLINNRLITTQQWLIKLTSKQMMTMHNTKGRTWSLMLVSLIIFIATTNLLGLLPHSFTPTTQLSMNLAMAIPLWAGTVIMGFRSKIKNALAHFLPQGTPTPLIPMLVIIETISLLIQPMALAVRLTANITAGHLLMHLIGSATLAMSTINLPSTLIIFTILILLTILEIAVALIQAYVFTLLVSLYLHDNT"
a2 = "MMTNLFSVFDPSTTILNLSLNWLSTFLGLLLIPFSFWLLPNRFQVVWNNILLTLHKEFKTLLGPSGHNGSTLMFISLFSLIMFNNFLGLFPYIFTSTSHLTLTLALAFPLWLSFMLYGWINHTQHMFAHLVPQGTPPVLMPFMVCIETISNVIRPGTLAVRLTANMIAGHLLLTLLGNTGPMTTNYIILSLILTTQIALLVLESAVAIIQSYVFAVLSTLYSSEVN"

l1 = len(a1)
l2 = len(a2)
if l1>=l2:
    long=l1
    short=l2
else:
    long=l2
    short=l1

a=""
for i in range(long):
    a += a1[i]
    if a in a2:
        same = a
print(same)






        


