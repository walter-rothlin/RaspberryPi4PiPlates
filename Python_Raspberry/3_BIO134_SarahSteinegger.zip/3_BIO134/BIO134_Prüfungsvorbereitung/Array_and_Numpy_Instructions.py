# -*- coding: utf-8 -*-
"""
Created on Sun Aug 11 18:52:10 2019

@author: sara
"""

# Sara Steinegger
# 11.08.2019

# Numpy and Arrays


# Example
import numpy as np
import matplotlib.pyplot as plt
cvalues = [20.1, 20.8, 21.9, 22.5, 22.7, 21.8, 21.3, 20.9, 20.1]

C = np.array(cvalues)
print(C, type(C))
print(C*9/5+32)

#plt.plot(C)
#plt.show



# arrange
# arange([start,] stop[, step], [, dtype=None])
import numpy as np

a = np.arange(1, 9, 2, dtype=int)
print(a)

a = np.arange(7.3)
print(a)

a = np.arange(0.5, 6.1, 0.8)
print(a)

a = np.arange(0.5, 6.1, 0.8, int)
print(a)



# linspace
# linspace(start, stop, num=50, endpoint=True, retstep=False)
import numpy as np
# 50 Werte (Defaut) zwischen 1 und 10:
print(np.linspace(1, 10))
# 7 Werte zwischen 1 und 10:
print(np.linspace(1, 10, 7))
# 7 Werte zwischen 1 und 10 (ohne Endpunkt):
print(np.linspace(1, 10, 7, endpoint=False))
# Mit dem Parameter retstep= True wird der Abstand
# zwischen Werten auch angegeben in einem Tuple



# Nulldimensionale Arrays in Numpy
import numpy as np
x = np.array(42)

print("x:", x)
print("Der Datentyp von x:", type(x))
print("Die Dimension von x:", np.ndim(x))



# Eindimensionales Array
F = np.array([1, 1, 2, 3, 5, 8, 13, 21])
V = np.array([3.4, 6.9, 99.8, 12.8])

print("F:", F)
print("V:", V)
print("Typ von F: ", F.dtype)
print("Typ von V: ", V.dtype)
print("Dimension von F: ", np.ndim(F))
print("Dimension von V: ", np.ndim(V))



# Zwei und Mehrdimensionale Arrays
A = np.array([[3.4, 8.7, 9.9],
              [1.1, -7.8, -0.7],
              [4.1, 12.3, 4.8]])
print(A)
print("Dimension von A: ", np.ndim(A))
print("Dimension von A: ", A.ndim)



# Shape/Gestalt eines Arrays
# Skalar
x = np.array(11)
print("Der Shape eines Skalars ist ein leeres Tuple: ", x.shape)

# Zweidimensionaler Array
x = np.array([[67, 63, 87],
             [77, 69, 59],
             [85, 87, 99],
             [79, 72, 71],
             [63, 89, 93],
             [68, 92, 78]])
print(np.shape(x))
print(x.shape)
x.shape = (3, 6)
print(x)           
            
x.shape = (2, 9)             
print(x)
             
# Dreidimensionaler Array
B = np.array([[[111, 112], [121, 122]],
              [[211, 212], [221, 222]],
              [[311, 312], [321, 322]]]) 
print(B.shape)



# Indizierung und Teilbereichsoperatoren (slicing)
# Eindimesionaler Array
F = np.array([1, 1, 2, 3, 5 , 8, 13, 21])
print(F[0])
print(F[-1])
# Zweidimensionale Arrays
A = np.array([[3.4, 8.7, 9.9],
              [1.1, -7.8, -0.7],
              [4.1, 12.3, 4.8]])
print(A[1][0])          
print(A[1, 0])            
# Dreidimensionales Array
B = np.array([[[111, 112], [121, 122]],
              [[211, 212], [221, 222]],
              [[311, 312], [321, 322]]])
print(B[0][1][0])             

# Slicing Beispele
# Eindimensionale Arrays
S = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
print(S[2:5])
print(S[:4])
print(S[6:])
print(S[:])
# Zweidimensionale Arrays
A = np.array([[11, 12, 13, 14, 15],
              [21, 22, 23, 24, 25],
              [31, 32, 33, 34, 35],
              [41, 42, 43, 44, 45],
              [51, 52, 53, 54, 55]])
print(A[:3,2:])             
print(A[3:, :])
print(A[:,4:])

X = np.arange(28).reshape(4,7)
print(X)
print(X[::2,::3])
print(X[::, ::3])
# Dreidimensionale Arrays
A = np.array([[[45, 12, 4], [45, 13, 5], [46, 12, 6]],
              [[46, 14, 4], [45, 14, 5], [46, 11, 5]],
              [[47, 13, 2], [48, 15, 5], [52, 15, 1]]])
print(A[1:3, 0:2, :])



# ACHTUNG
# Das orginale Array wird verändert
A = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
S = A[2:6]
S[0] = 22
S[1] = 23
print(A)
# Die orginale Liste wird nicht verändert
lst = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
lst2 = lst[2:6]
lst2[0] = 22
lst2[1] = 23
print(lst)



# Dreidimensionale Arrays
X = np.array([[[3, 1, 2], [4, 2, 2,]],
               [[-1, 0, 1], [1, -1, -2]],
               [[3, 2, 2], [2, 2, 1]],
               [[2, 2, 1], [3, 1, 3]]])
print(X.shape)
print("Dimension 0 with size ", X.shape[0])
for i in range(X.shape[0]):
    print(X[i,:,:])
    
print("\nDimension 1 with size ", X.shape[1])
for i in range(X.shape[1]):
    print(X[:,i,:])
    
print("\nDimension 2 with size ", X.shape[2])
for i in range(X.shape[2]):
    print(X[:,:,1])



# Array mit Einsen oder Nullen
# Array mit Einsen
E = np.ones (shape=(2,3), dtype=int)
print(E)
# Array mit Nullen
Z = np.zeros(shape=(3,4),dtype=int)
print(Z)
# ones_like und zeros_like
X = np.array([2, 5, 18, 14, 4])
E = np.ones_like(X)
Z = np.zeros_like(X)
print(E)
print(Z)



# Arrays kopieren
#np.copy(A)
#A.copy()



# Identitäts-Array
# identity
print(np.identity(4, dtype=int))
# eye (k stezt die Lage der Diagonale)
print(np.eye(5, 8, k=1, dtype=int))



             
             
             