def dictate(seq,W):
    dic = {}
    for i in range(len(seq)-W+1):
        section = seq[i:i+W]
        if section in dic:
            dic[section].append(i)
        else:
            dic[section] = [i]
    return dic

def common(a,b,W):
    one = dictate(a,W)
    two = dictate(b,W)
    matches = []
    for key in one:
        if (key in two) and (key not in matches):
            matches.append(key)
    return matches

human = 'MNENLFASFIAPTILGLPAAVLIILFPPLLIPTSKYLINNRLITTQQWLIKLTSKQMMTM' + \
'HNTKGRTWSLMLVSLIIFIATTNLLGLLPHSFTPTTQLSMNLAMAIPLWAGTVIMGFRSK' + \
'IKNALAHFLPQGTPTPLIPMLVIIETISLLIQPMALAVRLTANITAGHLLMHLIGSATLA' + \
'MSTINLPSTLIIFTILILLTILEIAVALIQAYVFTLLVSLYLHDNT'

mosq = 'MMTNLFSVFDPSTTILNLSLNWLSTFLGLLLIPFSFWLLPNRFQVVWNNILLTLHKEFKT' + \
'LLGPSGHNGSTLMFISLFSLIMFNNFLGLFPYIFTSTSHLTLTLALAFPLWLSFMLYGWI' + \
'NHTQHMFAHLVPQGTPPVLMPFMVCIETISNVIRPGTLAVRLTANMIAGHLLLTLLGNTG' + \
'PMTTNYIILSLILTTQIALLVLESAVAIIQSYVFAVLSTLYSSEVN'

W = 1
while True:
    com = common(human,mosq,W)
    if len(com) == 0:
        break
    com_long=com
    W += 1
print(com_long)
    
