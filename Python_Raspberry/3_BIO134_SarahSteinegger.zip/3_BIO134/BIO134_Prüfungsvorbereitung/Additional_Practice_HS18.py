# -*- coding: utf-8 -*-
"""
Created on Thu Aug 15 20:33:52 2019

@author: sara
"""

# Sara Steinegger
# 15.08.2019





# WEEK 2
# Problem 1
n = 4
for i in range(n):
    print(i*3, i*3+4)
print()
#for i in range(n):
    #n1 = i*3
    #n2 = n1+4
    #print(n1, n2)
#print()

# Solution
n = 4
for i in range(0, 3*n, 3):
    print(i, i+4)
    

# Problem 2
n = 12
m = 5000
for i in range(n):
    i = m*0.02
    m += i
print(m)

# Solution
n = 12
saving = 5000
for i in range(n):
    saving = saving*1.02
print(saving)


# Problem 3
n = 21
f = 1
for i in range(1, n+1):
    f *=i
print(f, "\n")

# Solution
n = 21
fact = 1
for i in range(1, n+1):
    fact *= i
print('factorial:', fact)

 
# Problem 4
#lys = [3, 4, 5, 2]
lys = [14, 165, 823, 34, 91653, 132, 9365, 1543, 129,\
       3765, 28764, 92846, 1649, 26, 291]
s = 0
for i in range(len(lys)):
    s += lys[i]
print(s, "\n")

# Solution
#lys = [3, 4, 5, 2]
lys = [14, 165, 823, 34, 91653, 132, 9365, 1543, 129,\
       3765, 28764, 92846, 1649, 26, 291]
summe = 0
for number in lys:
    summe += number
print('summe:', summe, "\n")


# Problem 5
lys = ['hi', 'sunny', 'strange', 'start',\
       'well', 'happy', 'start', 'done']
for word in lys:
    print(word)
print()
print("After modification 1:")
c = 0
for word in lys:
    if word == "start":
        c = 1
    if c == 1:
        print(word)
print()

# Solution 1
lys = ['hi', 'sunny', 'strange', 'start', 'well', 'happy', 'start', 'done']
for word in lys:
    print(word)
print()
print('after modification 2:')
flag = 0
for word in lys:
    if word == 'start':
        flag = 1
    if flag == 1:
        print(word, )
print()

# Solution 2
#problem 5: flag is a boolean instead of an integer as in 2_5a.py
lys = ['hi', 'sunny', 'strange', 'start', 'well', 'happy', 'start', 'done']
for word in lys:
    print(word)
print()
print('after modification 3:')
flag = False
for word in lys:
    if word == 'start':
        flag = True
    if flag:
        print(word)
print()





# WEEK 3
# Problem 1
import numpy.random as rd
rd.seed(0)
n = 10
sequence = []
for i in range(n):
    sequence.append(rd.randint(1, 16))
print("First number of the sequence:", sequence[0])
print("Last number of the sequence:", sequence[-1], "\n")

# Soultion
import numpy.random as rd
rd.seed(0)
for i in range(10):
    print(rd.randint(1, 16))
print()

# Problem 2
import numpy.random as rd
rd.seed(0)
n = 300
sequence = []
counter = 0
for i in range(n):
    r = rd.randint(1, 16)
    sequence.append(r)
    if r==4:
        counter += 1
print("Number of occurencees:", counter, "\n")

# Solution
import numpy.random as rd
rd.seed(0)
fours = 0
for i in range(300):
    r = rd.randint(1, 16)
    if r == 4:
        fours += 1
print(fours, "\n")


# Problem 3
lys = [8, 12, 4, 3, 20, 5, 2]
lys = [3746453728292834648473, 37363536774847463524, 857575656454534436353,\
       9958585746363588374, 3635252424253636371423, 37362626262514425262, 83737362625252242425, 38373736225252425253]
m = 0
for i in range(len(lys)):
    if lys[i]>m:
        m = lys[i]
print("Lagest number in the list:", m)
print()

# Solution
#lys = [8, 12, 4, 3, 20, 5, 2]
lys = [3746453728292834648473, 37363536774847463524, 857575656454534436353, 9958585746363588374, 
       3635252424253636371423, 37362626262514425262, 83737362625252242425, 38373736225252425253]
maximum = 0
for number in lys:
    if number > maximum:
        maximum = number
print(maximum, "\n")


# Problem 4
bases = ["A", "T", "C", "G"]
counter = 0
for base1 in bases:
    for base2 in bases:
        counter += 1
        print(counter, base1 + base2)
print()

# Solution
bases = ['A','T','C','G']
for base1 in bases:
    for base2 in bases:
        print(base1+base2)
print()

# Problem 5
#lys = [1, 1, 0, 0, 1, 0, 0, 0, 1, 0]
lys = [0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0 ,1, 0, 1, 0, 1, 0, 1, 0, 1, 0,\
       1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0 ,0 ,0, 0, 1, 0, 1, 1, 0, 0, 1, 0]        
zeros = 0
for number in lys:
    if number == 0:
        zeros +=1
    else:
        zeros = 0
    print(zeros, end=" ")

# Solution
lys = [1, 1, 0, 0, 1, 0, 0, 0, 1, 0]
lys = [0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0 ,1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 
       1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0 ,0 ,0, 0, 1, 0, 1, 1, 0, 0, 1, 0]
zeros = 0
for number in lys:
    if number == 0:
        zeros += 1
    else:
        zeros = 0
    print(zeros, end=' ')
print("\n")




# WEEK 4
# Problem 1
#lys1 = [6, 7, 8]
#lys2 = [5, 2, 1]
lys1 = [9, 12, 45, 12, 398, 24, 76, 21, 11, 12, 198, 87, 876, 34]
lys2 = [187, 23, 435, 761, 73, 3, 4, 987, 32, 46, 98, 107, 45, 1]
lys3 = [0]*len(lys1)
for i in range(len(lys1)):
    lys3[i] = lys1[i]*lys2[i]
print("Sum of lys3:", sum(lys3))
print()

# Solution
#lys1 = [6, 7, 8]
#lys2 = [5, 2, 1]
lys1 = [9, 12, 45, 12, 398, 24, 76, 21, 11, 12, 198, 87, 876, 34]
lys2 = [187, 23, 435, 761, 73, 3, 4, 987, 32, 46, 98, 107, 45, 1]

lys3 = len(lys1)*[0]
for i in range(len(lys1)):
    lys3[i] = lys1[i] * lys2[i]
#print(lys3)
print(sum(lys3))
print()


# Problem 2
import numpy.random as rd
rd.seed(4)
lys_r = []
r = 0
while r != 12:
    r = rd.randint(1,13)
    if r != 12:
        lys_r.append(r)
print(lys_r[-1])
print()

# Solution
import numpy.random as rd
rd.seed(4)
r = 0
while r!=12:
    r = rd.randint(1,13)
    print(r)
print()   

# Problem 3
lys1 = [7, 5, 43, 7, 90, 4, 6, 49, 2]
lys2 = [5, 46, 8, 20, 57, 9, 8, 2, 3]
lys3 = [0]*len(lys1)
for i in range(len(lys1)):
    if i < 4:
        lys3[i] = lys1[i]+lys2[i]
    else:
        lys3[i] = lys1[i]*lys2[i]
print("Sum of the elements in the new list (lys3):", sum(lys3), "\n")

# Solution
lys1 = [7, 5, 43, 7, 90, 4, 6, 49, 2]
lys2 = [5, 46, 8, 20, 57, 9, 8, 2, 3]
lys3 = 9 * [0]
for i in range(9):
    if i <= 3:
        lys3[i] = lys1[i] + lys2[i]
    else:
        lys3[i] = lys1[i] * lys2[i]
#print(lys3)
print(sum(lys3))


# Problem 4
import numpy.random as rd  
rd.seed(0)
sums = []
for i in range(5):
    s = 0
    for i in range(10):
        r = rd.randint(1,7)
        s += r
    sums.append(s)
print("The first sum i obtained:", sums[0])
print("The third sum i obtained:", sums[2])
n = 0
for number in sums:
    if number>35:
        n += 1
print("Sum that is larger than the expected sum of 35:", n)

# Solution
import numpy.random as rd
rd.seed(0)
for i in range(5):
    summe = 0
    for j in range(10):
        r = rd.randint(1,7)
        summe += r
    print(summe)
print()





# WEEK 5
# Problem 1
lys = ['apple', 'grape', 'strawberry', 'pear']
# Using "in"
c = 0
for fruit in lys:
    print(c, fruit)
    c += 1
print()
# Using "in range"    
for i in range(len(lys)):
    print(i, lys[i])
print()
# using enumerate
for i, fruit in enumerate(lys):
    print(i, fruit)
print()

# Solution
#problem 1
lys = ['apple', 'grape', 'strawberry', 'pear']
#option 1, enumerate:
for i, fruit in enumerate(lys):
    print(i, fruit)
#option 2, in range:
for i in range(len(lys)):
    print(i, lys[i])
#option 3, in:
i = 0
for fruit in lys:
    print(i, fruit)
    i += 1
print()


# Problem 2
lys = [['apple', 'grape', 'strawberry'], ['hi', 'hello'],\
       ['garden', 'flower', 'grass']]
c = 0
for i, sublist in enumerate(lys):
    for j in range(len(sublist)):
        print(c, lys[i][j])
        c += 1
#c = 0
#for i in range(len(lys)):
    #for j in range(len(lys[i])):
        #print(c, lys[i][j])
        #c += 1

# Solution
lys = [['apple', 'grape', 'strawberry'], ['hi', 'hello'], ['garden', 'flower', 'grass']]
ind = 0
for sublys in lys:
    for word in sublys:
        print(ind, word)
        ind += 1
lys = [['apple', 'grape', 'strawberry'], ['hi', 'hello'], ['garden', 'flower', 'grass']]
ind = 0
for i in range(len(lys)):
    for j in range(len(lys[i])):
        print(ind, lys[i][j])
        ind += 1
print()


# Problem 3
bases = ["A", "C", "G", "T"]
codons = []

for base1 in bases:
    for base2 in bases:
        for base3 in bases:
            if base1 != base2:
                codons.append(base1+base2+base3)
print(sorted(codons)[42])
print()

# Solution
bases = 'ATCG'
l = []
for b1 in bases:
    for b2 in bases:
        for b3 in bases:
            if b1 != b2:
                l.append(b1+b2+b3)
l.sort()
print(l[42])
print()


# Problem 4
numbers_fyle = open("some_numbers.txt", "r")
numbers = numbers_fyle.readlines()
numbers_fyle.close()
s = 0
for i in range(len(numbers)):
    numbers[i] = int(numbers[i].strip())
    s += numbers[i]
print("Sum:", s)

# Solution
fyle = open("some_numbers.txt")
l = fyle.readlines()
fyle.close()
summe = 0
for line in l:
    summe += int(line.strip())
print(summe)


# Problem 5
numbers_fyle1 = open("some_more_numbers.txt", "r")
numbers1 = numbers_fyle1.readlines()
numbers_fyle1.close()
s1 = 0
for i in range(len(numbers1)):
    numbers1[i] = numbers1[i].split()
    s1 += int(numbers1[i][1])
print("The sum of second numbers:", s1)

# Solution
fyle = open("some_more_numbers.txt")
l = fyle.readlines()
fyle.close()
summe = 0
for line in l:
    second_number = line.split()[1]
    summe += int(second_number)
print(summe)
print()





# WEEK 6
# Problem 1
marathon = {'Sarah': 3.89, 'Ron': 4.21, 'Louis': 3.62,\
            'Linda': 4.69, 'Marion': 5.20, 'Jack': 4.79,\
            'Mary': 3.34}
women = ['Marion', 'Linda', 'Sarah', 'Mary']
summe = 0
c = 0
for i, element in enumerate(women):
    summe += marathon[element]
    c += 1
m = summe/c
print("Mean:", m, "\n")

# Solution
marathon = {'Sarah': 3.89, 'Ron': 4.21, 'Louis': 3.62, 'Linda': 4.69, 'Marion': 5.20, 'Jack': 4.79, 'Mary': 3.34}
women = ['Marion', 'Linda', 'Sarah', 'Mary']
summe = 0
for name in women:
    summe += marathon[name]
print ('mean time:', summe/len(women))


# Problem 2
ages = {'Sarah': 23, 'Ron': 25, 'Louis': 23, 'Linda': 28,\
        'Marion': 21, 'Jack': 23, 'Mary': 25}
ages_r = {}
for name in ages:
    if ages[name] not in ages_r:
        ages_r[ages[name]] = []
    ages_r[ages[name]].append(name)
print(ages_r)
print()

# Solution
ages = {'Sarah': 23, 'Ron': 25, 'Louis': 23, 'Linda': 28, 'Marion': 21, 'Jack': 23, 'Mary': 25}
reverse = {}
for name in ages:
    age = ages[name]
    if age not in reverse:
        reverse[age] = []
    reverse[age].append(name)
print(reverse)

    
# Problem 3
#s = 'anckddjkwuslpe'
s = 'pwueofaevndakenadlkjaewqpnxmmmsncebewapadjsnjefhlajlajhliwsqapozujd'
s_new = ""
for i in range(0, len(s), 6):
    s_new += s[i:i+3].upper()
print(s_new)
print()

# solution
s = 'pwueofaevndakenadlkjaewqpnxmmmsncebewapadjsnjefhlajlajhliwsqapozujd'
snew = ''
for i in range(0,len(s),6):
    snew += s[i:i+3].upper()
print(snew)


# Problem 4
s = 'jnvhe***vnekjasbvk###jdndhdqv'
snew = s.partition("***")[2].partition("###")[0]
print(snew)
print()

# solution
s = 'jnvhe***vnekjasbvk###jdndhdqv'
snew = s.partition('***')[2].partition('###')[0]
print(snew)

# Problem 5
#l = [234, 1, 13]
l = [485, 38, 1, 948, 93, 43, 9243, 840, 46, 3, 814]
for number in l:
    print("{0:05d}".format(number), end="")
print()

# solution
#l = [234, 1, 13]
l = [485, 38, 1, 948, 93, 43, 9243, 840, 46, 3, 814]
s = ''
for i in range(len(l)):
    s += '{:05d}'.format(l[i])
print(s, "\n")





# WEEK 7
# Problem 1
def hi(name):
    print("Hi", name, ", how are you?")
hi("Christian")
hi ("Noemi")

# solution
def hi(name):
    print('Hi '+ name + ', how are you?')
hi('Christian')


# Problem 2
def hi2(name2):
    sentence = "Hi "+name2+", how are you?"
    return sentence
hi2('Martin')
print(hi2('Emma'))

# solution
def hi2(name):
    return 'Hi '+ name + ', how are you?'
hi2('Martin')
print(hi2('Emma'))


# Problem 3
def sum_product(a,b):
    summe = a+b
    product = a*b
    return summe, product
s, p = sum_product(3, 5)
print('sum:', s, 'product:', p)

# solution
def sum_product(a,b):
    return a+b, a*b
s, p = sum_product(3, 5)
print('sum:', s, 'product:', p)

# Problem 4
def list_new(l, n):
    for i in range(len(l)):
        l[i] += n
    return l
l1 = [9, 4, 1]
l2 = [9, 8, 3, 1]
print(list_new(l1,3))
print(list_new(l2, 5))

# solution
def add(l, a):
    for i in range(len(l)):
        l[i] += a
    return l
l1 = [9, 4, 1]
l2 = [9, 8, 3, 1]
print(add(l1, 3))
print(add(l2, 5))





# WEEK 8
# Problem 1
import numpy as np
def add_to_array(array):
    x = array.shape[0]
    y = array.shape[1]
    array[1:x-1,1:y-1] += 0.1      
    return array

#a = np.array([[0.1, 0.4, 0.2, 0.5], [0.6, 0.7, 0.5, 0.3], [0.9, 0.2, 0.2, 0.8]])
a = np.array([[0.13, 0.31, 0.49, 0.66, 0.63], [0.81, 0.26, 0.67, 0.31, 0.29],\
              [0.89, 0.62, 0.34, 0.64, 0.52], [0.54, 0.48, 0.28, 0.52, 0.51]])
anew = add_to_array(a)
print(np.sum(anew))



# Problem 2
import numpy as np
def shift_and_add(array):
    x = array.shape[0]
    y = array.shape[1]
    a_new = np.zeros(shape=(x-1,y), dtype=float)
    a_new[x,y] = a[x:x-1,y] + a[x+1:x-1,y]
    return a_new

a = np.array([[0.1, 0.3, 0.2, 0.5], [0.5, 0.5, 0.4, 0.3], [0.4, 0.1, 0.1, 0.1]])
anew = shift_and_add(a)
print(anew)
