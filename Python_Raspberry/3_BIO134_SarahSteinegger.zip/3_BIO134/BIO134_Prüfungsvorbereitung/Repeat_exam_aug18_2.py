# -*- coding: utf-8 -*-
"""
Created on Wed Aug 14 16:52:00 2019

@author: sara
"""

# Sara Steinegger
# 14.08.2019

# Repeat Exam August 2018



# Question 1
lys = ['g', 't', 's', 'r', 'q', 'c', 's', 'a', 'g']

for letter in lys:
    if letter != "s":
        print(letter)
    else:
        break
print()



# Question 2
lys = [[5, 2, 3], [2, 4], [5, 9, 3]]

for i in range(len(lys)):
    for j in range(len(lys[i])):
        lys[i][j] += 1
print(lys, "\n")



# Question 3
def sum_squares(n):
    sq = 0
    for i in range(1, n):
        sq += i**2
    return sq       
    
print(sum_squares(4), "\n")



# Question 4
lys = ['which', 'road', 'leads', 'to', 'Rome']

for i in range(len(lys), 0, -1):
    s = " ".join(lys[:i])
    n = len(s)
    print("{0:2d}. {1:.<24s} ?".format(n, s), "\n")



# Question 5
s = "Kate, when France is mine and I am yours\
then yours is France and you are mine"

d = {}
s_new = s.split()

for i, word in enumerate(s_new):
    if word not in d:
        d[word]= []
    d[word].append(i)
print(d)



# Question 6
#import numpy as np

#def reorganize(image):
    #x = image.shape[0]
    #y = image.shape[1]
    #i = np.zeros(shape=(x,y), dtype=float)
    #if x%2==0 and y%2==0:
        #i[0:int(x/2)+1, 0:int(y/2)+1] = image[int(x/2)+1:, int(y/2)+1:] # upper left
        #i[int(x/2)+1:, int(y/2)+1:] = image[0:int(x/2)+1, 0:int(y/2)+1] # lower right



# Question 7
def special_sort(lys):
    m = 0
    for word in lys:
        if len(word)>m:
            m = len(word)
    for i in range(m):
        for word in lys:
            if len(word)==i:
                print(word)
    return     
      
l = ['cows', 'are', 'eating', 'brown',\
     'grass', 'in', 'the', 'sun']
special_sort(l)
    