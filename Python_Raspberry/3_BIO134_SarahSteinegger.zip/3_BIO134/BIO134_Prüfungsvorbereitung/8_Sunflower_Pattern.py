# -*- coding: utf-8 -*-
"""
Created on Fri Aug 16 18:52:07 2019

@author: sara
"""

# Sara Steinegger
# 16.08.2019

# Sunflower pattern
from numpy import linspace, pi, cos, sin
import matplotlib.pyplot as pl

phi = (1+5**.5)/2
n = linspace(1,100,99)
x = n**.5 * cos(2*pi*phi*n)
y = n**.5 * sin(2*pi*phi*n)

pl.subplot(1,1,1)
pl.plot(x,y,'o',color='yellow',markeredgecolor='yellow')
R = 12
pl.xlim(-R,R)
pl.ylim(-R,R)

ax = pl.gca()   # stands for get-current-axes
ax.set_aspect('equal')
ax.xaxis.set_visible(False)
ax.yaxis.set_visible(False)
ax.set_facecolor("black")

pl.show()