#!/usr/bin/env python3
# -*- coding: utf-8 -*-

s1='MNENLFASFIAPTILGLPAAVLIILFPPLLIPTSKYLINNRLITTQQWLIKLTSKQMMTM\
HNTKGRTWSLMLVSLIIFIATTNLLGLLPHSFTPTTQLSMNLAMAIPLWAGTVIMGFRSK\
IKNALAHFLPQGTPTPLIPMLVIIETISLLIQPMALAVRLTANITAGHLLMHLIGSATLA\
MSTINLPSTLIIFTILILLTILEIAVALIQAYVFTLLVSLYLHDNT'

s2='MMTNLFSVFDPSTTILNLSLNWLSTFLGLLLIPFSFWLLPNRFQVVWNNILLTLHKEFKT\
LLGPSGHNGSTLMFISLFSLIMFNNFLGLFPYIFTSTSHLTLTLALAFPLWLSFMLYGWI\
NHTQHMFAHLVPQGTPPVLMPFMVCIETISNVIRPGTLAVRLTANMIAGHLLLTLLGNTG\
PMTTNYIILSLILTTQIALLVLESAVAIIQSYVFAVLSTLYSSEVN'

l1 = len(s1)
l2 = len(s2)
if l1 < l2:
    short = s1
    long = s2
else:
    short = s2
    long = s1

#it starts with the longest fragment and continues with smaller ones until it
#finds a match
found_seq = 0
for width in range(len(short),0,-1): #loop to generate fragments lengths
    for pos in range(len(long)-width+1):
        print(pos)#loop for generating slices of a sequence
        if long[pos:pos+width] in short:
            print (long[pos:pos+width])
            found_seq = 1
            break
    if found_seq == 1:
        break
    

            
