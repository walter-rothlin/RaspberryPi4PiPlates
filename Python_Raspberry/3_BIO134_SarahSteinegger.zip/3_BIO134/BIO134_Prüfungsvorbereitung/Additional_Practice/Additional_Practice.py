# -*- coding: utf-8 -*-
"""
Created on Wed Aug 14 15:10:42 2019

@author: sara
"""

# Sara Steinegger
# Additional Practice



# Question 1
s = "kenfaeniencdasjsbcealiuqeuzabcfcfcdsrs"
s_new = ""

for i in range(0, len(s), 4):
    s_new += s[i:i+2]
print(s_new, "\n")

    
    
# Question 2
l=['Your', 'care', 'is', 'gain', 'of',\
   'care', 'by', 'new', 'care', 'won']

for i,element in enumerate(l):
    if element == "care":
        print(l[i+1])
print()



# Question 3
l = [['Peter',25],[ 'Lisa',20],\
     [ 'Paul',21],[ 'Nina',20]]

d = {}

for i in range(len(l)):
    if l[i][1] not in d.keys(): # also possible: if l[i][1] not in d:
        d[l[i][1]] = []
    d[l[i][1]].append(l[i][0])
print(d)
        
        
        
        
        
        
        
    