# -*- coding: utf-8 -*-
"""
Created on Fri Aug 16 17:34:38 2019

@author: sara
"""

# Sara Steinegger
# 16.08.2019

# Plotting commands
import matplotlib.pyplot as pl
import numpy as np
import numpy.random as ran

halflife = 5.7
tau = halflife/np.log(2)

t = np.linspace(0,20,21)
n = np.exp(-t/tau)
dn = 0.1 * n**.5
noise = ran.standard_normal(len(n)) * dn
n += noise

# pl.plot(t,n,'o')
pl.errorbar(t,n,yerr=dn,marker='o',linestyle='none',label='Carbon 14')
pl.xlim(np.amin(t)-0.5,np.amax(t)+0.5)
pl.xlabel('Time (thousands of years)')
pl.ylabel('Relative abundance')
pl.legend()
pl.title('Radioactive decay')

pl.show()