# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 09:16:33 2019

@author: sara
"""

# Sara Steinegger
# 11.07.2019

# Hello Worls: Chapter 8
# Loop the Loop

# Two main kind of loops
# Counting loops: repeat a certain number of times
# Conditional loops: repeat until a certain thing happens
# (as long as a condition is true)



# Counting loops: for-loops
# Listing 8.1: A very simple for-loop
for looper in [1, 2, 3, 4, 5]:
    print("hello")

# Listing 8.2: Doing something diffrent each time through the for-loop
for looper in [1, 2, 3, 4, 5]:
    print(looper, end=" ")

# IMPORTANT: Runaway loops
# To stop a Runaway loop (endless loop/infinite loop) press CTRL-C



# Using counting loops
for looper in [1, 2, 3, 4, 5]:
    print(looper, "times 8 =", looper*8)



# A shortcut - range()
# range() creates a list containing a range of numbers.
# Instead of typing in two numbers, typing in only one number also works.
# Example: range(5) -> [0, 1, 2, 3, 4]
    
# Listing 8.4: A loop using range()
for looper in range(1, 5):
    print(looper, "times 8 =", looper*8)



# IMPORTANT: A string is like a list of characters.
# It's possible to loop through a string!!



# Counting by steps
# It's possible to counting by steps with an extra argument in range().
for i in range(1, 10, 2):
    print(i)

for i in range(5, 26, 5):
    print(i)

for i in range(10, 1, -1): # Counting backwards
    print(i)

# Listing 8.6: Ready for lift-off?
import time
for i in range(10, 0, -1):
    print(i)
    time.sleep(1)
print("BLAST OFF!")



# Counting without numbers
# Listing 8.7: Who's the coolest of them all?
for i in ["Spongebob", "Spiderman", "Justin Timberlake", "My dad"]:
    print(i, "is the coolest guy ever!")



# IMPORTANT: The for-loop is great if you know in advance how many times
# the loop has to run. The while-loop allows to run a loop until something
# happens. The while-lop is a conditional loop (Stops, when the condition
# it's no longer true).



# Conditional loops
# Listing 8.8: A conditional loop or while-loop
print("Type 3 to continue, anything else to quit.")
someInput = input()
while someInput == "3":
    print("Thank you for the 3. Very kind of you.")
    print("Type 3 to continue, anything else to quit.")
    someInput = input()
print("That's not 3, so I'm quitting now.")



# Bailing out of a loop - break and continue

# continue - jump ahead to next iteration of the loop
# (stop executing the current iteration of the loop and skip ahead to the
# next iteration)
# Listing 8.9: Using continue in a loop
for i in range(1, 6):
    print("i =", i, end=" ")
    print("Hello, how", en= " ")
    if i == 3:
        continue
    print("are you today?")
    
# break - stop the loop altogether
for i in range(1, 6):
    print()
    print("i =", 1, end=" ")
    print("Hello, how", end=" ")
    if i == 3:
        break
    print("are you today?")








    
    
    