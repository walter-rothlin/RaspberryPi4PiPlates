# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 10:32:30 2019

@author: sara
"""

# Sara Steinegger
# 11.07.2019

# Hello World: Chapter 9
# Just for you - Comments

# Comments are only for the programmer to read, not for the computer to execute.
# Comments are part of the program's documentation, and the computer 
# ignores them when it runs the program!



# Single-line comments
# This is a comment in a Python program
print("This is not a comment")



# End-of-line comments
# It's also possible to put comments at the end of a line of code!



# Multiline comments

# ************************
# This is a comment
# ************************

# An other way to make multiple comments are Triple-quoted strings
# whitout name.
"""Because the string has no name and the program isn't doing anything whith
the string, it has no effect on the program runs"""



# Commenting out
# Comments also can be used to temporarily exclude parts of the
# program from running!
