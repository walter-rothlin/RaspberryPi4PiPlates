# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 18:22:51 2019

@author: sara
"""

# Sara Steinegger
# 17.07.2019

# Print Formatting and Strings



# Vertical spacing
# Adding our own newlines
print("Hi")
print()
print("There")
# The easiest way to put a space between Hi and There is to add an
# extra print statement.

# Special printing codes
# An other way to add an extra line
# The code for a newline is \n
print("Hello \nWorld")



# Horizontal spacing - Tabs
# Tabs are useful for lining things up in columns.
print("ABC\tXYZ")

# Listing 21.1: A program to print squares and cubes
print("Number \tSquare \tCube")
for i in range(1, 11):
    print(i, "\t", i**2, "\t", i**3)



# How do we print a backslash?
# The trick is just to put two of them together
print("hi\\there")



# Inserting variables in strings
# Until now
name = "Sara Steinegger"
print("My name is", name, "and i wrote this notes.")
# A Way to insert variables into strings that gives more control
# over how they'll look, especially numbers.
print("My name is %s and I worte this book" %name)
# %s for strings
# %i for integers
# %f for floats
# They are called format strings



# Number formatting
# Example
dec_number = 12.3456 
print("It is %.2f degree today." %dec_number) # It's rounded

# Integers: %d or %i
number = 12.67 
print("%i" %number) # It's turncated
print(number)
# The numer is still the same; We changed just the way of printing!

# Floating point numbers: %f or %F
# For decimal numbers %f or %F can be used
# If %f is used by itself, the number will be displayedwith six
# six decimal places.
dec_number = 12.3456 
print("It is %.8f degree today." %dec_number) # It's rounded

# If the number is negativ, %f will always display the - sign.
dec_number = -5.76
print("%0.2f" %dec_number)
# Add a +
dec_number = 12.3456 
print("%+.4f" %dec_number)



# E-notation: %E or %e
number = 12.3456
print("%e" %number)
print("%.3e" %number)
print("%.8e" %number)

# Automatic float or E-notation: %g and %G
# Python choose automatically between float notation and
# E-notation.
number1 = 12.3
number2 = 456712345.6
print("%g" %number1)
print("%g" %number2)



# How do we print a percent sign?
# The percent sign (%) is a special character for format strings.
# How to make a % sign print?
# Python is smart enough to figure out when % is a sign to start a format string
# and when you just want to print one.
print("I got 90% of m math test")

# IMPORTANT: If you are using format strings and want to print a % sign
# You use two percent sign at the end of the format string
# (like the two backslashes).
math = 75.4
print("I got %.1f%% on my math test" %math)



# More than one format string
math = 75.4
science = 82.1
print("I got %.1f in math and %.1f in science" %(math, science))
# You can put as many format strings as you want in the print statement and
# then a tuple of variebles you want to print.



# Storing formatted numbers - assign it to a variable
my_string = "%.2f" %12.3456
print("The answer is:", my_string)



# Formatting - the new way
# The format() method
# Example 1
print("I got {0:.1f} in math, {1:.1f} in science".format(math, science))
# Example 2
distance = 149597870700
print("The sund is {0:.4e} meters from the earth.".format(distance))
# Example 3
print("I got {0:.1f}% in math.".format(math))



# Strings 'n' things - .split()
# Strings are objects n Python and they have their own methods
# for doing things like searching, splitting and combining.

# Splitting strings
# Creates a list and the split marker get thrown away
name_string = "Sam,Brad,alex,Cameron,Toby,Gwen,Jenn,Connor"
names = name_string.split(",")
print(names)
for name in names:
    print(name)
# If you don't give Python a split marker, it'll split the string any whitespace:



# Joining strings - .join()
# REMEMBER: Concatenating (Add two strings together with +)
word_list = ["my", "name", "is", "Sara"]
long_string = " ".join(word_list)
print(long_string)
# The string in front of join() is used as the glue to
# hold the other strings together.



# Searching for strings - startswith()
# The startswith() method tells you whether a string starts with a 
# certain character or characters.
name = "Frankenstein"
print(name.startswith("F"))
print(name.startswith("Frank"))
print(name.startswith("Flop"))
# startswith() returns True or False as value -
# use it in comparisons or if  statements!
if name.startswith("Frank"):
    print("Can I call Frank?")
    
# The endswith() method tells you wether a string ends with a
# certain character or characters
name = "Frankenstein"
print(name.endswith("n"))
print(name.endswith("stein"))
print(name.endswith("stone"))
# This two methods work really well for finding things at the
# start or end of a string.



# Searching anywhere in a string: in and index()
# But what if you want to find something in middle of a string?
# We use the keyword in to check whther a certain item is in the list.
# The keyword in just tells you whether
# the substring is somewhere in the string.
addr1 = "657 Maple Lane"
if "Maple" in addr1:
    print("That address has 'Maple' in it.")
# index() tells you where in the bigger string the smaller string starts!
addr1 = "657 Maple Lane"
if "Maple" in addr1:
    position = addr1.index("Maple")
    print("Found 'Maple' at index", position)
# First check if the substring is in the string and
# than searching for the index. If you searching for the index 
# of a substring which isn't in the string you'll get an error.



# Removing a part of a string - .strip()
name = "Sara Steinegger"
short_name = name.strip("er")
print(short_name)
# If you don't tell strip() what to strip off,
# it'll strip off any whitespace.



# Changing case
# lower()
string1 = "Hello"
string2 = string1.lower()
print(string2)
# upper()
string3 = string1.upper()
print(string3)

    












