# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 09:16:51 2019

@author: sara
"""

# Sara Steinegger
# 17.07.2019

# Objects
# Objects have attributes ("things you know"/properties) and methodes
# ("things you can do").

# Objects have:
# Things that you can do to them (actions)
# Things that describe them (attributes or ptoperties)

# What are attributes?
# Attributes are chunk of information (numbers, strings and so on.)
# You can display them$
print(ball.size)
# You can assign values to them
ball.color = "green"
# You can assign them to regular, non-object variables
myColor = ball.color
# You also can assign them to attributes in other objects
myBall.color = yourBall.color

# What are methods?
# Methods are functions that are included inside the object



# Object = attributes + methods
# Attributes are information
# Methods are actions
# object.attribute
# object.method()



# In Python the description or blueprint of an object is called a
# class. The second step is to use the class to make an actual object.
# The object is calles instance of that class.



# Listing 14.1: Creating a simple Ball class
class Ball:
    def bounce(self):
        if self.direction == "down":
            self.direction = "up"



# Creating an instance of an object
myBall = Ball()
# Add some attributes
myBall.direction = "down"
myBall.color = "green"
myBall.size = "small"



