# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 15:17:24 2019

@author: sara
"""

# Sara Steinegger
# 10.07.2019

# Hello World: Chapter 2

# Assign a value to a name (store a value in a variable)
teacher = "Mr. Morton"
print(teacher)

# Note the differnece between this two!
print("53 + 28")
print(53 + 28)

# More Examples with variables
first = 5
second = 3
print(first + second)
third = first + second
print(third)

# More than one name for the same thing
myTeacher = "Mrs. Goodyear"
yourTeacher = myTeacher
print(myTeacher)
print(yourTeacher)

# Strings and values
first = 5 # Here 5 and 3 are values/numbers
second = 3
print(first + second)

first ="5" #Here 5 and 3 are strings
second ="3"
print(first + second) # Python concatenate two strings!
# For a string that spend more than one line a triple_quoted string
# can be used!
