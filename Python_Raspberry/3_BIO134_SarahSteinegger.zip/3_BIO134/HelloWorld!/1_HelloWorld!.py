# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 08:22:02 2019

@author: sara
"""

# Sara Steinegger
# 09.07.2019

# Hello World: Getting started
# First Instructions
print("Hello World!")
print(5+3)
print(5*3)
print(2345*6789)
print("Cat"+"Dog")
print("Hello "*20)


# Listing 1.1
print("I love pizza!")
print("pizza "* 20)
print("yum "* 40)
print("I'm full!")


# Listing 1.2
import random
secret = random.randint(1, 99)
guess = 0
tries = 0
print("AHOY! I'm the Dread Pirate Roberts, and I have a secret!")
print("It is a number from 1 to 99. I'll give you 6 tries.")

while guess != secret and tries<6:
    guess = input("What's yer guess?")
    if guess<secret:
        print("Too low, ye scurvy dog!")
    elif guess>secret:
        print("too high, landlubber!")
    tries += 1

if guess == secret:
    print("Avast! Ye got it! Found my secret, ye did!")
else:
    print("No more guesses! Better luck next time, matey!")
    print("The secret number was", secret)