# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 08:12:11 2019

@author: sara
"""

# Sara Steinegger
# 11.07.2019

# Hello World: Chapter 7
# Decisions, Decisions (branching)



# Listing 7.1: Using the comparison operators
num1 = float(input("Enter the first number:"))
num2 = float(input("Enter the second number:"))
if num1 < num2:
    print(num1, "is les than", num2)
if num1 > num2:
    print(num1, "is greater than", num2)
if num1 == num2:
    print(num1, "is equal to", num2)
if num1 != num2:
    print(num1, "is not equal to", num2)
    
    

# Python does something, when the if-statement is true! But what does it
# do if the test is false? In Python there are three possibilities:    
# 1. Do another test, with the keyword elif() (else if)

# 2. Do something else, with the keyword else(). This always goes at the end
# (after() elif and else()).

# 3. Move on (the program will continue to the next line of code - if there
# is one- or will end - if there is no more code).



# Testing for more than one condition
age = float(input("Enter your age:"))
grade = int(input("Enter your grade:"))
if age >= 8:
    if grade >= 3:
        print("You can play this game.")
else:
    print("Sorry, you can't play the game.")



# Using "and"
# Combine conditions with "and"
# All conditions have to be true!
age = float(input("Enter your age:"))
grade = int(input("Enter your grade:"))
if age >= 8 and grade >= 3:  
    print("You can play this game.")
else:
    print("Sorry, you can't play the game.")
        
# Combine more than one condition with and
age = float(input("Enter your age:"))
grade = int(input("Enter your grade:"))
color = input("Enter your favorite color:")
if age >= 8 and grade >= 3 and color == "green":  
    print("You can play this game.")
else:
    print("Sorry, you can't play the game.")



# Using "or"
# The block is executed if any of the conditions are true!
color = input("Enter your favorite color:")
if color == "red" or color == "blue" or color =="green":
    print("You are allowed to play this game.")
else:
    print("Sorry, you can't play this game.")



# using "not"
# Flip around the comparison to mean the opposite
# Example:
# if not(age < 8):
# means the same as
# if age >= 8












        
    

    