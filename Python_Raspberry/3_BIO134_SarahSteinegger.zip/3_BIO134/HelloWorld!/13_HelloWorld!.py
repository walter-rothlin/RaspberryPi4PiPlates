# -*- coding: utf-8 -*-
"""
Created on Mon Jul 15 11:20:45 2019

@author: sara
"""

# Sara Steinegger
# 15.07.2019

# Hello World: Chapter 13
# Functions

# Functions, Obejcts and Modules
# Functions are like building blocks of code
# that you can use over and over again.
# Objects are a way of describing pieces of your 
# program as self-containes units.
#  Modules are just separate files that contain parts of 
# your program.



# A function is a chunk of code that does something.
# It's a small piece that you can use to build a bigger program.



# Create a function
# Create a function with Python's def keyword.
# Listing 13.1: Creating and using function
def MyAddress():
    print("Sara Steinegger")
    print("Bülachhof 1, Wg22")
    print("8057 Zürich")
    print("Schweiz")
MyAddress()
print("Done the function")

# Passing arguments to a function
# Listing 13.2: Passing an argument to a function
def Address1(name):
    print(name)
    print("Guggusstrasse 2")
    print("8840 Einsiedeln")
    print("Schweiz")
Address1("Sara Steinegger")

# Functions with more than one argument
# Listing 13.3: Functions with two arguments
def Address2(name, houseNum):
    print(name)
    print("Guggusstrasse", houseNum)
    print("8840 Einsiedeln")
    print("Schweiz")
Address2("Sara Steinegger", "02")
Address2("Salome Steinegger", "03")
# How many is too many?
# Perhaps collect all the arguments in a list
# and then pass the list to the function.



# Functions that return a value
# returning a value
def calculateTax1(price, tax_rate):
    taxTotal = price + (price*tax_rate)
    return taxTotal

totalPrice = calculateTax1(7.99, 0.06)
print(calculateTax1(7.99, 0.06))
total = calculateTax1(7.99, 0.06) + calculateTax1(6.59, 0.08)
calculateTax1(7.49, 0.07)
print(totalPrice, total)



# Listing 13.4: Creating and using a function that returns a value
def calculateTax2(price, tax_rate):
    total = price + (price*tax_rate)
    return total

my_price = float(input("Enter a price:"))
total_price = calculateTax2(my_price, 0.06)
print("price = ", my_price, "Total price = ", total_price)



# Listing 13.6: Using a global variable inside a function
def calculateTax2(price, tax_rate):
    total = price + (price*tax_rate)
    print(my_price)
    return total

my_price = float(input("Enter a price:"))
total_price = calculateTax2(my_price, 0.06)
print("price = ", my_price, "Total price = ", total_price)
# Global variables can bee used as lang as 
# the function don't change it.
#  If any part of the function tries to change the variable,
# Python creates a new local variable instead.



# Listing 13.7: Try to modify a global variable inside a function
def calculateTax2(price, tax_rate):
    total = price + (price*tax_rate)
    my_price = 10000
    print("my_price (inside function):", my_price)
    return total

my_price = float(input("Enter a price:"))
total_price = calculateTax2(my_price, 0.06)
print("price = ", my_price, "Total price = ", total_price)
print("my_price (outside function):", my_price)



# IMPORTANT: Python creates a new local variable instead
# of changing the global variable, when changing the 
# global variable inside the function!
# With the keyword global , global variables can be changed
# in functions
def calculateTax2(price, tax_rate):
    total = price + (price*tax_rate)
    global my_price = 10000
    print("my_price (inside function):", my_price)
    return total

my_price = float(input("Enter a price:"))
total_price = calculateTax2(my_price, 0.06)
print("price = ", my_price, "Total price = ", total_price)
print("my_price (outside function):", my_price)








