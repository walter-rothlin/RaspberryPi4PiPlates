# -*- coding: utf-8 -*-
"""
Created on Sat Jul 13 10:01:53 2019

@author: sara
"""

# Sara Steinegger
# 13.07.2019

# Hello World: Chapter 12
# Collecting things together - Lists and dictionaries

# What's a list?
# Example
# The individual things inside lists are calles items.
family = ["Mom", "Dad", "Junior", "Baby"]
print(family)

luckyNumbers = [2, 7, 14, 26, 30]
print(luckyNumbers)



# Creating a list
# Creating an empty list
newList = []

# Adding things to a list
# Use append() to add things to a list
# (add something to the end)
friends = []
friends.append("David")
friends.append("Mary")
print(friends)



# IMPORTANT: Lists can hold any kind of data that Python can store
# (numbers, strings, objects, other lists, etc.)



# Learning more about lists
# getting items from a list
letters = ["a", "b", "c", "d", "e", "f", "g"]
print(letters[0]) # The index start from 0
print(letters[3])

# Slicing a list
print(letters[1:4])
# Slicing a list gives back a smaller list
print(type(letters[1])) # Gives back an item
print(type(letters[1:2])) # Gives back a smaller copy of the list

# Slice shorthand
print(letters[:2]) # include the start of a list
print(letters[2:]) # include the end of the list
print(letters[:]) # whole list (COPY OF THE ORIGINAL LIST)

# Modifying items
letters[2] = "z"
print(letters)
letters[2] = "c"

# Other ways of adding to a list
# append() adds one item to the end of a list
letters.append("n")
print(letters)
letters.append("o")
print(letters)
# extend() adds multiple items to the
#end of the list
letters.extend(["p", "q", "r"])
print(letters)
# insert() adds one item somewhere in the list,
# not necessarily at the end
letters.insert(2, "z")
print(letters)

# IMPORTANT: The difference betwen append() and extend()
# extend()
lys1 = ["a", "b"]
lys1.extend(["c", "d", "e"]) 
print(lys1) # Adds the items to the original list
# append()
lys1 = ["a", "b"]
lys1.append(["c", "d", "e"]) 
print(lys1) # Creats a list in a list
# insert() works the same way as append()
# except that you tell it where to put the new item.

# Deleting from a list
# remove() deletes the item of choose from the list
letters = ["a", "b", "c"]
letters.remove("c")
print(letters)
# Delite an item from the list using the index: del
letters = ["a", "b", "c"]
del letters[2]
print(letters)
# pop() takes the last item off the list and
# gives it back
letters = ["a", "b", "c"]
lastLetter = letters.pop()
print("The list letters:", letters)
print("The last letter:", lastLetter)
# pop() gives back the last item and removes it
# from the list.
# pop(n) gives the item at that index and removes
# it from the list.



# Searching a list
# The in keyword
if "a" in letters:
    print("found 'a' in letters")
else:
    print("didn't find 'a' in letters")
# Finding the index
letters = ["a", "b", "c"]
print(letters.index("c"))



# Looping through a list
letters = ["a", "b", "c", "d", "e"]
for letter in letters:
    print(letter)



# Sorting lists
letters = ["d", "a", "e", "c", "b"]
letters.sort()
print(letters)
# Sorting in reverse order
letters = ["d", "a", "e", "c", "b"]
letters.reverse()
print(letters)
# It's also possible to do this with this function
letters = ["d", "a", "e", "c", "b"]
letters.sort(reverse=True)
print(letters)



# Sorting a list modifies the original list
# Use the slice function to create a copy of the
# original list and modify the copy to preserve the 
# original list from beeing modidied.
original_list = ["Tom", "James", "Sarah", "Fred"]
new_list = original_list[:]
new_list.sort()
print(original_list)
print(new_list)



# An other way to sort - sorted()
# The sorted function gives a sorted
# copy of the original list.
original = [5, 2, 3, 1, 4]
new = sorted(original)
print(original)
print(new)



# Mutable and immutable
# In Python numbers and strings are immutable
# (can no been changed), and lists are mutable
# (can be changed).



# Tuble an immutable list
my_tuple = ("red", "green", "blue")
# Use round brackets, instead of square ones that
# lists use.



# Lists of lists: table of data
joeMarks = [55, 63, 77, 81]
tomMarks = [65, 61, 67, 72]
bethMarks = [97, 95, 92, 88]

mathMarks = [55, 65, 97]
scienceMarks = [63, 61, 95]
readingMarks = [77, 67, 92]
spellingMarks = [81, 72, 88]

classMarks = [joeMarks, tomMarks, bethMarks]
print(classMarks)
# Gives a list of items,
# where each item is itself a list.
for studentMarks in classMarks:
    print(studentMarks)
   
# Getting a single value from the table
print(classMarks[0][2])



# Dictionaries
# A Python dictionary is a way of associating
# two things to each other (key and value):
# Create a dictionary
phonenumbers = {}
# Add an entry
phonenumbers["John"] = "555-1234"
phonenumbers["Mary"] = "555-6789"
phonenumbers["Bob"] = "444-4321"
phonenumbers["Jenny"] = "867-5309"
print(phonenumbers)
print(phonenumbers["Mary"])



# The keys() method gives a lis of all keys
phonenumbers.keys()
# The values() methode gives a list of all values
phonenumbers.values()



# IMPORTANT: Keys can only be immutable types (booleans,
# integers, floats, strings and tuples).
# Lists or dictionaries are not possible as keys,
# because they are mutable types.



# "Sorting" a dictionary
# Display the items in order of the keys
for key in sorted(phonenumbers.keys()):
    print(key, phonenumbers[key])
# Display the items in order of the values
for value in sorted(phonenumbers.values()):
    for key in phonenumbers.keys():
        if phonenumbers[key] == value:
            print(key, phonenumbers[key])



# Find out if a key exists in the dictionary using in
print("Bob" in phonenumbers)
print("Barb" in phonenumbers)
# Delete an item using del
del phonenumbers["John"]
print(phonenumbers)
# Delete all items (clear the dictionary) using cleare()
phonenumbers.clear()
print(phonenumbers)
            
        






