# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 07:32:36 2019

@author: sara
"""

# Sara Steinegger
# 11.07.2019

# Hello World: Chapter 5
# Input (built-in function)

# IMPORTANT
# The input() function ALWAYS gets a string from the user.
# Use int() or float() to create a number.



# Useful information: The print() command and end=" "/end=""
# "Don't jump down to the next line after you print this".
print("Enter your name:", end=" ")
name = input()

print("My", end=" ")
print("name", end=" ")
print("is", end=" ")
print("Sara.")



# Listing 5.1
print("Enter your name:")
name = input()
print("Hi", name, "how are you today?")
# A shorter way to do the same
name = input("Enter your name:")



# Listing 5.3
print("This program converts Fahrenheit to Celsius")
print("Type in a temperature in Fahrenheit:", end=" ")
fahrenheit = float(input())
celsius = (fahrenheit - 32) * float(5)/9
print("That is", celsius, "degrees Celsius")


# That's for Python 2 -> Python 3?????????????
# Input from the Web
# Listing 5.4: Getting Input from a file on the Web
import urllib2
file = urllib2.urlopen("http://helloworldbook2.com/data/message.txt")
message = file.read()
print(message)



# Try it out
# 1
f_name = input("What's your first name?")
l_name = input("What's your last name?")
print("So, your name is really:", f_name, l_name)