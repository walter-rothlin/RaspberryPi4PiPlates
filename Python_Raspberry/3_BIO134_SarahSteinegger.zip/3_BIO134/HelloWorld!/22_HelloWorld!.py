# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 14:50:52 2019

@author: sara
"""

# Sara Steinegger
# 16.07.2019

# Hello World: Chapter 22
# File Input and Output

# Open a file with the built-in function open()
my_file = open("my_filename.txt", "r")



# Reading a file
# If you'll be using the file as input,
# you'llopen the file for reading.
my_file = open("my_filename.txt", "r")
# To read lines of text from a file, you can use
# the readlines() method.
lines = my_file.readlines()
# This will read the whole file and make a list,
# with one line of text in each item of the list.
# Example
# Listing 22.1: Opening and reading from a file
my_file = open("notes.txt, "r")
lines = my_file.readlines()
print(lines)
my_file.close() # Don't forget to close the file!

# Reading one line at a time
#readline() reads just one line at a time
first_line = my_file.readline()
# Listing 22.2: Using readline() more than once
my_file = open("notes.txt", "r")
first_line = my_file.readline()
second_line = my_file.readline()
print("First line:", first_line)
print("Second line:", second_line)
my_file.close()
# readline() doesn't put the result into a list!

# Going back to the start
# If you use readline() a few times and you want to start back
# at the beginning of the file, you can use the seek() methode
first_line = my_file.readline()
second_line = my_file.readline()
my_file.seek(0)
first_line_again = my_file.readline()



# Writing a file
# If you'll be creating a brand-new file or replacing an  existing
# file with something brand new, you'll open the file for writing.
# This means starting a new file or overwriting an existing one.
my_file = open("notes.txt", "w")

# Listing 22.4: Using write mode on a new file
new_file = open("my_new_notes.txt", "w")
new_file.write("Eat supper\n")
new_file.write("Play soccer\n")
new_file.write("Go to bed\n")
new_file.close()

# Listing 22.5: Using write mode on an existing file
the_file = open("notes.txt", "w")
the_file.write("Wake up\n")
the_file.write("Watch cartoons")
the_file.close()

# Writing to a file: Using print()
my_file = open("new_file.txt", "w")
print(>> my_file, "Hello there, neighbor!")
my_file.close()
# Appending a file
# If you'll be adding to an existing file, you'll open for appending.
# This means adding to an existing file and keeping what's already there!
my_file = open("notes.txt", "a")
# If you really wnat to append something to a file
# the file has to exist. Otherwise use "w" -> Creates a new file
my_file.write("\nSpend allowance")
my_file.close()

