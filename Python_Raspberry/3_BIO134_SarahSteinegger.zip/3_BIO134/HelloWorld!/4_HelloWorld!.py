# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 16:56:52 2019

@author: sara
"""

# Sara Steinegger
# 10.07.2019

# Hello World: Chapter 4
# Types of Data



# Changing types (built-in functions)
# float() will create a new float from a string or an integer.
# int() will create a new integer from a string or float
# str() will create a new string from number (or any other type).
 
# Changing an integer into a float
# Python creates a new variable (b)
# and assigns the float of variable to it.
a = 24
b = float(a)
print(a)
print(b)

# Changing a float into an integer
c = 38.0
d = int(c)
print(c)
print(d)

e = 54.99 # Note: The int() built-in function always rounds down.
f = int(e) # Id doesn't give the nearest integer, it gives the next lowest integer.
print(e)
print(f)

# Changing a string to a float
a = "76.5"
b = float(a)
print(a)
print(b)



## Getting more information: type()
a = "44.2"
b = 44.2
print(type(a))
print(type(b))

