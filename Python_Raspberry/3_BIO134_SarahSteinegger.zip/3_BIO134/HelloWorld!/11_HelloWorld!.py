# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 20:43:51 2019

@author: sara
"""

# Sara Steinegger
# 12.07.2019

# Hello World: Chapter 11
# Nested and Variable Loops

# Listing 11.1
for multiplier in range(5, 8):
    for i in range(1, 11):
        print (i, "x", multiplier, "=", i*multiplier)
    print()

# Example Nested loops
numStars = input("How many stars want you?") # int()-function also here possible
for i in range(1, int(numStars) + 1):
    print("*", end="")
# An other way to do the same thing is:
numStars = input("How many stars want you?")
for i in range(0, int(numStars)):
    print("*", end="")


# Listing11.2
# A variable nested loop
# It's just a nested loop when one or more of the loops uses a
# variable in the range() function (variable nested loops)
numLines = int(input("How many lines of stars do you want?"))
numStars = int(input("How many stars per line?"))
for line in range(0, numLines):
    for star in range(0, numStars):
        print("*", end="")
    print()
# The second print command is needed to start a new line of stars!



# Listing 11.3
# Blocks of stars with double-nested loops
numBlocks = int(input("How many blocks of stars do you want?"))
numLines = int(input("How many lines in each block?"))
numStars = int(input("How many stars per line?"))
for block in range(0, numBlocks):
    for line in range(0, numLines):
        for star in range(0, numStars):
            print("*", end=" ")
        print()
    print()



# Listing 11.4
# A trickier version of blocks of stars
numBlocks = int(input("How many blocks of stars do you want?"))
for block in range(1, numBlocks+1):
    for line in range(1, block*2):
        for star in range(1, (block+line)*2):
            print("*", end=" ")
        print()
    print() 



# Listing 11.5
# Printing the loop variables in nested loops
numBlocks = int(input("How many blocks of stars do you want?"))
for block in range(1, numBlocks+1):
    print("block=", block)
    for line in range(1, block*2):
        for star in range(1, (block+line)*2):
            print("*", end=" ")
        print("line =", line, "star =", star)
    print()



# IMPORTANT: nested loops are good to figuring out all the possible
# permutations (mathematical term means a unique way of combining a
# set of lines; the order does matter) and combinations (the order does't
# matter)of a series of decision!

# Listing 11.6
# Hot dog combinations
print("\tDog \tBun \tKetchup\tMustard\tOnions")
count = 1
for dog in [0, 1]:
    for bun in [0, 1]:
        for ketchup in [0, 1]:
            for mustard in [0, 1]:
                for onion in [0, 1]:
                    print("#", count, "\t",end=" ")
                    print(dog, "\t", bun, "\t", ketchup, "\t", end=" ")
                    print(mustard, "\t", onion)
                    count += 1



# Listing 11.7
# Counting calories
dog_cal = 140
bun_cal = 120
mus_cal = 20
ket_cal = 80
onion_cal = 40
                    
print("\tDog \tBun \tKetchup\tMustard\tOnions\tcalories")
count = 1
for dog in [0, 1]:
    for bun in [0, 1]:
        for ketchup in [0, 1]:
            for mustard in [0, 1]:
                for onion in [0, 1]:
                    total_cal = (dog*dog_cal) + (bun*bun_cal) + \
                    (mustard*mus_cal) + (ketchup*ket_cal) + \
                    (onion*onion_cal)
                    print("#", count, "\t",end=" ")
                    print(dog, "\t", bun, "\t", ketchup, "\t", end=" ")
                    print(mustard, "\t", onion, end=" ")
                    print("\t", total_cal)
                    count += 1
                    






                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          