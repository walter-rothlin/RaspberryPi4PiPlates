# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 16:19:32 2019

@author: sara
"""

# Sara Steinegger
# 10.07.2019

# Hello World: Chapter 3
# Basic Math



# The four basic operations (the symbols are called arithmetic operators)
# Addition
print(3+5)
# Subtraction
print(5-3)
# Multiplication
print(5*3)

# Division is a bit special:
# Divison
print(6/2)
# Divison
print(3/2)
# Floor divison
print(3//2) 
print(3%2) # Getting the remainer

# Note: "=" is also an operator, called the assignement operator!
# Note: Don't forget the order of operations (Python follows the math rules)



# Exponentiation - raising to power
print(3*3*3*3*3)
print(3**5)



# Modulus - getting the remainder
print(7//2)
print(7%2)



# Increment and Decrement
# Incrementing
number = 7
number += 1
print(number)
# Decrementing
number = 7
number -= 1
print(number)



# E-notation: Really big and really small
print(9938712345656.34*4823459023067.456)

a = 2.5e6
b = 1.2e7
print(a + b)

c = 2.6e75
d = 1.2e74
print(c + d)