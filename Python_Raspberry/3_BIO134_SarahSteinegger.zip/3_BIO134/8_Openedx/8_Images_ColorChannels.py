# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 10:12:34 2019

@author: sara
"""

# Sara Steinegger
# 23.07.2019

# Color Channels
import matplotlib.pyplot as pl
import matplotlib.image as img

h = img.imread('Haeckel.png')
# uint8 (0,255) or float32 (0.0,1.0)
copy = 1*h  # copy of the image
h[:,:,0] = copy[:,:,1]
h[:,:,1] = copy[:,:,2]
h[:,:,2] = copy[:,:,0]

pl.imshow(h)
pl.show()
