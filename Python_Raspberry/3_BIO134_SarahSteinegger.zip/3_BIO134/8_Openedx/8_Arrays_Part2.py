# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 08:41:21 2019

@author: sara
"""

# Sara Steinegger
# 23.07.2019

# Arrays Part 2
import numpy as np



# Commands of the type
x = np.array(range(10))
print(x)
print(len(x), x.shape)
print(type(x))



# Create arrys with more than one dimension
y = np.ndarray(shape=(3,4),dtype=int)
print(y)
print(len(y), y.shape)
print(type(y))
print(y[2,2])



# Creat arrys with more than one dimension (only zeros)
y = np.zeros(shape=(3,4),dtype=int)
print(y)
print(len(y), y.shape)
print(type(y))
print(y[2,2])





