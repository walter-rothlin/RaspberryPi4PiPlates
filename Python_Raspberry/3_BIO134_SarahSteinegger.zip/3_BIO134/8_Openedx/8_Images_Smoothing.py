# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 10:19:56 2019

@author: sara
"""

# Sara Steinegger
# 23.07.2019

# Smoothing
import matplotlib.pyplot as pl
import matplotlib.image as img

h = img.imread('Haeckel.png')
# uint8 (0,255) or float32 (0.0,1.0)

h = h[150:400,30:420]
nsum = 0*h

P = h.shape[0]
Q = h.shape[1]
print(h.shape)

#This commented part is the version without slicing:
#for p in range(1,P-1):
#    for q in range(1,Q-1):
#        nsum[p,q] = h[p+1,q] + h[p-1,q] + h[p,q+1] + h[p,q-1]

#This line is the concise alternative with slicing:
nsum[1:-1,1:-1] = h[2:,1:-1] + h[:-2,1:-1] + h[1:-1,2:] + h[1:-1,:-2]

h = (h + nsum/4)/2

pl.imshow(h)
pl.show()