# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 09:32:56 2019

@author: sara
"""

# Sara Steinegger
# 23.07.2019

# Exercises on slicing 2D arrays
import numpy as np
a = np.array([[1, 2, 6, 4],[9, 6, 6, 3],[3, 4, 7, 5],[3, 2, 1, 9],[3, 8, 7, 4]])
a[2:4,:3] = 0
print(a)



# Question on slicing arrays 1
# In order to do calculations like these, the slices
# (which are arrays themeselves) generally need to have the same shape.
# If the arrays do not have the same shape and python cannot work
# with them, it will raise an error that is a problem with broadcasting.
a = np.zeros([4,5])
a[3,1] = 3
a[2,3] = 2
a[0,2] = 4
a[1,2] = 5
b = a[:,1:3] + a[:,2:4]

# c = a[1:3,:-1] + a[:,1:3]
# c: Gives an error



# Question on slicing arrays 2
a = np.zeros([4,5])
a[3,1] = 3
a[2,3] = 2
a[0,2] = 4
a[1,2] = 5
b = a[:,1:3] + a[:,2:4]
c = a[3,:-1] + a[:,3]
print(c)
# Does c gives an error? NO!
# Both slices are onedimensional with the same length!



