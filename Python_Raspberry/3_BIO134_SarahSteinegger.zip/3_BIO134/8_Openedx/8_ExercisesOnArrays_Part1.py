# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 08:56:20 2019

@author: sara
"""

# Sara Steinegger
# 23.07.2019

# Exercises on Arrays (part 1)



# Exercise: Arrays 1
# Arrays are very powerful for doing calculations.
# Compared to lists, they are faster and code is easier to read an write.

# Calculation with a list
a = [1, 2, 6, 4]
for i in range(len(a)):
    a[i] *= 2
print(a)

# Calculation with an array
import numpy as np
a = np.array([1, 2, 6, 4])
a *= 2
print(a)



# Exercise: Arrays 2
# Arrays can be sliced!
# For 1-dimensional arrays this works the same as for lists.

# Calculation with a list
a = [3, 5, 2, 4, 3, 6] 
for i in range(1,4):
    a[i] += 10
print(a)

# Calculation with an array
import numpy as np
a = np.array([3, 5, 2, 4, 3, 6])
a[1:4] += 10
print(a)
