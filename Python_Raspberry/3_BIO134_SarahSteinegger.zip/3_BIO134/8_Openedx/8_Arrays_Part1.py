# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 08:14:20 2019

@author: sara
"""

# Sara Steinegger
# 23.07.2019

# Arrays Part 1
# Arrays look like lists of numbers, printed without commas.
# Numpy introduces a new datatype: arrays
import numpy as np



# Creating arrays
# with numpy.array()
x = np.array(range(10))
print(x)
# with numpy.linespace()
y = np.linspace(0,9,10)
print(y)



# Get the length of an array with len()
print(len(x))
# .shape (without parentheses) returns the shape of an array
print(x.shape)



# Arithmetic with arrays is completely diffrent to lists
# (it is component by component). In contrast to lists,
# arrays needs to be homogenous.
y = x+x
print(y)

y = 10*x
print(y)

y = x/2
print(y)



# When using arrays, it's important to keep the data type
# integer/float) in mind.
# Integer
z = np.array([0,1,False])
print(z)
z[2] +=0.5
print(z)
# float
z = np.array([0,1,False])
print(z)
z = 1.0*z
z[2] +=0.5
print(z)



# Create a copy
# An independent copy can be made by carrying out a calculation.
y = 1*x
y[1] = -1
print(x)
print(y)
# copy.deepcopy() can be used as well!
