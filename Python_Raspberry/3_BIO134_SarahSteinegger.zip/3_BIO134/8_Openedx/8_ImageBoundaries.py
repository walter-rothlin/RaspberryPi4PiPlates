# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 10:53:02 2019

@author: sara
"""

# Sara Steinegger
# 23.07.2019

# Exercise: Image boundaries
# Calculate the mean value of boundary pixels with numpy.mean()
# As input you can give an appropriate slice of the image.
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as img

image = img.imread("C://Users/sara/Desktop/BIO134_Programming _in_Biology/8_Openedx/hotspring_pattern.jpg")
# image = img.imread("C://Users/sara/Desktop/BIO134_Programming _in_Biology/8_Openedx/TestBild_2.jpg")

print(image.shape)

# What is the mean blue value of the right boundary pixels?
#image1 = np.array(image[:,0:10])

image1 = np.array(image[:,:,:])
print(image1)
for i in range(2986):
    image1[2000:2100,i] = [255,0,0]


mean_B = np.mean(image[:, 2986, 2]) # Zahlen drehen
print(mean_B)

plt.imshow(image1)
plt.show