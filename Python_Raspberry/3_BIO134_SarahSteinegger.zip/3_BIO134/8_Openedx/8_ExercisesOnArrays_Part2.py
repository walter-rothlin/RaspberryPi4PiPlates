# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 09:08:37 2019

@author: sara
"""

# Sara Steinegger
# 23.07.2019

# Exercises on Arrays (part 2)
import numpy as np
x = np.array([4,3,1])
print(x)



# Exercise: array copies and synonyms
import numpy as np
x = np.array([4, 3, 1])
y = x
z = 1*y
y[1] = 6
z[2] = 7
print(x)
print(y)
print(z)
# x: [4 6 1]
# y: [4 6 1]
# z: [4 3 7]



# Exercise: data types in arrays
import numpy as np
x = np.array([4, 3, 1])
y = 1.0*x
x[1] += 0.8
y += 0.1
print(x)
print(y)
# x: [4 3 1]
# y: [4.1 3.1 1.1]