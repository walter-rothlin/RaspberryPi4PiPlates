# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 09:19:30 2019

@author: sara
"""

# Sara Steinegger
# 23.07.2019

# Slicing multidimensional Arrays
import numpy as np
a = np.zeros([4,5])



# Change a single element in a multidimensional array
# a[3][1] = 3
a[3,1] = 3
a[2,3] = 2
a[0,2] = 4
a[1,2] = 5
print(a)



# Slicing multidimensional arrays
b = a[:,2]
print(b)
# Attention: teh two arrays refer to the same values (synonymes).
# Changing array a also changes array b (vice versa).
# Example 1
b = 1*a[:,2]
print(b)
# Example 2
c = 1*a[:,1:3] + 1*a[:,2:4]
print(c)



# Slicing and changing multidimensional arrays in one step
b = 1*a[:,1:3] + 1*a[:,2:4]
print(b)


