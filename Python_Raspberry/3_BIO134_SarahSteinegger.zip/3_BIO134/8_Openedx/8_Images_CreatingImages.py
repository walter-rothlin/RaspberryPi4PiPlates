# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 10:45:31 2019

@author: sara
"""

# Sara Steinegger
# 23.07.2019

# Creating Images

# A RGB (RedGreenBlue) image can be created as follows:
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
a=np.array([[[0,0,0],[0,0,0],[0,0,0]],[[1,0,0],[0,1,0],[0,0,1]],\
           [[1,1,0],[1,0,1],[0,1,1]],[[1,1,1],[0.5,0.5,0.5],\
           [1,1,1]]])
matplotlib.image.imsave("C://Users/sara/Desktop/BIO134_Programming _in_Biology/8_Openedx/dots.png", a)
plt.imshow(a)
plt.show()



# Alternatively, each pixel can also be described by only one value.
b=np.array([[  0,  0,  0,  0,  0,  0,  0],\
            [  0,0.3,  0,  0,  0,0.3,  0],\
            [  0,  0,  0,0.6,  0,  0,  0],\
            [  0,  1,  0,  0,  0,  1,  0],\
            [  0,  0,  1,  1,  1,  0,  0],\
            [  0,  0,  0,  0,  0,  0,  0]])
plt.imshow(b,cmap=plt.cm.jet)
plt.show()