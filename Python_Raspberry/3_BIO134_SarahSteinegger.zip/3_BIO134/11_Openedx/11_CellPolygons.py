# -*- coding: utf-8 -*-
"""
Created on Sun Jul 28 16:59:23 2019

@author: sara
"""

# Sara Steinegger
# 28.07.2019

# Cell Polygons

# Function:
# Import the data from a file
# Creats a list
def fyle_to_lyst(filename):
    fyle = open(filename+".txt", "r")
    fyle_lines = fyle.readlines()
    fyle.close()    
    l =[]
    for i in fyle_lines:
        l.append(i.split())
    for i,el in enumerate(l):
        for j,el1 in enumerate(el):
            l[i][j] = float(l[i][j])
    return l

# Cell-Vertex number
cv = fyle_to_lyst("wd_large_cv")
# Vertex position
vp = fyle_to_lyst("wd_large_vp")

# Selfcontrol
# print(len(cv[0]))
# print(len(cv[len(cv)-1]))
# print(vp[0][1])


# Getting the data in a useful format
# Here we need integers
for i,el in enumerate(cv):
    for j,el1 in enumerate(el):
        cv[i][j] = int(cv[i][j])

x_axis = []
y_axis = []
for i, el in enumerate(cv):
    x_el = []
    y_el = []
    for k in range(len(el)):
        x_el.append(vp[el[k]][0])
        y_el.append(vp[el[k]][1])
    x_axis.append(x_el)
    y_axis.append(y_el)

# Selfcontrol
# print(x_axis[0])
# print(y_axis[0])



# Warmup 1: data format wing disc
x_positions = [4.3, 1.2, 5.0, 8.3, 1.5, 4.2, 3.1]
vertex_numbers = [1, 2, 4]
p = 1
for element in vertex_numbers:
    p *= x_positions[element]
print(p)

# Warmup 2: data format wing disc
x_positions = [4.6, 4.5, 9.1, 2.2, 6.2, 7.6, 5.4, 9.3, 2.5, 2.6, 7.1, 
               8.9, 4.2, 3.1, 6.2, 1.4, 2.9, 9.7, 3.5, 5.2, 1.1, 9.3]
vertex_numbers = [2, 4, 11, 16, 18]
p = 1
for element in vertex_numbers:
    p *= x_positions[element]
print(p)



# Area calculation
x = [1, 2, 4]
y = [1, 3, 2]
a_sum = 0
for i,el in enumerate(x):
    a_sum += x[i]*y[i-1] - y[i]*x[i-1]
p = (1/2)*a_sum
print("The area of the triangle is: {:.1f}".format(p))



# Wing disc: Cell areas
import numpy as np
A_array = np.zeros(shape=(len(x_axis),1), dtype=float)

for i,el in enumerate(x_axis):
    a_sum = 0
    for j in range(len(el)):
        a_sum += x_axis[i][j]*y_axis[i][j-1] - x_axis[i][j-1]*y_axis[i][j]
    p = (1/2)*a_sum
    A_array[i] = p

# Selfcontrol    
# print("Area of the first cell:", ca_array[0])
# print("Area of the second cell:", ca_array[1])
# print("Are of the last cell:", ca_array[-1])



# Wing disc: cell centroids
# Cell centroids   
cx_array = np.zeros(shape=(len(x_axis),1), dtype=float)
cy_array = np.zeros(shape=(len(y_axis),1), dtype=float)

for i,el in enumerate(x_axis):
    c_sum = 0    
    for j in range(len(el)):
        c_sum += (x_axis[i][j]+x_axis[i][j-1])*((x_axis[i][j]*y_axis[i][j-1])-(y_axis[i][j]*x_axis[i][j-1]))
    c = (1/(6*A_array[i]))*c_sum
    cx_array[i] = c

for i,el in enumerate(y_axis):
    c_sum = 0    
    for j in range(len(el)):
        c_sum += (y_axis[i][j]+y_axis[i][j-1])*((x_axis[i][j]*y_axis[i][j-1])-(y_axis[i][j]*x_axis[i][j-1]))
    c = (1/(6*A_array[i]))*c_sum
    cy_array[i] = c

# distance to the disc center
distance = np.zeros(shape=(len(x_axis),1), dtype=float)

for i in range(len(distance)):
    distance[i,0] = (cx_array[i,0]**2 + cy_array[i,0]**2)**0.5

print(cx_array[0,0])
print(cy_array[0,0])
print(distance[0,0])
