# -*- coding: utf-8 -*-
"""
Created on Sun Jul 28 16:31:16 2019

@author: sara
"""

# Sara Steinegger
# 28.07.2019

# Exercise on Array Indexing

# Question 1
import numpy as np
  
a=np.array([3,5,2,5,6,2])
b=np.array([8,4,1,7,6,8])
for i in range(len(a)):
    if b[i]>=a[i]:
        a[i]+=2
print(a)

a=np.array([3,5,2,5,6,2])
b=np.array([8,4,1,7,6,8])
a[b>=a]+=2
print(a)



# Question 2
import numpy as np
import time
# loop
a=np.array(int(1e6)*[3,5,2,5,6,2])
b=np.array(int(1e6)*[8,4,1,7,6,8])
t0 = time.time()
for i in range(len(a)):
    if b[i]>=a[i]:
        a[i]+=2
t1 = time.time()
t_loop = t1-t0
# Array Indexing
a=np.array(int(1e6)*[3,5,2,5,6,2])
b=np.array(int(1e6)*[8,4,1,7,6,8])
t2 = time.time()
a[b>=a]+=2
t3 = time.time()
t_index = t3-t2

print("time spend on calculation with a loop:", t_loop)
print("time spend on calculation with array indexing:", t_index)



# IMPORTANT: and, or, &, |
# In this case, & had to be used instead of and. Even though this is not
# part of the course, this is why: and performs a single Boolean evaluation
# on an entire object, while & performs multiple Boolean evaluations on each
# of the elements of an object. The same is true for or and |
# (which also stands for or).