# -*- coding: utf-8 -*-
"""
Created on Sun Jul 28 16:22:56 2019

@author: sara
"""

# Sara Steinegger
# 28.07.2019

# Array Indexing
import numpy as np

a=np.array([6,8,5,7,3])
b=np.array([0,3,2])
c=np.array([0,3,2,0,1])

print (a[b]) #integer array indexing
print (a[(c>2) & (a>5)]) #boolean array indexing