# -*- coding: utf-8 -*-
"""
Created on Sun Jul 28 15:31:50 2019

@author: sara
"""

# Sara Steinegger
# 28.07.2019

# Python libraries



# Fitting: Polynomial fit

# numpy.polyfit(x,y,deg)
# does a least-square polynomial fit.

# x is the x-coordinates of the sample point,
# y is the y coordinates of the sample point
# and deg is the degree of the polynomial fit.
# This function returns an array of polynomial coefficients
# with the highest power appearing first.



# Student's t-test
# A t-test is usually done to determine if two samples are significantly
# diffrent from each other.

# scipy.stats.ttest_ind(a,b)



# The Spearman's rank
# The Spearman's rank correlation can be used to check the
# relationship between two variables.
# The Spearman's rank correlation coefficient and the p-value
# for non-correlation can be calculated by:

# scipy.stats.spearmanr(x, y)

# Calculating Spearmans's rho:
import scipy
import numpy as np

x = np.array([1.68, 1.92, 1.73])
y = np.array([68, 2.92, 1.73])
scipy.stats.spearmanr(x,y)

