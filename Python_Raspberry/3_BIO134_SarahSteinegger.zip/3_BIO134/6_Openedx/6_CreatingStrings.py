# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 10:06:12 2019

@author: sara
"""

# Sara Steinegger
# 18.07.2019

# Creating strings
s = "hell"
s += "o"
print(s)



# Exercise: Creating strings
s = 'kenfaeniencdasjsbce'
s_new = ""
for i in range(0, len(s), 4):
    s_new += s[i]
    s_new += s[i+1]
print(s_new)

s = 'ztvnenejsncejajdncalkjalymmxndjfbfbvsjdlfjbbaldkjfnlaqeqwqwplnnnel'
s_new = ""
for i in range(0, len(s), 4):
    s_new += s[i]
    s_new += s[i+1]
print(s_new)
