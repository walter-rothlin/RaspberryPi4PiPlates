# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 16:13:56 2019

@author: sara
"""

# Sara Steinegger
# 18.07.2019

# Exercise: Number formatting
from numpy import pi
p = int(10**6 * pi)
print('{:d} is an integer'.format(p))
print('{:f} is a float'.format(pi))
print('{:e} is a float in exp notation'.format(pi))

# Exercise 1
print('{:08d} is an integer'.format(p))

# Exercise 2
print('{:013.8f} is a float'.format(pi))

# Exercise 3
print('{:017.8e} is a float in exp notation'.format(pi))




