# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 15:18:05 2019

@author: sara
"""

# Sara Steinegger
# 17.07.2019

# The genetic Code

# Dictionary with genetic code is conventiently expressed in Python dictionary
cdn = {}
cdn['ttt'] = cdn['ttc'] = 'F phenylalanine'
cdn['tta'] = cdn['ttg'] = 'L leucine'
cdn['tct'] = cdn['tcc'] = cdn['tca'] = cdn['tcg'] = 'S serine'
cdn['tat'] = cdn['tac'] = 'Y tyrosine'
cdn['taa'] = cdn['tag'] = '* stop'
cdn['tgt'] = cdn['tgc'] = 'C cysteine'
cdn['tga'] = '* stop'
cdn['tgg'] = 'W tryptophan'
cdn['ctt'] = cdn['ctc'] = cdn['cta'] = cdn['ctg'] = 'L leucine'
cdn['cct'] = cdn['ccc'] = cdn['cca'] = cdn['ccg'] = 'P proline'
cdn['cat'] = cdn['cac'] = 'H histidine'
cdn['caa'] = cdn['cag'] = 'Q glutamine'
cdn['cgt'] = cdn['cgc'] = cdn['cga'] = cdn['cgg'] = 'R arginine'
cdn['att'] = cdn['atc'] = cdn['ata'] = 'I isoleucine'
cdn['atg'] = 'M methionine'
cdn['act'] = cdn['acc'] = cdn['aca'] = cdn['acg'] = 'T threonine'
cdn['aat'] = cdn['aac'] = 'N asparagine'
cdn['aaa'] = cdn['aag'] = 'K lysine'
cdn['agt'] = cdn['agc'] = 'S serine'
cdn['aga'] = cdn['agg'] = 'R arginine'
cdn['gtt'] = cdn['gtc'] = cdn['gta'] = cdn['gtg'] = 'V valine'
cdn['gct'] = cdn['gcc'] = cdn['gca'] = cdn['gcg'] = 'A alanine'
cdn['gat'] = cdn['gac'] = 'D aspartic acid'
cdn['gaa'] = cdn['gag'] = 'E glutamic acid'
cdn['ggt'] = cdn['ggc'] = cdn['gga'] = cdn['ggg'] = 'G glycine'



# Exercise: genetic code 1
s = "atgagtaaaggagaagaacttttcactggagttgttccaattcttgttgaattagatggt"
codon = []
amino_acid_s = []

for i in range(0, len(s), 3):
    codon.append(s[i:i+3])    
for el in codon:
    amino_acid_s.append(cdn[el][0])

amino_acid_s = "".join(amino_acid_s)
print(amino_acid_s)  

# Exercise: genetic code 2
s = "atgagtaaaggagaagaacttttcactggagttgttccaattcttgttgaattagatggt"
codon = []
amino_acid_s = ""

for i in range(0, len(s), 3):
    codon.append(s[i:i+3])    
for el in codon:
    amino_acid_s += cdn[el][0]

print(amino_acid_s)  






