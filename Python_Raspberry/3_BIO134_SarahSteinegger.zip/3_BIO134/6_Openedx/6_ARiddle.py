# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 10:48:27 2019

@author: sara
"""

# Sara Steinegger
# 18.07.2019

# A riddle
riddle = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/6_Openedx/riddle.txt", "r")
r = riddle.read()
riddle.close()

word = ""

if "*****" and "#####" in r:
    star_index = r.index("*****")
    zaun_index = r.index("#####")
needed_r = r[int(star_index):int(zaun_index)]

for i,el in enumerate(needed_r):
    if el in "abcdefghijklmnopqrstuvwxyz":
        word += el
print(word)
        

        