# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 16:28:38 2019

@author: sara
"""

# Sara Steinegger
# 18.07.2019

# String formatting

# Exercise: Rewriting strings 
s = "EzHsPsKyTvKJKqoVzwRavQTzHDtHQyvhrFUIeTBRkSRpJPlLEocbyJBiRlngqmfUKcd"
s_new = ""
count = 0

for i in range(0, len(s), 10):
    s_new += s[i:i+5].upper()
    s_new += s[i+5:i+10].lower()

for i in s:
    count += 1

print(s_new, "{:9d}".format(count))
   
s = "dlFuBMOzwdejnppmBbTKtUHeCbixgCuKDiMICOPkwpmFPbAFdhvfeBGrooNpW"
s_new = ""
count = 0

for i in range(0, len(s), 10):
    s_new += s[i:i+5].upper()
    s_new += s[i+5:i+10].lower()

for i in s:
    count += 1

print(s_new, "{:9d}".format(count))
