# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 15:40:38 2019

@author: sara
"""

# Sara Steinegger
# 17.07.2019

# Dictionaries and the keyword in

# Exercise: Looping through a dictionary
# for something in myDictionary:
    # print(something)
# prints the keys of the dictionary



# Exercise: Keys in dictionaries 1
l = ['ediks', 29, 'adnec']
d = {'adcen': 65, 'ikjna': 29, 'ediks': 73, 'zhdis': 76}
l_new = len(l)*[]

for el in l:
    if el in d:
        l_new.append(1)
    else:
        l_new.append(0)
print(l_new)



# Exercise: Keys in dictionaries 2
l = ['nwnnnwwnnd', 'wdnndnnwwn', 45, 'nwwwnwnnnwd', 'dnwndddnw', 'nnnwdwdndd',
     'ndnnwwnwnn', 'nwdnnnnnww', 'dnddwndnd', 'wwnwdnnwdw', 'dwndwnnnd', 17, 
     'nwddwwnnnnw', 'nnwndwwddw', 'wnwnwnwnd', 'wdwwwnnnw', 'nnwnddnnw', 
     'nwdnndwnww', 81, 'wnwwwwwnnnw', 'nwndnnnnnww', 31]
d = {'wnwwwwwnnnw': 48, 'nwndnnnnnww': 97, 'nnwdwdddnw': 63, 'nwndnnnnww': 45,
     'nwdnndnwnww': 39, 'nnwndddnnw': 82, 'wdnndnnwwn': 11, 'nnnwwwwnwdn': 31, 
     'dnwwwnnddw': 66, 'wnwnwnwnd': 89, 'dwdwwdnndww': 17, 'nnwnddnwnww': 80, 
     'dndwwnwwwwd': 94, 'nwwdnnwnd': 88, 'nwnnnwwnnd': 58, 'ndnwwnwwwd': 4, 
     'nwnwdwdnw': 45, 'nwwwnwnnnwd': 70, 'wdnnwnndnnd': 95, 'ndnddnwwwwn': 45, 
     'nwdnndddwd': 7, 'nwdnnnnnww': 5, 'nnwwnddnnwn': 45, 'nndwdnwwwwd': 29, 
     'nnwwdwddnww': 17, 'wnnwnnwnn': 24, 'dnwndddnw': 99, 'wwdnwwwndn': 36, 
     'wwwwwnndwn': 31, 'nwdnndwnww': 43, 'nwnndwwwwnd': 9, 'wdwwnnnnw': 71}
l_new = len(l)*[]

for el in l:
    if el in d:
        l_new.append(1)
    else:
        l_new.append(0)
print(l_new)   



