# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 10:38:25 2019

@author: sara
"""

# Sara Steinegger
# 18.07.2019

# Some string operations
s = "I am shocked shocked to find that gambling is going in here"

# Changing case - upper()
s_upper = s.upper()
print(s_upper)

# Changing case - lower()
s_lower = s.lower()
print(s_lower)

# Replace the vocals with hyphen ("-")
for c in "aeiou":
    s_hyphen = s.replace(c,"-")
print(s_hyphen)

# Splitting a string
s_split = s.split("shocked")
print(s_split)

# partition() looks for the forst "shocked" in the string
# and gives always back a tuple with 3 elemnets.
# ("Befor partition parameter", "partition parameter", "after partition parameter")
s_partition = s.partition("shocked")
print(s_partition)

