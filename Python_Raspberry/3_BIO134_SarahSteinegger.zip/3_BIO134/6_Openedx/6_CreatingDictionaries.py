# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 15:50:22 2019

@author: sara
"""

# Sara Steinegger
# 17.07.2019

# Creating dictionaries

# Exercise: Creating dictionaries 1
dic_1 = {}
births = [['darwin','12 February 1809'],['shakespeare','26 April 1564'],\
          ['cervantes','29 September 1547'],['lincoln','12 February 1809']]

for i,el in enumerate(births):
    for j,el2 in enumerate(el):
        dic_1[births[i][0]] = births[i][1]
print(dic_1)
            
        

# Exercise: Creating dictionaries 2
dic_2 = {}
births = [['darwin','12 February 1809'],['shakespeare','26 April 1564'],\
          ['cervantes','29 September 1547'],['lincoln','12 February 1809']]

for i,el in enumerate(births):
    for j,el2 in enumerate(el):
        if births[i][1] not in dic_2.keys():
            dic_2[births[i][1]] = []
    dic_2[births[i][1]].append(births[i][0])
print(dic_2)



# Exercise: Creating dictionaries 3
person = {}
person_new = {}

person['darwin'] = 'Charles Darwin'
person['shakespeare'] = 'William Shakespeare'
person['cervantes'] = 'Miguel de Cervantes'
person['lincoln'] = 'Abraham Lincoln'

for i,el in enumerate(person):
    person_new[person[el]] = el
print(person_new)


                   
# Referring to values in a list within a dictionary
d = {'Paul': 'Meier', 'Julia': 'Leutenegger', 'Daniel': 'Brunner'}
print(d['Julia'])

d = {'Paul': ['Meier', 20], 'Julia': ['Leutenegger', 23], 'Daniel': ['Brunner', 21]}
print(d['Paul'][1])



# Exercise: Creating dictionaries 4
person = {}
person_new = {}

person['darwin'] = ['Charles Darwin',
                    '12 February 1809','19 April 1882']
person['shakespeare'] = ['William Shakespeare',
                    '26 April 1564','23 April 1616']
person['cervantes'] = ['Miguel de Cervantes',
                    '29 September 1547','23 April 1616']
person['lincoln'] = ['Abraham Lincoln',
                    '12 February 1809','15 April 1865']
for el in person:
    for i,el2 in enumerate(el):
        if person[el][2] not in person_new.keys():
            person_new[person[el][2]] = []
    person_new[person[el][2]].append(el)
print(person_new)



# Exercise: Creating dictionaries 5
person = {}
person_new = {}

person['darwin'] = ['Charles Darwin',
                    '12 February 1809','19 April 1882']
person['shakespeare'] = ['William Shakespeare',
                    '26 April 1564','23 April 1616']
person['cervantes'] = ['Miguel de Cervantes',
                    '29 September 1547','23 April 1616']
person['lincoln'] = ['Abraham Lincoln',
                    '12 February 1809','15 April 1865']

for el in person:
    for j,el2 in enumerate(el):
        if person[el][2] not in person_new:
            person_new[person[el][2]] = []
    person_new[person[el][2]].append(person[el][0])
print(person_new)
            