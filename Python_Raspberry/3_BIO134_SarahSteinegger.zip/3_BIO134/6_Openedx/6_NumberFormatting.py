# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 11:26:54 2019

@author: sara
"""

# Sara Steinegger
# 18.07.2019

# Number formatting
temp = 10
s = 'It is {} °C'.format(temp)
print(s)

# Aligne a 5 space holder to the right
print('It is {:5d} °C'.format(temp))

#Align to the left
print('It is {:<5d} °C'.format(temp))

# Padding with zeros
print('It is {:05d} °C'.format(temp))

# Formatting as a float
print('It is {:10.2f} °C'.format(temp)) 

# Formatting using e-notation
print('It is {:10.2e} °C'.format(temp))

# Formatting more than one number
temp = 11
temp2 = temp * 9/5 + 32
s = 'It is {:.2f} °C, which is {:.2f} °F'.format(temp, temp2)
print(s)
