# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 10:52:54 2019

@author: sara
"""

# Sara Steinegger
# 11.07.2019

# Looping through lists using Indices
# Example 1
lys1 = [4, 5, 7, 2]
lys2 = [3, 7, 10, 12]

for i in range(len(lys1)):
    print(i, lys1[i] + lys2[i])

# Example 2
lys1 = [4, 5, 7, 2]
lys2 = [3, 7, 10, 12]
lys3 = 4*[0]

for i in range(4):
    lys3[i] = lys1[i] + lys2[i]

print(lys3)





