# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 11:07:36 2019

@author: sara
"""

# Sara Steinegger
# 11.07.2019

# Calculation with two lists 1
lys1 = [5, 6, 2, 9]
lys2 = [3, 8, 3, 6]
lys3 = 3*[0]

for i in range(len(lys1)-1):
    lys3[i] = lys1[i] * lys2[i+1]

print(lys3)



# Calculation with two lists 2
lys1 = [7, 3, 2, 5, 1, 4, 4, 6, 2, 9, 1, 6, 3, 2, 6, 5, 5]
lys2 = [8, 9, 8, 9, 6, 4, 5, 5, 8, 2, 4, 3, 1, 6, 5, 6, 5]
lys3 = 16*[0]

for i in range(16):
    lys3[i] = lys1[i] * lys2[i+1]

print(lys3)
print(sum(lys3))



