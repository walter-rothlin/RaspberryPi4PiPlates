# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 20:37:00 2019

@author: sara
"""
# Sara Steinegger
# 09.07.2019

# Exercise: Population dynamics

# The number of predators and prey in a region depend on each other.
# Let's make the following assumptions for a model describing these
# relationships: The prey population increases by 5% each day as the net
# result of birth and natural death. At the same time, the population is
# decreased by the presence of predators. The more predators there are,
# the more prey is being caught and the more prey there is, the easier it is
# for predators to catch the prey.
# Specifically, each day the prey population is reduced by 0.0002*number
# of predators*number of prey.

# The predator population decreases by 10% per day.
# In addition, the presence of prey has a positive influence on the number of
# predators. This depends on how much prey is being caught and this is again
# dependent on the number of predators as well as the number of prey.
# The increase amounts to 0.0001*number of predators*number of prey each day.

# Note that in order to calculate the changes in predator and prey populations,
# you should use the predator and prey numbers from the start of the day

n = 200
predator = float(100)
prey = float(1000)

for i in range(1, n+1):
    prey_n = prey + (prey*0.05 - 0.0002*predator*prey)
    predator_n = predator + (-0.1*predator + 0.0001*predator*prey)
    prey = prey_n
    predator = predator_n
print(int(prey), int(predator))



# Warm-up 1
n = 40
prey = float(1000)
for i in range(1, n+1):
    prey = prey + (prey*0.05)
print(int(prey))

# Warm-up 2
n = 10
prey = float(1000)
predator = float(100)
for i in range(1, n+1):
    prey = prey*1.05 - 0.0002*prey*predator
print(int(prey))



# How many predator and prey is present after 1542 days
n = 1542
predator = float(100)
prey = float(1000)

for i in range(1, n+1):
    prey_n = prey + (prey*0.05 - 0.0002*predator*prey)
    predator_n = predator + (-0.1*predator + 0.0001*predator*prey)
    prey = prey_n
    predator = predator_n
print(int(prey), int(predator))



# Update the population each hour (instead of each day)
n = 4800
predator = float(100)
prey = float(1000)

p1 = 0.05/24
p2 = 0.1/24
p3 = 0.0002/24
p4 = 0.0001/24

for i in range(1, n+1):
    prey_n = prey + (prey*p1 - p3*predator*prey)
    predator_n = predator +(-predator*p2 + p4*predator*prey)
    prey = prey_n
    predator = predator_n
print(int(prey), int(predator))



# Update the population each minute (instead of each hour)
n = 288000
predator = float(100)
prey = float(1000)

p1 = (0.05/24)/60
p2 = (0.1/24)/60
p3 = (0.0002/24)/60
p4 = (0.0001/24)/60



for i in range(1, n+1):
    prey_n = prey + (prey*p1 - p3*predator*prey)
    predator_n = predator + (-predator*p2 + p4*predator*prey)
    prey = prey_n
    predator = predator_n
print(int(prey), int(predator))



