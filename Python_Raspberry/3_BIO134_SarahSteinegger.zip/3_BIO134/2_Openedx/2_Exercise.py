# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 09:21:51 2019

@author: sara
"""

# Sara Steinegger
# 09.07.2019

# For loops
# The range() function is very important.

# Questions: in range()
# Exercise 1
j = 0
for i in range(1, 6):
    j += 1
print(i)

# Exercise 2
j = 0
for i in range(1, 6):
    j += 1
print(j)

# Exercise 3
j = 0
for i in range(1, 6):
    j += 1
    print(j)

# Exercise 4
j = 0
for i in range(1, 6, 2):
    print("hello")
print(i)

# Exercise 5
j = 0
for i in range(8, 0, -2):
    print(i)



# Loop and print
# Exercise: loop and print 1
n = 5
j = 0
for i in range(0, n):
    j = i+4
    print(i, j)
    j = 0

# Exercise: loop and print 2
n = 10
j = 0
for i in range(0, n+1, 2):
    j = i*3
    print(i, j)
    j = 0



# Loop and adding up
# Exercise: loop and adding up 1
n = 5
j = 0
for i in range(1, n+1):
    j += i
print(j)
    
n = 213
j = 0
for i in range(1, n+1):
    j += i
print(j)

# Exercise: loop and adding up 2
n = 8
j = 0
for i in range(0, n+1, 2):
    j += i
print(j)

n = 226
j = 0
for i in range(0, n+1, 2):
    j += i
print(j) 


# Exercise: Population dynamics
# The number of predators and prey in a region depend on each other.
# Let's make the following assumptions for a model describing these
# relationships: The prey population increases by 5% each day as the net
# result of birth and natural death. At the same time, the population is
# decreased by the presence of predators. The more predators there are,
# the more prey is being caught and the more prey there is, the easier it is
# for predators to catch the prey.
# Specifically, each day the prey population is reduced by 0.0002*number
# of predators*number of prey.

# The predator population decreases by 10% per day.
# In addition, the presence of prey has a positive influence on the number of
# predators. This depends on how much prey is being caught and this is again
# dependent on the number of predators as well as the number of prey.
# The increase amounts to 0.0001*number of predators*number of prey each day.

# Note that in order to calculate the changes in predator and prey populations,
# you should use the predator and prey numbers from the start of the day
n = 200
predator = 100
prey = 1000

for i in range(1, n+1):
    prey = prey*0.05 - 0.0002*predator*prey
    predator -= predator*0.1 + 0.0001*predator*prey
print(prey, predator)

# Warm-up 1
n = 40
prey = 1000
for i in range(1, n+1):
    prey *= 1.05
print(prey)

# Warm-up 2
n = 10
prey = 1000
predator = 100
for i in range(1, n+1):
    prey = prey*1.05 - 0.0002*prey*predator
print(int(prey))




