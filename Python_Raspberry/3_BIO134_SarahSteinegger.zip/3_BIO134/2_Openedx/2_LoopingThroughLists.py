# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 21:26:54 2019

@author: sara
"""

# Sara Steinegger
# 09.07.2019

# Exercise: Looping through lists
lys = ["Surely", "you're", "joking"]
for words in lys:
    print(words+"*",end="")
print()


# Exercise: Calculation with list elements
#lys = [5, 3, 3, 2]
lys = [5, 7, 2, 9, 8, 9, 3, 4, 2, 3, 2, 7, 7, 5]
j = 1
for number in lys:
    j *= number
print(j)



# Exercise: loop and if
#lys = [5, 3, 3, 2]
lys = [5, 7, 2, 9, 8, 9, 3, 4, 2, 3, 2, 7, 7, 5]
j = 1
a = 0
for number in lys:
    if number == 3:
        a = 1
    if a == 1:
        j *= number
print(j)
