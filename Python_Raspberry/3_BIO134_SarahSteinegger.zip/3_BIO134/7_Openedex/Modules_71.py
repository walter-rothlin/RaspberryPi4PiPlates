# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 16:17:37 2019

@author: sara
"""

# Sara Steinegger
# 21.07.2019

# Modules

# NOTE: module names cannot start with a number
# (this is not mentioned in the movie).

# The movie shows how functions can be used by other programs.
# The following example is being discussed:

def subtract(a,b):
   c = a-b
   return c
   
def length_line(x1,y1,x2,y2):
   l = (subtract(x2,x1)**2 + subtract(y2,y1)**2)**0.5
   return l





