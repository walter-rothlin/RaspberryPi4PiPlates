# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 07:45:52 2019

@author: sara
"""

# Sara Steinegger
# 21.07.2019

# GenBank and FASTA

# Exercise: Genbank to FASTA

# def genbank_to_fasta():
    
g = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/7_Openedex/B4F440.genbank.txt", "r")
g_lines = g.readlines()
f = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/7_Openedex/B4F440.fasta.txt", "w")
f_lines = []

for i,el in enumerate(g_lines):
    g_lines[i] = el.strip().split()

print(g_lines)

for i,line in enumerate(g_lines):
    for j, el in enumerate(line):
        if el == 'ORIGIN':  
            f_lines.extend(g_lines[i+1:len(g_lines)])

for i, line in enumerate(f_lines):
    for j,el in enumerate(line):
        f_lines[i] = f_lines[i][1:len(el)]         
print(f_lines)
    

        
    
    






