#------------------------------------------------------------------------------           
def fasta_to_genbank(seq_id):
    filename = seq_id+'.fasta.txt'
    
    fidI=open(filename,'r')           
    fidO=open(seq_id+'.fasta2genbank','w')
    
    num_char=1 #num character (seq)
    flag_first_line=True #header in fasta
    lines = fidI.readlines()
    for line in lines:
        line = line.strip()
        if flag_first_line:
            flag_first_line=False
            fidO.write('Header\n')
            fidO.write('ORIGIN\n') #starts the seq
        else:
            fidO.write('{:9d}'.format(num_char))
            line = line.lower()
            for n in range(0,60,10):
                if len(line[n:n+10])>0:
                    fidO.write(' '+line[n:n+10])
            fidO.write('\n')
            num_char+=(len(line))            
    
    fidO.write('//') #seq stop
   
    fidI.close()
    fidO.close() 
#------------------------------------------------------------------------------          
def genbank_to_fasta(seq_id):
    filename = seq_id+'.genbank.txt'
    fidI=open(filename,'r')           
              
    lines = fidI.readlines()
    fidI.close()

    fidO=open(seq_id+'_genbank2fasta','w')
    fidO.write('>Header\n')

    text=''.join(lines)
    
    trash,tmp,text=text.partition('ORIGIN\n')        
    
    seq,tmp,trash=text.partition('//')
    
    # The following line uses list comprehension,
    # which is an optional section in Week 5.
    line_no_number=[s for s in seq.split() if s[-1]!='1']
         
    for i,ch in enumerate(line_no_number):
        fidO.write(ch.upper())
        if i%6==5:
            fidO.write('\n')
    
    fidO.close()


#-----------------------------------------------------------------------------
genbank_to_fasta('B4F440')
fasta_to_genbank('B4F440')
      
