# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 16:19:07 2019

@author: sara
"""

# Sara Steinegger
# 21.07.2019

# Modules 2
import Modules_71

x_1=0.7
y_1=6.3
x_2=3.4
y_2=9.3
length = Modules_71.length_line(x_1, y_1, x_2, y_2)
print(length)

# This is especially useful for larger programs;
#for small programs it may be most practical to have
# everything in one file.