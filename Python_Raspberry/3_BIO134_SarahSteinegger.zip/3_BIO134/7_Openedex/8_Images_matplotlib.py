# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 09:53:55 2019

@author: sara
"""

# Sara Steinegger
# 23.07.2019

# Images: matplotlib