# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 09:34:02 2019

@author: sara
"""

# Sara Steinegger
# 21.07.2019

# Calling functions from other functions
def subtract(a,b):
    c = a-b
    return c

def length_line(x1,y1,x2,y2):
    l_1 = (subtract(x2,x1)**2 + subtract(y2,y1)**2)**0.5
    return l_1

x_1=0.7
y_1=6.3
x_2=3.4
y_2=9.3
length = length_line(x_1, y_1, x_2, y_2)
print(length)

# Does the order of function definitions matter? NO!
# Please note though that this is only the case if functions
# are called inside other functions. In the main program,
# it is possible to call a function after defining the 
# function itself and the functions it calls.
# Thus in this case, length_line() can only be calles after both
# substract and length_line() have been defined.



# Exercise: Standard deviation
def average(a):
    sum_a = 0
    for i,el in enumerate(a):
        sum_a += float(el)
    mean_a = sum_a/len(a)
    print(mean_a)
    return mean_a     

def standarddev(b):
    mean_b = average(b)
    sum_b1 = 0
    for i,el in enumerate(b):
        sum_b1 += ((float(el)-mean_b)**2)
    sd_b = (sum_b1/(len(b)-1))**0.5
    return sd_b

l = [5.75, 5.37, 2.45, 8.22, 7.45, 1.89, 3.82, 2.49]
sd = standarddev(l)
print(sd)



# Exercise: Standard error
def average(a):
    sum_a = 0
    for i,el in enumerate(a):
        sum_a += float(el)
    mean_a = sum_a/len(a)
    print(mean_a)
    return mean_a     

def standarddev(b):
    mean_b = average(b)
    sum_b1 = 0
    for i,el in enumerate(b):
        sum_b1 += ((float(el)-mean_b)**2)
    sd_b = (sum_b1/(len(b)-1))**0.5
    return sd_b

def standarderror(c):
    se_c = standarddev(c)/(len(c)**0.5)
    return se_c

l = [5.75, 5.37, 2.45, 8.22, 7.45, 1.89, 3.82, 2.49]
se = standarderror(l)
print(se)