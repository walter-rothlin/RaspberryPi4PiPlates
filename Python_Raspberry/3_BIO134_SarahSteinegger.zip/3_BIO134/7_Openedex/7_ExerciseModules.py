# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 16:28:14 2019

@author: sara
"""

# Sara Steinegger
# 21.07.2019

# Exercise: modules

# Cell invasion
import CallingFunctionsWithinFunctions_7

nr = [34.78, 72.73, 72.73, 66.67, 73.33, 68.18, 88.89, 91.67, 77.78]
r = [16.67, 66.67, 20.00, 12.50, 46.15, 40.00, 40.00, 0.00, 66.67,
             0.00, 40.00, 66.67, 100.00, 63.64, 75.00, 50.00, 40.00]


# Question 1
m_nr = CallingFunctionsWithinFunctions_7.average(nr)
print(m_nr)

# Question 2
se_nr = CallingFunctionsWithinFunctions_7.standarderror(nr)
print(se_nr)

# Question 3
m_r= CallingFunctionsWithinFunctions_7.average(r)
print(m_r)

# Question 4
se_r = CallingFunctionsWithinFunctions_7.standarderror(r)
print(se_r)
        
