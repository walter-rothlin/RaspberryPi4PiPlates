# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 12:53:58 2019

@author: sara
"""

# Sara Steinegger
# 19.07.2019

# Functions with two arguments

# Question 1
def add(a,b):
    c = a+b
    return c
print(add(3,4))
# Prints 7

# Question 2
def add(a,b):
    c = b+4
    return c
print(add(3,4))
# Prints 8

# Question 3
def add(a,b):
    c = b+4
    return c
a = 3
b = 4
print(add(b,a))
# Prints 7
# a in the function gets the same value as
# the first argument that the function is called with
# (in this case b, which is 4) and b in the function gets the
# same value as the second argumentz.

# Question 4
def add(a,b):
    c = a+4
    return c
print(add(4))
# It gives an error!
# When calling the function add() two arguments must be given.





