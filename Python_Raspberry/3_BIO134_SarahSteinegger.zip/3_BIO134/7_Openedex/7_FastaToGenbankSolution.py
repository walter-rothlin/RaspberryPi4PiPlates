# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 17:27:27 2019

@author: sara
"""

# Sara Steinegger
# 21.07.2019

# Fasta to Genbank Solution
def fasta_to_genbank(sid):
    fyle_fasta = open(sid + '.fasta.txt')
    fyle_genbank = open(sid + '.genbank.txt', 'w')
    list_fasta = fyle_fasta.readlines()[1:]
    s = 'dummy header\nORIGIN\n'
    number = 1
    for line in list_fasta:
        line = line.strip().lower()
        s += '{:9d}'.format(number)
        for i in range(0, 60, 10):
            if len(line[i:i+10])>0:
                s += ' '+line[i:i+10]
        s += '\n'
        number += 60
    s += '//'
    print(s)
    fyle_genbank.write(s)
    fyle_fasta.close()
    fyle_genbank.close()

fasta_to_genbank('B4F440')
