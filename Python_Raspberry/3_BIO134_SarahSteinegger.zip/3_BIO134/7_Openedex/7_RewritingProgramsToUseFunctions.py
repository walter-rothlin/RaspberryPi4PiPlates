# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 16:55:41 2019

@author: sara
"""

# Sara Steinegger
# 19.07.2019

# Rewriting programs to use functions
