# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 16:29:37 2019

@author: sara
"""

# Sara Steinegger
# 19.07.2019

# Exercise: Write a function
def average(a):
    l_sum = 0
    for i, el in enumerate(a):
        l_sum += el
    l_average = l_sum/len(a)
    return l_average
l = [5.75, 5.37, 2.45, 8.22, 7.45, 1.89, 3.82, 2.49]
m = average(l)
print(m)



# Exercise: Returning more than one variable
def sum_average(a):
    l_summe = 0
    for i, el in enumerate(a):
        l_summe += el
    l_mean = l_summe/len(a)
    return l_summe, l_mean
l = [5.75, 5.37, 2.45, 8.22, 7.45, 1.89, 3.82, 2.49]
summe, mean = sum_average(l)
print(int(summe * mean))



# Exercise: function and printing 1
def test_square(a, b):
    c = a**2
    if c < b:
        print("The square of", a, "is smaller than", b, ".")
    if c>= b:
        print("The square of", a, "is not smaller than", b, ".")
test_square(4, 17)
test_square(4, 16)



# Exercise: function and printing 2
def test_square2(c, d):
    e = c**2
    if e < d:
        return True
    else:
        return False
a = 4
b = 17
if test_square2(a, b):
  print('The square of {:d} is smaller than {:d}.'.format(a,b))
else:
  print('The square of {:d} is not smaller than {:d}.'.format(a,b))    









