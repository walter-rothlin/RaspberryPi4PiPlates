# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 15:58:36 2019

@author: sara
"""

# Sara Steinegger
# 19.07.2019

# The scope of variables

# Question 1
def add(a):
    b = a+4
    return b
add(3)
print(b)
# It gives an error!
# The variable b is not known outside the function. The function
# returns the value of b, but this value is not stored in a variable

# Question 2
b = 2
def add(a):
    b = a+4
    return b
c = add(3)
print(b)
# Prints 2
# b inside the function is local and not known outside the function
# A function cannot simply change globaö variables
# (b outside the function), unless it is explicitly instructed to do so.

# Question 3
b = 2
def add(a):
    c = b+2+a
    return c
d = add(3)
print(d)
# Prints 7
# When b is used within the function, it is a global variable.
# Functions can use values of global variables; they just
# cannoit simply change them.
# However, usually it's bad parctice to access global variables
# inside a function as an argument. In this way, you can simply
# look at the passed arguments to see which variables a function uses.
# Especially if a program uses many functions, this makes it
# easier to understand how a program works.
# Better alternative
b = 2
def add(a, b_local):
    c = b_local+2+a
    return c
d = add(3, b)
print(d)

# Question 4
b = 2
def add(a):
    c = b+2
    b = c+a
    return b
b = add(3)
print(b)
# It gives an error!
# The line "b = c+a" makes b a local variable, since functions 
# cannot simply change global variables.
# Even though the line "c = b+2" is before that line, it sti has
# to treat b as a local variable now and the local variable b is not 
# assigned yet at the point.

# Question 5
b = 2
def add(a):
    global b
    c = b+2
    b = c+a
add(3)
print(b)
# Prints 7
# Since b is declared global, it can be changed by the function,
# even if the function does not return anything. Using global variables
# should be limited as much as possible, because it can become
# unclear which variale can be changed by which function.
# By using functions shithout global variables and by only using
# local variables inside the function (so also without using values of
# global variables), the function can be seen as a black box with 
# a certain in and output that is independent of the rest of
# the program. This makes it easier to keep track of variables in more
# complicated programs.

# Question 7
b = 2
def add(b):
    c = b+2
    return c
a = add(3)
print(a)
# Prints 5
# In this case the value 3 is stored in the local variale b while
# calling the function. The function will therefore treat b 
# as a local variable.


