# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 12:33:26 2019

@author: sara
"""

# Sara Steinegger
# 19.07.2019

# Functions that return a variable

# Question 1
def add(a):
    b = a+4
print(add(3))
# Prints none
# The function does not return any variable
#so that add(3) does not get a value

# Question 2
def add(a):
    b = a+4
    return b
print(add(3))
# Prints 7
# Since the function returns b, add(3) now has the value of b

# Question 3
def add(a):
    b = a+4
    return b
    b += 3
print(add(3))
# Prints 7
# The function returns b when it still has a value of 7.
# in fact, a function is not being read further as soon as a value 
# has been returned.

# Question 4
def add(a):
    b = a+4
    return b
c = add(3)
print(c)
# Prints 7

# Question 5
def add(a):
    b = a+4
    return b
a = add(3)
print(a)
# Prints 7
# a (global) gets the value of the variable that the add() function returns

# Question 6
def add(a):
    b = a+4
    return b
print(b)
# It gives an error!
# Since the function add() is not being called,
# b is not defined at any time. In addition, since b would only be defined
# inside the function, it cannot be printed outside the function.




