# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 15:40:20 2019

@author: sara
"""

# Sara Steinegger
# 19.07.2019

#Funcions that return two values

# Question 1
def add(a,b):
    c = a+5
    d = b+6
    return c,d
print(add(3,4))
# Prints (8,10)
# The function returns a tuple with two values:
# c,d is short for (c,d). Thus, it would also have been
# possible to write: return (c,d)

# Question 2
def add(a,b):
    c = a+5
    d = b+6
    return c
    return d
print(add(3,4))
# Prints 8
# A function is quit as soon as a variable has been returnd.

# Question 3
def add(a,b):
    c = a+5
    d = b+6
    return [c,d]
print(add(3,4))
# Prints [8,10]
# It is possible to return two values in a list, as has been done
# here. However, since lists are mutable, this is less efficient.
# Therefore, tuples are usually used for this kind of cases.

# Question 4
def add(a,b):
    c = a+5
    d = b+6
    return c,d
print(add(3,4)[1])
# Prints 10!
# It prints the second value of the tuple, which is the value
# that was given to d!

# Question 5
def add(a,b):
    c = a+5
    d = b+6
    return c,d
e = add(3,4)
print(e)
# Prints (8,10)

# Question 6
def add(a,b):
    c = a+5
    d = b+6
    return c,d
e,f=add(3,4)
print(e)
# Prints 8
# e and f get the value of the first and second part of
# the returned tuple, respectively.

# Question 7
def add(a,b):
    c = a+5
    d = b+6
    return c,d
e,f,g = add(3,4)
print(e)
# It gives an error!
# Sce the returned tuple only contains two values, it is not
# possible to assign values to three diffrent variables.


