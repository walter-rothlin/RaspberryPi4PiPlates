# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 17:01:57 2019

@author: sara
"""

# Sara Steinegger
# 21.07.2019

# Biopython

# Libraries in Pxthon
# In addition to standard libraries, Spyder also contains
# some libraries that are often used for scientific programming
# including matplotlib, numpy and scipy.



# Uniprot 1
from Bio import ExPASy, SeqIO
sid = input('Sequence id? ')
try:
    handle = ExPASy.get_sprot_raw(sid)
    seq = SeqIO.read(handle,'swiss')
    SeqIO.write(seq, sid+'.genbank.txt','genbank')
    print ('Sequence length',len(seq))
except Exception:
    print ('Sequence not found')

# Uniprot 2: This code is also possible...
# from Bio import ExPASy, SeqIO
# sid = input('Sequence id? ')
# handle = ExPASy.get_sprot_raw(sid)
# seq = SeqIO.read(handle,'swiss')
# SeqIO.write(seq, sid+'.genbank.txt','genbank')
# print ('Sequence length',len(seq))



