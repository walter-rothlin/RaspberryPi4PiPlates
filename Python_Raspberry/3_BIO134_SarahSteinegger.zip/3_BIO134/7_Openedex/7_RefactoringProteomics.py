# -*- coding: utf-8 -*-
"""
Created on Sun Jul 21 07:43:53 2019

@author: sara
"""

# Sara Steinegger
# 21.07.2019

# Refactoring: Proteomics