# -*- coding: utf-8 -*-

def to_fasta(sid):
    fyle=open(sid+'.genbank.txt')
    l=fyle.readlines()
    s='>Header\n'
    found_origin=0
    for i,line in enumerate(l):
        if found_origin==1:
            t=line.upper().split()[1:]
            s+=''.join(t)+'\n'
        if line[:6]=='ORIGIN':
            found_origin=1
    s=s[:-2]
    print (s)
    #write fasta string to new file
    fyle.close()
    out = open(sid+'_custom.fasta','w')
    out.write(s)
    out.close()

def to_genbank(sid):
    fyle=open(sid+'.fasta.txt')
    l=fyle.readlines()
    s='dummy header\nORIGIN\n'
    for i,line in enumerate(l):
        if i==0:
            pass
        else:
            r=line.lower().strip()
            num=(i-1)*60+1
            s+='{:9d}'.format(num)
            for j in range((len(r)-1)//10+1):
                s+=' '+r[j*10:(j+1)*10]
            s+='\n'
    s+='\n//'
    print (s)
    #write genbank string to new file
    fyle.close()
    out = open(sid+'_custom.genbank','w')
    out.write(s)
    out.close()

print ('\nFasta code:\n')
to_fasta('B4F440')
print ('\n\nGenbank code:\n')
to_genbank('B4F440')

