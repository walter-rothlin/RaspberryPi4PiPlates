# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 12:25:07 2019

@author: sara
"""

# Sara Steinegger
# 19.07.2019

# Functions with a print statement

# Question 1
def printvar():
    print(5)
# Prints nothing
# The function is not called and is therefore not carried out.

# Question 2
def printvar():
    print(5)
printvar()
# Prints 5
# The function is called and is therefore carried out.

# Querstion 3
def printvar():
    print(5)
printvar(5)
# It gives an error!
# printvar() takes no arguments, but one was given

# Question 4
def printvar(a):
    print(a)
printvar(5)
# Prints 5

# Question 5
def printvar(a):
    printvar(a)
printvar()
# It gives an error!
# The function printvar() requires one argument, but none is given







