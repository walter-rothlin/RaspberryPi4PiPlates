# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 11:43:44 2019

@author: sara
"""

# Sara Steinegger
# 17.07.2019

# split() and join()



# split()
s1 = "50,46,,12"
l1 = s1.split(",")
print("l1:", l1)

s2 = "50 46   12"
l2 = s2.split()
print("l2:", l2)

# split() also removes line endings, but not when it contains an argument
s1 = '50 46  \n  12\r\n'
l1 = s1.split()
print('l1:',l1)

s2 = '50,46\n,,12\r\n'
l2 = s2.split(',')
print('l2:',l2)



# join()
# Making a string out of lists (kind of the opposite of .split())
l = ['50', '46', '12']
s1 = "".join(l)
s2 = "*".join(l)
s3 = '"'.join(l)
s4 = str(l)
print('s1:',s1)
print('s2:',s2)
print('s3:',s3)
print('s4:',s4)



# Exercise: split() and join()
import copy
s = 'dfkfje*jfdn*pwndnv*sfkjadjbvbjbajbfkaj*nkd*nvndlanakndndhnfajnja*lsdkjf*cevgfjh**nfe*en*m\r\n'
s1 = copy.deepcopy(s)

s1 = s1.split()
s1 = "".join(s1)
s1 = s1.split("*")
s1 = "".join(s1)
print(len(s1))

