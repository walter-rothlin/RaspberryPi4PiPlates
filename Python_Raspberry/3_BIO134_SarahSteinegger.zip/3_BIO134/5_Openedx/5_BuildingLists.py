# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 09:10:54 2019

@author: sara
"""

# Sara Steinegger
# 16.07.2019

# Exercises on building lists

# Auto-checker: assembling a list
bases = ["A", "C", "G", "T"]
codons = []

for b1 in bases:
    for b2 in bases:
        for b3 in bases:
            if (b1!=b2) and (b2!=b3):
                codon = b1+b2+b3
                codons.append(codon)
print(codons)
print(codons[29])



# Auto-checker: select bases 1
lys = ['z', 'a', 't', 'e', 'z', 'a', 'w', 'r',
       'w', 'z', 'g', 'i', 's', 'h', 'g', 'f',
       'w', 'w', 'u', 'f', 'y', 'n', 'g', 'l',
       'k', 'c', 'o', 'j', 'o', 'y', 'q', 'k',
       'w', 'z', 'm', 'y', 'a', 'd', 'e', 'y',
       'r', 's', 'h', 'm', 'x', 'c', 'd', 'b',
       'm', 'v', 'o', 'k', 'n', 'e', 'y', 'j',
       'g', 'i', 'v', 'i', 'x', 'i', 'l', 'b',
       'x', 'u', 'm', 'd', 'm', 'j', 'v', 'y',
       't', 'h', 'b', 'x', 'y', 'e', 'm', 'm',
       't', 'x']

dna = ['z', 'a', 't', 'e', 'z', 'a', 'w', 'r',
       'w', 'z', 'g', 'i', 's', 'h', 'g', 'f',
       'w', 'w', 'u', 'f', 'y', 'n', 'g', 'l',
       'k', 'c', 'o', 'j', 'o', 'y', 'q', 'k',
       'w', 'z', 'm', 'y', 'a', 'd', 'e', 'y',
       'r', 's', 'h', 'm', 'x', 'c', 'd', 'b',
       'm', 'v', 'o', 'k', 'n', 'e', 'y', 'j',
       'g', 'i', 'v', 'i', 'x', 'i', 'l', 'b',
       'x', 'u', 'm', 'd', 'm', 'j', 'v', 'y',
       't', 'h', 'b', 'x', 'y', 'e', 'm', 'm',
       't', 'x']
rna = ['z', 'a', 't', 'e', 'z', 'a', 'w', 'r',
       'w', 'z', 'g', 'i', 's', 'h', 'g', 'f',
       'w', 'w', 'u', 'f', 'y', 'n', 'g', 'l',
       'k', 'c', 'o', 'j', 'o', 'y', 'q', 'k',
       'w', 'z', 'm', 'y', 'a', 'd', 'e', 'y',
       'r', 's', 'h', 'm', 'x', 'c', 'd', 'b',
       'm', 'v', 'o', 'k', 'n', 'e', 'y', 'j',
       'g', 'i', 'v', 'i', 'x', 'i', 'l', 'b',
       'x', 'u', 'm', 'd', 'm', 'j', 'v', 'y',
       't', 'h', 'b', 'x', 'y', 'e', 'm', 'm',
       't', 'x']

for i in lys:
    if i!='a' and i!='c' and i!='g' and i!='t':
        dna.remove(i)
for i in lys:
    if i!='a' and i!='c' and i!='g' and i!='u':
        rna.remove(i)
if len(dna)>len(rna):
    print(dna)
else:
    print(rna)



# Auto-checker: select bases 2
lys1 = ['z', 'a', 't', 'e', 'z', 'a', 'w', 'r',
       'w', 'z', 'g', 'i', 's', 'h', 'g', 'f',
       'w', 'w', 'u', 'f', 'y', 'n', 'g', 'l',
       'k', 'c', 'o', 'j', 'o', 'y', 'q', 'k',
       'w', 'z', 'm', 'y', 'a', 'd', 'e', 'y',
       'r', 's', 'h', 'm', 'x', 'c', 'd', 'b',
       'm', 'v', 'o', 'k', 'n', 'e', 'y', 'j',
       'g', 'i', 'v', 'i', 'x', 'i', 'l', 'b',
       'x', 'u', 'm', 'd', 'm', 'j', 'v', 'y',
       't', 'h', 'b', 'x', 'y', 'e', 'm', 'm',
       't', 'x']
dna = lys1[:]
rna = lys1[:]

dna_bases = ["a", "c", "g", "t"]
rna_bases = ["a", "c", "g", "u"]

for i in lys1:
    if i not in dna_bases:
        dna.remove(i)
for j in lys1:
    if j not in rna_bases:
        rna.remove(j)
            
if len(dna)>len(rna):
    print(dna)
else:
    print(rna)
            
    















            