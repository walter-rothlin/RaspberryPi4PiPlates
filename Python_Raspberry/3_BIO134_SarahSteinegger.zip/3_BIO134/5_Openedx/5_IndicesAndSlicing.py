# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 10:34:30 2019

@author: sara
"""

# Sara Steinegger
# 16.07.2019

# Question: Indices & Slicing
lyst = [5, 8, 2, 4, 6, 9, 1]

# Question 1
print(lyst[2])

# Question 2
print(lyst[-2])

# Question 3
print(lyst[10])
# Gives an error!!!

# Question 4
print(lyst[2:5])

# Question 5
print(lyst[:3])

# Question 6
print(lyst[5:1])

# Question 7
print(lyst[5:9])

# Question 8
print(lyst[8:10])
# Gives an empty list!!!











