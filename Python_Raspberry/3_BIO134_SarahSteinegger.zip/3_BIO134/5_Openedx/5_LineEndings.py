# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 16:29:52 2019

@author: sara
"""

# Sara Steinegger
# 16.07.2019

# Line endings on Mac and Windows
# Usually you don't have to worry about different end of lines
# when using python to read and write files. Nevertheless,
# sometimes it may be practical to know which end of lines have
# been used exactly. For this, the following code can be used:
#fyle = open('MyFile.txt','r',newline='')
#l = fyle.readlines()
#print(l)
#fyle.close()



# strip()
# When working with text files using Python, you may want get rid of any
# line endings. You can do this using .strip()
# (removes any whitespace from ends, including spaces, tabs and newlines)
s = "string \n"
s = s.strip()
print(s)
# This prints: string
# The strip() function can also be used to strip off specified characters
s = "o    stringss"
s = s.strip("os")
print(s)
# PrintS: string



# Exercise: copy
crick_1 = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/5_Openedx/crick.txt", "r")
crick_lines = crick_1.readlines()
crick_1.close()
print(crick_lines)

crick_2 = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/5_Openedx/crick_copy.txt", "w")
for el in crick_lines:
    crick_2.write(el[:-1])
crick_2.close()

control = open('crick_copy.txt','r')
s = control.read()
print(s)
control.close()