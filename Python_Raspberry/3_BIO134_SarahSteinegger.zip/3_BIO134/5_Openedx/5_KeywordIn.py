# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 10:00:26 2019

@author: sara
"""

# Sara Steinegger
# 16.07.2019

# The key-word "in"

# Exercise: keyword "in"
l = ['a', 'c', 'd', 'e', 'c', 'y']
found_c = False
for s in l:
    if s == 'c':
        found_c = True
if found_c:
    print ('Found it!')

# Shorter version of this code
l = ['a', 'c', 'd', 'e', 'c', 'y']
if 'c' in l:
    print ('Found it!')  