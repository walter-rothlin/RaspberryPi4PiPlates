# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 11:02:21 2019

@author: sara
"""

# Sara Steinegger
# 16.07.2019

# Combining Lists
line = 'the quick brown fox jumps over a lazy dog'
lett = ' abcdefghijklmnopqrstuvwxyz'
lline = list(line)
n = []
for x in line:
    n.append(lett.index(x))
z = zip(n,lline)



# Synonyms vs. copies
# If we have
A = X
B = X[:]
# and then X mutates,
# A will do the same. But B will retain an old copy.