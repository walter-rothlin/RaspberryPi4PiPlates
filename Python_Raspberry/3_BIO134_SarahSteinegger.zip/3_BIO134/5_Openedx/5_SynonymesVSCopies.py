# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 11:16:33 2019

@author: sara
"""

# Sara Steinegger
# 16.07.2019

# Questions: Synonymes vs. copies

# Question 1
a = [3,6,2]
b = a
b[2] = 8
b = [3]
# a = [3,6,8,]
# b = [3]

# Question 2
a = [3, 2, 4]
b = [7, a]
c = a[:]
d = b[:]
b[1][0] = 10
b[0] = 6
a[2] = 50
# a = [10, 2, 50]
# b = [6, [10,2,50]]
# c = [3,2,4]
# d = [7, [10,2,50]]

# Question 3
a = [3, 2, 4]
b = [7, a]
c = a[:]
d = b[:]
b[1] = 10
b[0] = 6
a[2] = 50
# a = [3,2,50]
# b = [6,10]
# c = [3,2,4]
# d = [7, [3,2,50]]



# Example: copy.deepcopy() 1
import copy
a = [3, 2, 4]
b = [7, a]
d = copy.deepcopy(b)
b[1][0] = 10
b[0] = 6
a[2] = 50
print('a:',a)
print('b:',b)
print('d:',d)



# Example: copy.deepcopy() 2
import copy
a = [3,2,4]
b = [7,copy.deepcopy(a)]
b[1][0] = 10
b[0] = 6
a[2] = 50
print('a:',a)
print('b:',b)



