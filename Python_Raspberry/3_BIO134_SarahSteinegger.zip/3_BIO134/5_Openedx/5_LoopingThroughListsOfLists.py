# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 11:34:24 2019

@author: sara
"""

# Sara Steinegger
# 16.07.2019$

# Looping throu a list of lists
import copy

l = [[5, 4, 9], [7, 8], [2, 5, 6]]
lnew = copy.deepcopy(l)
for i, el in enumerate(l):
    for j, el2 in enumerate(el):
        lnew[i][j] = l[i][j] + 1
print(lnew)