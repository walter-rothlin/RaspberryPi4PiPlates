# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 12:19:03 2019

@author: sara
"""

# Sara Steinegger
# 17.07.2019

# Analyzing text files

# Exercise: txt-file 1
darwin = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/5_Openedx/darwin.txt", "r")
d_length = []
length = 0

for i in range(4):
    d = darwin.readline()
    d = d.split(" ")
    for i,el in enumerate(d):
        if i==2:
            length += len(el)
            d_length.append(el)
mean_length=length/4
print("words:", d_length)
print("absolute length:", length)
print("mean length", mean_length)
darwin.close()



# Exercise: txt-file 2
darwin_1 = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/5_Openedx/darwin.txt", "r")
lys = darwin_1.readlines()
length = 0

for i,el in enumerate(lys):
    lys[i] = el.split(" ")
for i, el in enumerate(lys):
    for j, el2 in enumerate(el):
        if j == 2:
            length += len(el2)
mean_length = length/4

print("Mean length:", mean_length)



# Exercise: csv-file
values = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/5_Openedx/values.csv", "r")
v = values.readlines()
v_sum = 0

for i, el in enumerate(v):
    v[i] = "".join(el.split()).split(",")
for i, el in enumerate(v):
    for j, el2 in enumerate(el):
        v_sum += int(el2)
print(v_sum)









