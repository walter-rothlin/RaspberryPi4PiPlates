# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 09:03:03 2019

@author: sara
"""

# Sara Steinegger
# 16.07.2019

# Tuples

# Auto-checker: Tuples are immutable
# The problem with copies and synonyms is only relevant
# for mutable types. As the bok explains, tuples are
# immutable lists and you can't do things like
# sort them or append or delete items.
# Use spyder to test whether it's possible to change
# single values in tuples
tuple1 = ("This", "is", "a", "tuple")
#tuple1[2] = "no"



# Auto-checker: Creating tuples
t = (5, 4, 2) # tuple
s = 5,4,2 # Also a tuple
print(type(s))
