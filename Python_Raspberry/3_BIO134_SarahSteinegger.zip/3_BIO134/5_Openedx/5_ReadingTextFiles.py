# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 16:18:57 2019

@author: sara
"""

# Sara Steinegger
# 16.07.2019

# Reading text files 2
thompson_text = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/5_Openedx/thompson.txt", "r")
text_l = thompson_text.readlines()
print(text_l[89][:48])
thompson_text.close()

# As we have sen before, .readlines() reads the data from a file and returns
# the lines as strings in a list.  Sometimes, it may however be more practical
# to have all text in one single string. This can be done using .read()
thompson_text = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/5_Openedx/thompson.txt", "r")
text_s = thompson_text.read()
print(text_s[6183:6235])
thompson_text.close()