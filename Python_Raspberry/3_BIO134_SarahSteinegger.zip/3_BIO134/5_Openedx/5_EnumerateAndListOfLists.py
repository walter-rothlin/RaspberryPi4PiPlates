# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 10:43:07 2019

@author: sara
"""

# Sara Steinegger
# 16.07.2019

# Exercise: Enumerate & Slicing
lys = ["The", "sun", "is", "shining"]
i = 0
for w in lys:
    print(i, w, end=" ")
    i += 1
# Using range()
lys = ["The", "sun", "is", "shining"]   
for i in range(len(lys)):
    print(i, lys[i], end=" ")
# Using enumerate()
lys = ["The", "sun", "is", "shining"]
for i, j in enumerate(lys):
    print(i, j, end=" ")



# Exercise: Lists of lists 1
lyst = [[2, 4], [1, 5, 7], [2, 6]] 
lyst[1].append(8)
print(lyst)



# Exercise: Lists of lists 2
lyst = [[2, 4], [1, [5, 9], 7], [2, 6]] 
lyst[1][1].append(3)
print(lyst)



# Exercise: lists of lists 3
lyst = [[2, 4], [1, [5, 9], 7], [[2], 6]] 
lyst[2][0].append(8)
print(lyst)



# ExerciseL lists of lists 4
lyst = [[2, 4], [1, [5, 9], 7], [[2], 6]] 
lyst[2][0].remove(2)
print(lyst)


