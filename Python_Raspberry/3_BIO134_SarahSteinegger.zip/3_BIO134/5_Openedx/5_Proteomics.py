# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 13:31:03 2019

@author: sara
"""

# Sara Steinegger
# 17.07.2019

# Exercise: Proteomics
brain = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/5_Openedx/human_brain_proteins.csv", "r")
plasma = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/5_Openedx/human_plasma_proteins.csv", "r")
brain_all = brain.readlines()
plasma_all = plasma.readlines()
brain_only = []
plasma_only = []
brain_and_plasma = []

del brain_all[0] # Get rid of the header
del plasma_all[0] # Get rid of the header

def revision(a):
    for i, el in enumerate(a):
        a[i] = "".join(el.split()).split(",")
revision(brain_all)
revision(plasma_all)

brain_bioseq_names = []
plasma_bioseq_names = []

for el in brain_all:
    for i,el2 in enumerate(el):
        if i==0:
            brain_bioseq_names.append(el2)
        
            
print(brain_all)            
    





