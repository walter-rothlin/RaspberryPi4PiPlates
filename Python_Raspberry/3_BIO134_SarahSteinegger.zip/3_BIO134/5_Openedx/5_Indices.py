# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 10:05:25 2019

@author: sara
"""

# Sara Steinegger
# 16.07.2019

# Indices

line = "the quick brown fox jumps over the lazy dog"

# Print elements/items from the line
print(line[0])
print(line[-1]) # last element
print(line[-2])

# Slicing the line
print(line[0:3])
print(line[-4:])
print(line[-4:-1]) # Without last element
print(line[38:41])

# How long is the line
print(len(line))

# Create a list with list()
l_list = list(line)
print(l_list, len(l_list))

# Create a tuple with tuple()
l_tuple = tuple(line)
print(l_tuple, len(l_tuple))

# Example 1
for i in range(0, 100, 9):
    print(i, line[i:i+9])

# Example 2
fox = "quick"
dog = "lazy"
[fox, dog] = [dog, fox]
print(fox, dog)

# Example 3: Indices
lett = " abcdefghijklmnopqrstuvwxyz"
for x in lett:
    print(x in line)
    print(x, line.index(x))

# Summary
# Strings and tuples can be indexed just like lists (but only lists are mutable).
# Use len() to get the length
# Negative indices start from the end
# Use enumerate() to pair elements with their indices
# Implicit indexing allows multiple assignments in one line
# Some things like range() ar not lists and can't be printed,
# unless you turn them into lists or tuples first.



# Example 3: Indices (continued)
line = 'the quick brown fox jumps over a lazy dog'
lett = ' abcdefghijklmnopqrstuvwxyz'
lettlist = list(lett)
for i in range(len(lettlist)):
    lettlist[i] = [lettlist[i]]
for i,x in enumerate(line):
    k = lett.index(x)
    lettlist[k].append(i)
print(lettlist)


