# -*- coding: utf-8 -*-

#problem 3        
bases = 'ATCG'
l = []
for b1 in bases:
    for b2 in bases:
        for b3 in bases:
            if b1 != b2:
                l.append(b1+b2+b3)
l.sort()
print(l[26])














