# -*- coding: utf-8 -*-

#problem 2

#using in
lys = [['apple', 'grape', 'strawberry'], ['hi', 'hello'], ['garden', 'flower', 'grass']]
ind = 0
for sublys in lys:
    for word in sublys:
        print(ind, word)
        ind += 1


        













