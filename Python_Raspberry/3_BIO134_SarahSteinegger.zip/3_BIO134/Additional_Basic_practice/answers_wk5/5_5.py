# -*- coding: utf-8 -*-

#problem 5
fyle = open("some_more_numbers.txt")
l = fyle.readlines()
fyle.close()
summe = 0
for line in l:
    second_number = line.split()[1]
    summe += int(second_number)
print(summe)
















