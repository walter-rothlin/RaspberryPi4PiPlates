# -*- coding: utf-8 -*-

#problem 2

#using in range()
lys = [['apple', 'grape', 'strawberry'], ['hi', 'hello'], ['garden', 'flower', 'grass']]
ind = 0
for i in range(len(lys)):
    for j in range(len(lys[i])):
        print(ind, lys[i][j])
        ind += 1


        













