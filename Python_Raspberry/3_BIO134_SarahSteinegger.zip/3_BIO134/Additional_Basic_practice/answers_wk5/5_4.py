# -*- coding: utf-8 -*-

#problem 4
fyle = open("some_numbers.txt")
l = fyle.readlines()
fyle.close()
summe = 0
for line in l:
    summe += int(line.strip())
print(summe)
















