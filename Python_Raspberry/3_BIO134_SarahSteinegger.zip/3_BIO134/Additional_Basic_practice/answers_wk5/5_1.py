# -*- coding: utf-8 -*-

#problem 1
lys = ['apple', 'grape', 'strawberry', 'pear']
#option 1, enumerate:
for i, fruit in enumerate(lys):
    print(i, fruit)
#option 2, in range:
for i in range(len(lys)):
    print(i, lys[i])
#option 3, in:
i = 0
for fruit in lys:
    print(i, fruit)
    i += 1









