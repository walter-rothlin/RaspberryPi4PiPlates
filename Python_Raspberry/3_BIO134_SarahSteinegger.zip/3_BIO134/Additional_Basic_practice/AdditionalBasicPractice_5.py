# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 14:35:56 2019

@author: sara
"""

# Sara Steinegger
# 01.08.2019

# Additional Basic Practice: week 5



# Problem 1
lys = ['apple', 'grape', 'strawberry', 'pear']

# Using enumerate()
for i,fruit in  enumerate(lys):
    print(i, fruit)

# Using in range()
for i in range(len(lys)):
    print(i, lys[i])

# Using in
counter = 0
for fruit in lys:
    print(counter, fruit)
    counter += 1



# Problem 2
lys = [['apple', 'grape', 'strawberry'],
       ['hi', 'hello'],
       ['garden', 'flower', 'grass']]
counter = 0

for i,el in enumerate(lys):
    for j,el1 in enumerate(el):
        print(counter, lys[i][j])
        counter += 1



# Problem 3
bases = ["A", "C", "G", "T"]
codons = []

for base1 in bases:
    for base2 in bases:
        for base3 in bases:
            if base1 != base2:
                codons.append(base1+base2+base3)
print(sorted(codons)[42])



# Problem 4
fyle = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/Additional_Basic_practice/some_numbers.txt", "r")
numbers = fyle.readlines()
fyle.close()

for i in range(len(numbers)):
    numbers[i] = int(numbers[i].strip())
print(sum(numbers))



# Problem 5
fyle = open("C://Users/sara/Desktop/BIO134_Programming _in_Biology/Additional_Basic_practice/some_more_numbers.txt", "r")
numbers = fyle.readlines()
fyle.close()
ssn = 0

for i in range(len(numbers)):
    numbers[i] = numbers[i].split()
    for j in range(len(numbers[i])):
        numbers[i][j] = int(numbers[i][j])
        if j == 1:
            ssn += numbers[i][j]
print(ssn)