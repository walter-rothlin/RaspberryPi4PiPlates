# -*- coding: utf-8 -*-
"""
Created on Tue Jul 30 10:23:27 2019

@author: sara
"""

# Sara Steinegger
# 30.07.2019

# Additional Basic Practice: week 3



# Problem 1
import numpy.random as rd
rd.seed(0)
n = 10
numbers = []

for i in range(n):
    numbers.append(rd.randint(1,16))
print(numbers)

# Solution
import numpy.random as rd
rd.seed(0)
for i in range(10):
    print(rd.randint(1, 16))




# Problem 2
import numpy.random as rd
rd.seed(0)
n = 300
numbers = []
count = 0

for i in range(n):
    r = rd.randint(1,16)
    numbers.append(r)
    if r == 4:
        count += 1
print("The occurrences of the number 4: {:d}".format(count))

# Solution
import numpy.random as rd
rd.seed(0)
fours = 0
for i in range(300):
    r = rd.randint(1, 16)
    if r == 4:
        fours += 1
print(fours)




# Problem 3
#lys = [8, 12, 4, 3, 20, 5, 2]$
lys = [3746453728292834648473, 37363536774847463524, 857575656454534436353, 9958585746363588374,
       3635252424253636371423, 37362626262514425262, 83737362625252242425, 38373736225252425253]
ln = 0
for n in lys:
    if n > ln:
        ln = n
print(ln)

# Solution
lys = [3746453728292834648473, 37363536774847463524, 857575656454534436353, 9958585746363588374, 
       3635252424253636371423, 37362626262514425262, 83737362625252242425, 38373736225252425253]
maximum = 0
for number in lys:
    if number > maximum:
        maximum = number
print(maximum)



# Problem 4
bases = ["A", "T", "C", "G"]
co2_bases = []
count = 0

for i in range(len(bases)):
    for j,el in enumerate(bases):
        co2_bases.append(bases[i]+el)
        count += 1
print("This generates {:d} combinations.".format(count))

# Solution
bases = ['A','T','C','G']
for base1 in bases:
    for base2 in bases:
        print(base1+base2)




# Problem 5
# lys = [1, 1, 0, 0, 1, 0, 0, 0, 1, 0]
lys = [0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0 ,1, 0, 1, 0, 1, 0, 1, 0, 1,
       0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0 ,0 ,0, 0, 1, 0, 1, 1, 0, 0,
       1, 0] 
n0 = 0
n1 = 0
ln0 = 0
ln1 = 0
for number in lys:
    if number == 0:
        n0 += 1
        if n1 > ln1:
            ln1 = n1
        n1 = 0
    if number == 1:
        n1 += 1
        if n0 > ln0:
            ln0 = n0
        n0 = 0
    print(n0, end=" ")

# Solution
lys = [1, 1, 0, 0, 1, 0, 0, 0, 1, 0]
lys = [0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0 ,1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 
       1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0 ,0 ,0, 0, 1, 0, 1, 1, 0, 0, 1, 0]
zeros = 0
for number in lys:
    if number == 0:
        zeros += 1
    else:
        zeros = 0
    print(zeros, end=' ')

    
    
    
 