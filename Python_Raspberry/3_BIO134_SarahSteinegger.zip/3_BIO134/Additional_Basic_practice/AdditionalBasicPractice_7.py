# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 16:24:10 2019

@author: sara
"""

# Sara Steinegger
# 01.08.2019

# Additional Basic Practice: week 6



# Problem 1
def hi(name):
    print("Hi", name, "how are you?")
hi("Christian")
hi("Noemi")



# Problem 2
def hi2(name):
    line = "Hi "+name+" how are you?"
    return line
hi2("Martin")
print(hi2("Emma"))



# Problem 3
def sum_project