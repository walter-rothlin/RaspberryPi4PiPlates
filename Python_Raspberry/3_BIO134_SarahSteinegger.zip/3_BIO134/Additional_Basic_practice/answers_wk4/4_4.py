# -*- coding: utf-8 -*-

#problem 4
import numpy.random as rd
rd.seed(0)
for i in range(5):
    summe = 0
    for j in range(10):
        r = rd.randint(1,7)
        summe += r
    print(summe)









