# -*- coding: utf-8 -*-

#problem 1

#lys1 = [6, 7, 8]
#lys2 = [5, 2, 1]
lys1 = [9, 12, 45, 12, 398, 24, 76, 21, 11, 12, 198, 87, 876, 34]
lys2 = [187, 23, 435, 761, 73, 3, 4, 987, 32, 46, 98, 107, 45, 1]

lys3 = len(lys1)*[0]
for i in range(len(lys1)):
    lys3[i] = lys1[i] * lys2[i]
#print(lys3)
print(sum(lys3))






