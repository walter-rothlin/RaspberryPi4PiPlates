# -*- coding: utf-8 -*-

#problem 3      
lys1 = [7, 5, 43, 7, 90, 4, 6, 49, 2]
lys2 = [5, 46, 8, 20, 57, 9, 8, 2, 3]
lys3 = 9 * [0]
for i in range(9):
    if i <= 3:
        lys3[i] = lys1[i] + lys2[i]
    else:
        lys3[i] = lys1[i] * lys2[i]
#print(lys3)
print(sum(lys3))









