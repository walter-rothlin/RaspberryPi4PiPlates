# -*- coding: utf-8 -*-

#problem 2
import numpy.random as rd

rd.seed(4)

r = 0
while r!=12:
    r = rd.randint(1,13)
    print(r)







