# -*- coding: utf-8 -*-

#problem 4
bases = ['A','T','C','G']
for base1 in bases:
    for base2 in bases:
        print(base1+base2)






