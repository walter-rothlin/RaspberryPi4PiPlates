# -*- coding: utf-8 -*-

#problem 1
import numpy.random as rd
rd.seed(0)
for i in range(10):
    print(rd.randint(1, 16))

