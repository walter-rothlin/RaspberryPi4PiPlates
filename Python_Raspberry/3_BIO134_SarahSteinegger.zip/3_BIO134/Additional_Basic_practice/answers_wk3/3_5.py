# -*- coding: utf-8 -*-

#problem 5
lys = [1, 1, 0, 0, 1, 0, 0, 0, 1, 0]
lys = [0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0 ,1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 
       1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0 ,0 ,0, 0, 1, 0, 1, 1, 0, 0, 1, 0]
zeros = 0
for number in lys:
    if number == 0:
        zeros += 1
    else:
        zeros = 0
    print(zeros, end=' ')





