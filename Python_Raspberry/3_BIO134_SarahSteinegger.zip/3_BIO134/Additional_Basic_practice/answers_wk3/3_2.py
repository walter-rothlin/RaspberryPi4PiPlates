# -*- coding: utf-8 -*-

#problem 2
import numpy.random as rd
rd.seed(0)
fours = 0
for i in range(300):
    r = rd.randint(1, 16)
    if r == 4:
        fours += 1
print(fours)



