# -*- coding: utf-8 -*-

#problem 5
#l = [234, 1, 13]
l = [485, 38, 1, 948, 93, 43, 9243, 840, 46, 3, 814]
s = ''
for i in range(len(l)):
    s += '{:05d}'.format(l[i])
print(s)