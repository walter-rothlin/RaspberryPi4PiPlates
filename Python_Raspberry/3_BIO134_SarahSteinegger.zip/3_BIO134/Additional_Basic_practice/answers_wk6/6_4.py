# -*- coding: utf-8 -*-

#problem 4
s = 'jnvhe***vnekjasbvk###jdndhdqv'
snew = s.partition('***')[2].partition('###')[0]
print(snew)