# -*- coding: utf-8 -*-

#problem 3
#s = 'anckddjkwuslpe'
s = 'pwueofaevndakenadlkjaewqpnxmmmsncebewapadjsnjefhlajlajhliwsqapozujd'
snew = ''
for i in range(0,len(s),6):
    snew += s[i:i+3].upper()
print(snew)
