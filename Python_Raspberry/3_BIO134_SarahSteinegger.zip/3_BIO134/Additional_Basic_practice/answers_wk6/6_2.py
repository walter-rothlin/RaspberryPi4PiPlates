# -*- coding: utf-8 -*-

#problem 2
ages = {'Sarah': 23, 'Ron': 25, 'Louis': 23, 'Linda': 28, 'Marion': 21, 'Jack': 23, 'Mary': 25}
reverse = {}
for name in ages:
    age = ages[name]
    if age not in reverse:
        reverse[age] = []
    reverse[age].append(name)
print(reverse)
