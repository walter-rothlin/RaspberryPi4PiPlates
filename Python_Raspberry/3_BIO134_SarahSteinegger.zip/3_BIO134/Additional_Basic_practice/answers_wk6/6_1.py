# -*- coding: utf-8 -*-

#problem 1
marathon = {'Sarah': 3.89, 'Ron': 4.21, 'Louis': 3.62, 'Linda': 4.69, 'Marion': 5.20, 'Jack': 4.79, 'Mary': 3.34}
women = ['Marion', 'Linda', 'Sarah', 'Mary']
summe = 0
for name in women:
    summe += marathon[name]
print ('mean time:', summe/len(women))
