# -*- coding: utf-8 -*-
"""
Created on Tue Jul 30 09:42:45 2019

@author: sara
"""

# Sara Steinegger
# 30.07.2019

# Additional Basic Practice: week 2




# Problem 1
n = 4
for i in range(n):
    x = i*3
    y = x+4
    print(x, y)

# Solution
n = 4
for i in range(0, 3*n, 3):
    print(i, i+4)




# Problem 2
n = 12
x = 5000
for i in range(n):
    x += (x/100)*2
print(x)

# Solution
n = 12
saving = 5000
for i in range(n):
    saving = saving*1.02
print(saving)




# Problem 3
n = 21
factorial_n = 1
for i in range(1, n+1):
    factorial_n *= i
print("n = {:d}, factorial og n = {:d}".format(n, factorial_n))

# Solution
n = 21
fact = 1
for i in range(1, n+1):
    fact *= i
print('factorial:', fact)




# Problem 4
# 1
lys = [14, 165, 823, 34, 91653, 132, 9365, 1543, 129, 3765, 28764, 92846, 1649, 26, 291]
lys_sum = 0
for el in lys:
    lys_sum += el
print(lys_sum)
# 2
lys = [14, 165, 823, 34, 91653, 132, 9365, 1543, 129, 3765, 28764, 92846, 1649, 26, 291]
lys_sum = 0
for i in range(len(lys)):
    lys_sum += lys[i]
print(lys_sum)

# Solution
lys = [14, 165, 823, 34, 91653, 132, 9365, 1543, 129, 3765, 28764, 92846, 1649, 26, 291]
summe = 0
for number in lys:
    summe += number
print('summe:', summe)



# Problem 5
lys = ['hi', 'sunny', 'strange', 'start', 'well', 'happy', 'start', 'done']
count = 0
for el in lys:
    if el=="start":
        count = 1
    if count == 1:
        print(el)

# Solution
lys = ['hi', 'sunny', 'strange', 'start', 'well', 'happy', 'start', 'done']
for word in lys:
    print(word)
print()
print('after modification:')
flag = 0
# flage = False (flag is a boolean instead of an integer)
for word in lys:
    if word == 'start':
        flag = 1
        # flag = True
    if flag == 1:
        print(word)     
    
