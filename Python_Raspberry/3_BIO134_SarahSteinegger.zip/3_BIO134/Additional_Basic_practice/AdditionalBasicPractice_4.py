# -*- coding: utf-8 -*-
"""
Created on Tue Jul 30 11:02:56 2019

@author: sara
"""

# Sara Steinegger
# 30.07.2019

# Additional Basic Practice: week 4




# Problem 1
# 1
# lys1 = [6, 7, 8]
# lys2 = [5, 2, 1]
lys1 = [9, 12, 45, 12, 398, 24, 76, 21, 11, 12, 198, 87, 876, 34]
lys2 = [187, 23, 435, 761, 73, 3, 4, 987, 32, 46, 98, 107, 45, 1]
lys3 = []
for i in range(len(lys1)):
    lys3.append(lys1[i]*lys2[i])
#print(lys3)
print(sum(lys3))    

# 2
# lys1 = [6, 7, 8]
# lys2 = [5, 2, 1]
lys1 = [9, 12, 45, 12, 398, 24, 76, 21, 11, 12, 198, 87, 876, 34]
lys2 = [187, 23, 435, 761, 73, 3, 4, 987, 32, 46, 98, 107, 45, 1]
lys3 = []
for i,el in enumerate(lys1):
    lys3.append(el*lys2[i])
#print(lys3)
print(sum(lys3))

# 3
# lys1 = [6, 7, 8]
# lys2 = [5, 2, 1]
lys1 = [9, 12, 45, 12, 398, 24, 76, 21, 11, 12, 198, 87, 876, 34]
lys2 = [187, 23, 435, 761, 73, 3, 4, 987, 32, 46, 98, 107, 45, 1]
lys3 = []   
for i,el in enumerate(lys1):
    for j,el1 in enumerate(lys2):
        if i==j:
            lys3.append(el*el1)
#print(lys3)
print(sum(lys3))

# Solution
lys1 = [9, 12, 45, 12, 398, 24, 76, 21, 11, 12, 198, 87, 876, 34]
lys2 = [187, 23, 435, 761, 73, 3, 4, 987, 32, 46, 98, 107, 45, 1]

lys3 = len(lys1)*[0]
for i in range(len(lys1)):
    lys3[i] = lys1[i] * lys2[i]
#print(lys3)
print(sum(lys3))




# Problem 2
import numpy.random as rd
rd.seed(4)
numbers = []

r = 0
while r != 12:
    r = rd.randint(1,13)
    if r == 12:
        break
    numbers.append(r)    
print(numbers[-1]) # print the last number (before the first time 12 appears)

# Solution
import numpy.random as rd
rd.seed(4)

r = 0
while r!=12:
    r = rd.randint(1,13)
    print(r)




# Problem 3
lys1 = [7, 5, 43, 7, 90, 4, 6, 49, 2]
lys2 = [5, 46, 8, 20, 57, 9, 8, 2, 3]
lys3 = []
for i in range(len(lys1)):
    if i < 4:
        lys3.append(lys1[i]+lys2[i])
    else:
        lys3.append(lys1[i]*lys2[i])
print("The sum of the elements in the new list is:", sum(lys3))

# Solution
lys1 = [7, 5, 43, 7, 90, 4, 6, 49, 2]
lys2 = [5, 46, 8, 20, 57, 9, 8, 2, 3]
lys3 = 9 * [0]
for i in range(9):
    if i <= 3:
        lys3[i] = lys1[i] + lys2[i]
    else:
        lys3[i] = lys1[i] * lys2[i]
#print(lys3)
print(sum(lys3))




# Problem 4
import numpy.random as rd
rd.seed(0)
numbers = []
sum_numbers = []

for j in range(5):
    numbers = []
    for i in range(10):
        r = rd.randint(1,7)
        numbers.append(r)
    sum_numbers.append(sum(numbers))
print("The first sum I obtained:", sum_numbers[0])
print("The third sum I obtained:", sum_numbers[2])

count = 0
for i in range(len(sum_numbers)):
    if sum_numbers[i] > 35:
        count += 1
print("{:d} times the sum is larger than the expected mean, which is 35.".format(count))

# Solution
import numpy.random as rd
rd.seed(0)
for i in range(5):
    summe = 0
    for j in range(10):
        r = rd.randint(1,7)
        summe += r
    print(summe)