# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 15:42:22 2019

@author: sara
"""

# Sara Steinegger
# 01.08.2019

# Additional Basic Practice: week 6



# Problem 1
import statistics

marathon = {'Sarah': 3.89, 'Ron': 4.21, 'Louis': 3.62, 'Linda': 4.69,
            'Marion': 5.20, 'Jack': 4.79, 'Mary': 3.34}
women = ['Marion', 'Linda', 'Sarah', 'Mary']

women_values = []
for name in women:
    if name in marathon:
        women_values.append(marathon[name])
print(statistics.mean(women_values))



# Problem 2
ages = {'Sarah': 23, 'Ron': 25, 'Louis': 23, 'Linda': 28, 'Marion': 21,
        'Jack': 23, 'Mary': 25}
ages_reverse = {}

for names in ages:
    if ages[names] not in ages_reverse:
        ages_reverse[ages[names]] = []  
    ages_reverse[ages[names]].append(names)
print(ages_reverse)



# Problem 3
#s = 'anckddjkwuslpe'
s = 'pwueofaevndakenadlkjaewqpnxmmmsncebewapadjsnjefhlajlajhliwsqapozujd'
s_new = ""

for i in range(0, len(s), 6):
    s_new += s[i:i+3].upper()
print(s_new)



# Problem 4
s = 'jnvhe***vnekjasbvk###jdndhdqv'

#for i in range(len(s)):
    #while s[i:i+3]=="***":



# Problem 5
#l = [234, 1, 13]
l = [485, 38, 1, 948, 93, 43, 9243, 840, 46, 3, 814]
for number in l:
    #x = number
    print("{:05d}".format(number),end="")