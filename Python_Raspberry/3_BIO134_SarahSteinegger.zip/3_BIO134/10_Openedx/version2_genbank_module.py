from Bio import ExPASy, SeqIO

#------------------------------------------------------------------------------ 
def fetch_genbank(sid):
    try:
        handle = ExPASy.get_sprot_raw(sid)
        seq = SeqIO.read(handle,'swiss')
        SeqIO.write(seq, 'genbank/'+sid+'.genbank','genbank')
        print(sid,'sequence length',len(seq))
    except Exception:
        print (sid,'not found')
#------------------------------------------------------------------------------ 
def read_genbank(fname):
    f = open(fname)
    for p in SeqIO.parse(f,'genbank'):
        break
    f.close()
    return p.annotations['organism'],str(p.seq)
#------------------------------------------------------------------------------ 
