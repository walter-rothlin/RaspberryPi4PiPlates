# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import matplotlib.pyplot as plt
from Bio import ExPASy, SeqIO

def slyce(lyne,w):
    dic={}
    for i in range (len(lyne)-w+1):
        frag=lyne[i:i+w]
        if frag not in dic:
            dic[frag]=[]
        dic[frag].append(i)
    return dic

def match (l1,l2,w):
    dic1=slyce(l1,w)
    dic2=slyce(l2,w)
    both = []
    for s in dic1:
        if s in dic2:
            if s not in both:
                both.append(s)
    lis1=[]
    lis2=[]
    for s in both:
        #print (s+' : '+str(dic1[s])+str(dic2[s]))
        for pos1 in dic1[s]:
            for pos2 in dic2[s]:
                lis1.append(pos1)
                lis2.append(pos2)
    return lis1,lis2

def fetch_genbank(sid):
    try:
        handle = ExPASy.get_sprot_raw(sid)
        seq = SeqIO.read(handle,'swiss')
        SeqIO.write(seq, sid+'.genbank','genbank')
        print(sid,'sequence length',len(seq))
    except Exception:
        print (sid,'not found')

def read_genbank(fname):
    f = open(fname)
    for p in SeqIO.parse(f,'genbank'):
        break
    f.close()
    return p.annotations['organism'],str(p.seq)    

def plot(x,y,labelx,labely,w):
    plt.figure()
    plt.plot(x,y,'o')
    plt.xlabel(labelx)
    plt.ylabel(labely)
    plt.title('Dot plot with window size '+str(w))   
