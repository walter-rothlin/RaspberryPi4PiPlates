# -*- coding: utf-8 -*-
"""
Created on Sat Jul 27 13:26:08 2019

@author: sara
"""

# Sara Steinegger
# 27.07.2019

# Generating pairs
l = ['ball','clock','glass','table']
l_new = []


for i in range(len(l)):
    for j in range(i+1, len(l)):
        l_new.append([l[i], l[j]])
print(l_new)
    