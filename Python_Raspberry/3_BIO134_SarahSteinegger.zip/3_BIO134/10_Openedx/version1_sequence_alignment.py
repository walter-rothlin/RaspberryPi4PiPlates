#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from dotplot import match, plot, fetch_genbank, read_genbank
import matplotlib.pyplot as plt
    
####
#Test out the procedure using the Shakespeare lines
####

l1 = 'My care is loss of care, by old care done'
l2 = 'Your care is gain of care, by new care won'

x,y = match(l1,l2,5)
print('check step using Shakespear lines:', list(zip(x,y)))
plot(x, y, l1, l2, 5)



####
#Carry out procedure for ATP synthase subunit a in different animals
####

sids = ['P00846','Q95A26','Q9T9W0','Q2I3G9','Q9TA24']#ATPase
#generate genbank files
for sid in sids:
    fetch_genbank(sid)

w = 10
tot_dots = 0
for i in range(len(sids)):
    for j in range(i+1,len(sids)):
        sid1 = sids[i]
        anim1, seq1 = read_genbank(sid1+'.genbank')
        sid2 = sids[j]
        anim2, seq2 = read_genbank(sid2+'.genbank')
        x,y = match(seq1,seq2,w)
        plot(x,y,anim1,anim2,w)
        #for autochecker
        print(anim1+' and '+anim2+':')
        print(len(x),'dots;', 'sorted(zip(y,x)[8]:',sorted(zip(x,y))[4])
        tot_dots += len(x)
        
print('total number of dots:',tot_dots)
plt.show()     