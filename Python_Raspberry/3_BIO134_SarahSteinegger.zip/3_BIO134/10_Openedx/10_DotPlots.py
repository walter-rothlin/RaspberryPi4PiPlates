# -*- coding: utf-8 -*-
"""
Created on Sat Jul 27 13:52:39 2019

@author: sara
"""

# Sara Steinegger
# 27.07.2019

# Dot plots

line1 = "My care is loss care, by old care done"
line2 = "Your care is gain of care, by new care won"
W = 5

