# -*- coding: utf-8 -*-
"""
Created on Sat Jul 27 11:59:58 2019

@author: sara
"""

# Sara Steinegger
# 27.07.2019

# Exercise: testing performance of dictionaries

import numpy.random as rd
import time

def random_list(length):
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    l = []
    for i in range(length):
        s = ''
        for j in range(5):
            s += alphabet[rd.randint(0,24)]
        l.append(s)
    return l

rd.seed(0)
l1 = random_list(10000)
l2 = random_list(10000)

time1 = time.time()
common = []
for element in l1:
    if element in l2:
        if element not in common:
            common.append(element)
time2 = time.time()

print(common)
print("Time:", time2-time1)

# Creating dictionaries
def lyst_to_dictionary(l):
    d={}
    for i,element in enumerate(l):
        if element not in d:
            d[element]=[]
        d[element].append(i)
    return d
d1 = lyst_to_dictionary(l1)
d2 = lyst_to_dictionary(l2)

time3 = time.time()
common = []
for element in l1:
    if element in l2:
        if element not in common:
            common.append(element)
time4 = time.time()

print(d1["oodms"])

print(common)
print("Time:", time4-time3)


       