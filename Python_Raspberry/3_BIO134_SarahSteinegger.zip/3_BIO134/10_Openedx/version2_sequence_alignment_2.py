import genbank_module as genmod
import dotplot_module as dotplot

#------------------------------------------------------------------------------
# create files
filenames=['P00846','Q95A26','Q9T9W0','Q2I3G9','Q9TA24']
for file in filenames:
    genmod.fetch_genbank(file)
#-----------------------------------------------------------------------------
# read files
organism=[]
seq=[]
for file in filenames:
    [org,s]=genmod.read_genbank('./genbank/'+file+'.genbank')
    organism.append(org)
    seq.append(s)
#------------------------------------------------------------------------------
# compute the alignment
width=10

l=len(filenames)

mat_list=l*[[]]
dots = 0
for i in range(l):
    mat_list[i]=[0]    
    for j in range(0,i):
        [r1,r2]=dotplot.match(seq[i],seq[j],width)
        l1=len(r1)            
        mat_list[i].append(l1) 
        dots += l1
        dotplot.dotplot_function(r1,r2,organism[i],organism[j],width)

print('Pairwise comparison:')
dotplot.print_list(mat_list,filenames)
print()
for i in range(len(filenames)):
    print(filenames[i],organism[i])
print()
print('total dots:',dots)


