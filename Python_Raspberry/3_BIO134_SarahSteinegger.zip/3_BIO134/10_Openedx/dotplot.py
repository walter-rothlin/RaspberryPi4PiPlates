# -*- coding: utf-8 -*-
"""
Created on Sat Jul 27 14:09:05 2019

@author: sara
"""

# Sara Steinegger
# 27.07.2019

# dotplot.py

line_1 = "My care is loss care, by old care done"
line_2 = "Your care is gain of care, by new care won"
W = 5


# Function 1
# Function should return a dictionary
# The keys of the dictionary are strings (of "width" characters)
# the values are lists with the positions of these srings in "line".
def slyce(line,width):
    d = {}
    s = ""
    for i in range(0, (len(line)-4)):
        s = line[i:(i+width)]
        if s not in d:
            d[s] = []
        d[s].append(i)
    return d
d1 = slyce(line_1, W)
d2 = slyce(line_2, W)   
  

  
# Function 2
# Function should return a tuple with two lists.
# The lists contains x- and y- values respectively
def match(line1, line2, width):
    dic1 = slyce(line1, width)
    dic2 = slyce(line2, width)
    slyces = []
    l1 = []
    l2 = []
    for i,el in enumerate(dic1):
        if el in dic2:
            slyces.append(el)
            for j in range(len(dic1[el])):
                l1.append(dic1[el][j])
                l2.append(dic2[el][j])
    return(l1,l2)
t = match(line_1, line_2, W)
print(t)
            
# dot plot: warmup 1
l1 = [7, 2, 1, 4, 8, 9]
l2 = [4, 3, 9, 8, 1, 2]
l1_new = []
l2_new = []

for i in range(len(l1)):
    for j in range(len(l2)):
        l1_new.append(l1[i])
        l2_new.append(l2[j])
print(sum(l1_new))
print(sum(l2_new))
  
# dor plot: warmup2
l1 = [[2, 4, 1], [6, 2]]
l2 = [[7, 5], [2, 1, 3, 8]]

                
        





 
# Function 3
#def plot(x, y, labelx, labely):
