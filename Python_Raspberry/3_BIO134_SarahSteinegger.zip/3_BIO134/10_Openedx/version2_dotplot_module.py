import matplotlib.pyplot as pl

#------------------------------------------------------------------------------
def slyce(s,w):
    n=len(s)-w+1;
    
    dictio={}    
    for i in range(n):
        key=s[i:i+w]        
        if not(key in dictio):
            dictio[key] = []
        dictio[key].append(i)  
    
    return dictio  

def print_list(l,f):
    print('       '+' '.join(f))
    for i in range(1,len(f)):
        print(f[i],end=' ')
        for j in range(1,len(l[i])):
            print('%6i ' % l[i][j],end='')
        print()

def match(s1,s2,w):
    
    dictio1=slyce(s1,w)
    dictio2=slyce(s2,w)

    com_keys=[]
    for key in dictio1.keys():
        if key in dictio2.keys():
            if key not in com_keys:
                com_keys.append(key)
                

    res_1=[]
    res_2=[]
    for key in com_keys:
        r1=dictio1[key]
        r2=dictio2[key]
        for i in range(len(r1)):
            for j in range(len(r2)):
                res_1.append(r1[i])
                res_2.append(r2[j])
                
    return res_1,res_2  
#------------------------------------------------------------------------------ 
def dotplot_function(s1,s2,lab1,lab2,w):
    
    pl.figure()
    pl.plot(s1,s2,'o',color='blue',markeredgecolor='blue')

    pl.xlabel(lab1)
    pl.ylabel(lab2)
    
    ax = pl.gca()
    ax.set_aspect('equal')

    pl.show()  
#------------------------------------------------------------------------------
