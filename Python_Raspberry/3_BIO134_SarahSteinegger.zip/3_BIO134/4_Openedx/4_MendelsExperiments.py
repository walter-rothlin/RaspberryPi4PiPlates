# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 09:04:43 2019

@author: sara
"""

# Sara Steinegger
# 12.07.2019

# Mendel's experiments
# Simulating a cross
#Example 1
allel_parent1 = np.random.randint(0,2)
if allel_parent1==0:
    allel1 = "d"
else:
    allel1 = "r"

allel_parent2 = np.random.randint(0,2)
if allel_parent2==0:
    allel2 = "d"
else:
    allel2 = "r"

if allel_parent1=="d" or allel_parent2=="d":
    dominant += 1

# Example 2
a = np.random.randint(1, 5)
if a!=1:
    dominant += 1

# Example 3
a = np.random.randint(1, 5)
if a<4:
    dominant += 1

# Example 4
a = np.random.uniform(0, 1)
if a<0.75:
    dominant += 1

# Example 5
a = np.random.uniform(0, 1)
if a>=0.75:
    dominant += 1



# Comparison with expected outcome
# men_rec = number of recessives found by Mendel
# men_dom = number of dominants found by Mendel
# sim_rec = number of recessives found by simulation
# sim_dom = number of dominants found by simulation
plantnumber=men_rec+men_dom
expected_dom=plantnumber*3.0/4.0
mendel_closer=0
if abs(sim_dom-expected_dom)>abs(men_dom-expected_dom):
     mendel_closer = 1


    