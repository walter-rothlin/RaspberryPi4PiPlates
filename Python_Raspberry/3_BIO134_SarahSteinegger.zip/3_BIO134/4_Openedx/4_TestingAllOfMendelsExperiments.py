# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 12:26:53 2019

@author: sara
"""

# Sara Steinegger
# 12.07.2019

# Testing all of Mendel's experiment
import numpy.random as np

mendel_dominant = [5474, 6022, 705, 882, 428, 651, 787, 372, 353,
                   64, 71, 60, 67, 72, 65]
mendel_recessive = [1850, 2001, 224, 299, 152, 207, 277, 193, 166,
                    36, 29, 40, 33, 28, 35]
mendel_closer = 15*[0]
simulation_closer = 15*[0]

for k in range(15):
    if k<=7:
        men_dom = mendel_dominant[k]
        men_rec = mendel_recessive[k]
        plantnumber = men_dom + men_rec
        exp_dom = plantnumber*3.0/4.0
        men_closer = 0
        sim_closer = 0
        equal_close = 0 
        
        for j in range(1000):
            sim_dom = 0
            for i in range(plantnumber):
                a = np.randint(1, 5)
                if a!=4:
                    sim_dom += 1
            if abs(men_dom-exp_dom)<abs(sim_dom-exp_dom):
                men_closer += 1
            if abs(men_dom-exp_dom)>abs(sim_dom-exp_dom):
                sim_closer += 1
        mendel_closer[k] = men_closer
        simulation_closer[k] = sim_closer
    if k>7:
        men_dom = mendel_dominant[k]
        men_rec = mendel_recessive[k]
        plantnumber = men_dom + men_rec
        exp_dom = plantnumber*2.0/3.0
        men_closer = 0
        sim_closer = 0
        equal_close = 0 
        
        for j in range(1000):
            sim_dom = 0
            for i in range(plantnumber):
                a = np.randint(1, 5)
                if a!=4:
                    sim_dom += 1
            if abs(men_dom-exp_dom)<abs(sim_dom-exp_dom):
                men_closer += 1
            if abs(men_dom-exp_dom)>abs(sim_dom-exp_dom):
                sim_closer += 1
        mendel_closer[k] = men_closer
        simulation_closer[k] = sim_closer

print("Mendel closer:", mendel_closer)
print("Simulation closer:", simulation_closer)
        


# Warm-up
lys1 = [4, 3, 91, 5, 67, 53, 2]
lys2 = [46, 68, 30, 29, 100, 7, 4]
lys3 = 7*[0]

for i in range(7):
    if i<=2:
        lys3[i] = lys1[i]*lys2[i]
    else:
        lys3[i] = lys1[i]+lys2[i]
print(lys3)
print(sum(lys3))




