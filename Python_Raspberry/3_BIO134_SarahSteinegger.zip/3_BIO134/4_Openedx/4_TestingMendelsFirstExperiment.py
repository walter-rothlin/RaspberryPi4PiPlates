# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 12:05:27 2019

@author: sara
"""

# Sara Steinegger
# 12.04.2019

#  Testing Mendel's first experiment
import numpy.random as np

men_dom = 5474
men_rec = 1850
plantnumber = men_dom + men_rec

exp_dom = plantnumber*3.0/4.0

men_closer = 0
sim_closer = 0
equal_close = 0 

for j in range(10000):
    sim_dom = 0
    for i in range(plantnumber):
        a = np.randint(1, 5)
        if a!=4:
            sim_dom += 1
    if abs(men_dom-exp_dom)<abs(sim_dom-exp_dom):
        men_closer += 1
    if abs(men_dom-exp_dom)>abs(sim_dom-exp_dom):
        sim_closer += 1
    if abs(men_dom-exp_dom)==abs(sim_dom-exp_dom):
        equal_close += 1
print("Mendel closer to the expected outcome:", men_closer)
print("Simulation closer to the expected outcome:", sim_closer)
print("Mendel and simulation equally close to the expected outcome:", equal_close)   
