# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 08:45:51 2019

@author: sara
"""

# Sara Steinegger
# 12.07.2019

# Calculation with a list
# Exercise: Reviewing list 1
l = [3, 2, 4]
l_n = 3*[0]

for i in range(3):
    l_n[i] = l[i]**3
print(l_n)

# Exercise: Reviewing list 2
l = [38, 38, 46, 46, 13, 24, 3, 54, 18, 47, 4, 42,
     8, 66, 50, 46, 62, 36, 19, 19, 77, 17, 7, 63,
     28, 47, 46, 65, 63, 12, 16, 24, 14, 51, 34, 56,
     29, 59, 92, 79]
l_n = 40*[0]

for i in range(40):
    l_n[i] = l[i]**3
print(l_n)