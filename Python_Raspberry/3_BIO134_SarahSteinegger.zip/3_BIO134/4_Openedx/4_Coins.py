# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 08:52:35 2019

@author: sara
"""

# Sara Steinegger
# 12.07.2019

# Coins
from numpy.random import randint, seed
seed(0)
count = 0
longest = 0
ones = 0
twos = 0

while longest<8:
    r = randint(1,3)
    count+=1
    if r==1:
        ones+=1
        twos=0
    else:
        ones=0
        twos+=1
    if ones>longest:
        longest=ones
    if twos>longest:
        longest=twos
print("tosses needed:", count)       

