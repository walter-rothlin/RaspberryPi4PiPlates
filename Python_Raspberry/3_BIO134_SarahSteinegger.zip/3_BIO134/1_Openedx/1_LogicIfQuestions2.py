# -*- coding: utf-8 -*-
"""
Created on Sat Aug  3 21:16:52 2019

@author: sara
"""

# Sara Steinegger
# 03.08.2019

# Logic: If Questions 2

# Exercise 1
# When thinking about what "not" does, it may be usefule to keeping in mind
# that not changes False into True and the other way around!
# For each of the following questions assume that i=5 and j=4.

# Do the following conditions yield "True" or "False"?
# i>=5 and j<4: False
# i>=5 or j<=4: True
# not(i==5 and j==4): False
# not(i<=5 or j==4): False
# not(i<=5) or j==4: True
# not(i!=5) or j<4: True
# not(i==5) or j!=4: False
# i==5 and (not(i>j) or not(j<=4)): False
