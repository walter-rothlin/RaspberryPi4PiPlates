# -*- coding: utf-8 -*-
"""
Created on Sat Aug  3 20:31:33 2019

@author: sara
"""

# Sara Steinegger
# 03.08.2019

# First steps in Python

# Exercise 1
x = 8
y = 11
x = x + y
y = x - y
x = x - y
print (x, y)



# Exercise 2
print(4*"hi" + 3*"hello")



# Exercise 3
import random
secret = random.randint(1, 99)  # Picks secret number
guess = 0
tries = 0
print ("AHOY! I'm the Dread Pirate Roberts, and I have a secret!")
print ("It is a number from 1 to 99. I'll give you 6 tries.")

# Allows up to 6 guesses
while guess!=secret and tries<6:
    guess = int(input("What's yer guess? "))  # Gets player’s guess
    if guess<secret:
        print ("Too low, ye scurvy dog!")
    elif guess>secret:
        print ("Too high, landlubber!")
    tries = tries+1                          # Uses up one try

# Prints a message at the end of the game
if guess == secret:
    print ("Avast! Ye got it! Found my secret, ye did!")
else:
    print ("No more guesses! Better luck next time, matey!")
    print ("The secret number was", secret)