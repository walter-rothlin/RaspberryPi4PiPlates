# -*- coding: utf-8 -*-
"""
Created on Sat Aug  3 20:43:51 2019

@author: sara
"""

# Sara Steinegger
# 03.08.2019

# Logic: While Questions

# Example
i=0
while i<2:
    i = i+1
print(i)

# Exercise 1
i=0
while i<5:
    i=i+1
print(i)

# Exercise 2
i=0
while i<5:
    i=i+1
    print(i) # The first number printed is 1 
# Note: The print-statement is part of the while loop
    
# Exercise 3
i=0
while i<5:
    print(i) # The first number printed is 0
    i=i+1
# Note: The print-statement is part of the while loop

# Exercise 4
i=0
j=0
while i<3 or j>5:
    i=i+1
    j=j+1
print(i)
# Note: The print-statement is no longer part of the while loop

# Exercise 5
i=0
j=0
while i<3 or not(j>5):
    i=i+1
    j=j+1
print(i)

# Exercise 6
i=0
j=0
while not(i<3 or j==5):
    i=i+1
    j=j+1
print(i)