# -*- coding: utf-8 -*-
"""
Created on Sat Aug  3 21:20:16 2019

@author: sara
"""

# Sara Steinegger
# 03.08.2019

# Data Types

# a="5": string
# a=5.: float
# x=2>3: False (boolean)
