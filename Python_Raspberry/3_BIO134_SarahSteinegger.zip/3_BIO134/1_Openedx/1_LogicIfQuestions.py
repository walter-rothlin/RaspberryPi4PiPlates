# -*- coding: utf-8 -*-
"""
Created on Sat Aug  3 20:39:59 2019

@author: sara
"""

# Sara Steinegger
# 03.08.2019

# Logic: If Questions

# Exercise 1
i=5
if i>5:
    print("Yes")
else:
    print("No")

# Exercise 2
i=5
if i<=5:
    print("Yes")
else:
    print("No")

# Exercise 3
i=5
if i!=5:
    print("Yes")
else:
    print("No")

# Exercise 4
i=5
if not (i==4):
    print("Yes")
else:
    print("No")

# Exercise 5
i=5
j=4
if i==5 and j==5:
    print("Yes")
else:
    print("No")

# Exercise 6
i=5
j=4
if i==5 or j==5:
    print("Yes")
else:
    print("No")

# Exercise 7
i=5
j=4
if i==5 or j==4:
    print("Yes")
else:
    print("No")