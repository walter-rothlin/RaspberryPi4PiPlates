# -*- coding: utf-8 -*-
"""
Created on Sat Aug  3 21:00:03 2019

@author: sara
"""

# Sara Steinegger
# 03.08.2019

# Logic: While loops and if Questions

# Exercise 1
i=0
j=0
while j<6:
    j=j+1
    if j>4:
        i=i+1
print(i)

# Exercise 2
i=0
j=0
k=0
while j<6:
    j=j+1
    if j>4:
        i=i+1
        k=k+1
print(i)
print(k)

# Exercise 3
i=0
j=0
k=0
while j<6:
    j=j+1
    if j>4:
        i=i+1
    k=k+1
print(i)
print(k)

# Exercise 4
i=0
j=0
while j<6:
    if j>4:
        i=i+1
    j=j+1
print(i)

# Exercise 5
i=0
j=0
while j<6:
    i=i+1
    if i>4:
        j=j+2
print(i)

# Exercise 6
i=0
j=0
while j>6:
    if i>4:
        j=j+2
    i=i+1
print(i)