# -*- coding: utf-8 -*-
"""
Created on Sat Aug  3 21:10:04 2019

@author: sara
"""

# Sara Steinegger
# 03.08.2019

# Arithmetic

# Exercise: Quotient and remainer
print(3987//8)
print(3987%8)

# Exercise: Limitations floor division
# Only use floor division (//) in python 3 for integers (when using floor 
# division for numbers with decimal spaces the error can become large)
print(2//0.1) # ideal for getting errors that are not discovered
print(int(2/0.1)) # correct alternative!

# Exercise: e-notation
print(3.56*((10**(-6))))

# Exercise: Square root
print(4489**0.5)