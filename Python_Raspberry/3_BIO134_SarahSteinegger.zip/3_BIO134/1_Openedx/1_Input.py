# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 10:38:47 2019

@author: sara
"""

# Sara Steinegger
# 03.08.2019

# Input

# Python 3 does not have raw_input() because input() anyway returns a string.
# In Python 3 we use urllib.request in place of urllib2 (Python 2) to read
# web pages directly.

# Example:
import urllib.request
seite = urllib.request.urlopen('http://helloworldbook2.com/data/message.txt')
message = seite.read()
message = str(message, encoding='utf-8') #optional
print(message)

# Exercise 1
n_1 = input("Hei you, Give me a float")



