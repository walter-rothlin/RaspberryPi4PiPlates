# -*- coding: utf-8 -*-
"""
Created on Sat Aug  3 21:23:14 2019

@author: sara
"""

# Sara Steinegger
# 03.08.2019

# Logic: True or False

# Exercise 1
i=5
i>6

# Exercise 2
i=5
if i==5:
    print("Yes")

# Exercise 3
if True:
    print("Yes")
else:
    print("No")

# Exercise 4
if False:
    print("Yes")
else:
    print("No")

# Exercise 5
if False and True:
    print("Yes")
else:
    print("No")

# Exercise 6
if not(False):
    print("Yes")
else:
    print("No")