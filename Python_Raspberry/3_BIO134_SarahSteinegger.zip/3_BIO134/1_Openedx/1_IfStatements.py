# -*- coding: utf-8 -*-
"""
Created on Sat Aug  3 21:03:22 2019

@author: sara
"""

# Sara Steinegger
# 03.08.2019

# If-Statements



# Note that the following code does not do what you may expect.
# This code prints "Yes"
a = 3
if a == 4 or 2:
    print("Yes")
# This tests whether a is equal to 4 or whether 2 is true (which is the case).
# The correct alternative would be:
a = 3
if a == 4 or a == 2:
    print("Yes")

# Exercise 1
a = 2
b = 3
if a == 1:
    a+= 1
b*=2
print(b)

# Exercise 2
a = 2
b = 3
if a == 2:
    a += 1
else:
    b *= 2
print(b)

# Exercise 3
a = 2
b = 3
if a == 3:
    a += 1
else:
    b*= 2
print(b)

# Exercise 4
a = 2
b = 3
if a == 2:
    a += 1
elif b == 3:
    b *= 2
print(b)

# Exercise 5
a = 2
b = 3
if a == 3:
    a += 1
elif b == 3:
    b *= 2
    if b == 6:
        b += 5
else:
    b -= 1
print(b)

# Exercise 6
a = 2
b = 3
if a == 3:
    a += 1
elif b == 3:
    b *= 2
    if b == 4:
        b += 5
    elif a == 3:
        b += 6
else:
    b -= 1
print(b)
