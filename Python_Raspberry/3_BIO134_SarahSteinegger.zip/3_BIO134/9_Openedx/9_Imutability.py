# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 08:13:26 2019

@author: sara
"""

# Sara Steinegger
# 25.07.2019

# (Im)mutability

# Which of the following pieces of code give an error?
t = (4, 5)
t[0] += 1
# This program yields an error!
# Tuples are immutable

l = [4, 5]
l[0] += 1
# This program works!
# Lists are mutable

d = {'a': 4, 'b': 5}
d['a'] += 1
# This program works!
# dictionaries are mutable

import numpy as np
a = np.array([4, 5])
a[0] += 1
# This program works!
# Arrays are mutable

s = 'ab'
s[0] = 'c'
# This program yields an error!
# Strings are immutable!