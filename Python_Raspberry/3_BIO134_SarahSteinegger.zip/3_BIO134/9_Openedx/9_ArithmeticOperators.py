# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 08:28:16 2019

@author: sara
"""

# Sara Steinegger
# 25.07.2019

# Arithmetic operators



# Question 1
l = [7, 4, 1]
print(2 * l)
# Prints: [7, 4, 1, 7, 4, 1]

# Question2
l = [7, 4, 1]
print(l + l)
# Prints: [7, 4, 1, 7, 4, 1]

# Question3
import numpy as np
a = np.array([7,4,1])
print(2*a)
# Prints: [14 8 2]

# Question 4
s = '741'
print(2 * s)
# Prints: "741741"

# Question 5
d = {'a': 7, 'b': 4, 'c': 1}
print(2 * d)
# This program gives an error!