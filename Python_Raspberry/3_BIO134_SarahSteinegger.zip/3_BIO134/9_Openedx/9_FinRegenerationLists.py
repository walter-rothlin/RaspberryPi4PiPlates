# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 08:47:20 2019

@author: sara
"""

# Sara Steinegger
# 25.07.2019

# Fin regeneration (list)

# Exercise 1: List
def textFile(text_file):
    text = open(text_file, "r")
    text_l = text.readlines()
    text.close()
    for i,el in enumerate(text_l):
       text_l[i] = el.split()
       for j in el:
           text_l[i][0] = int(text_l[i][0])
           text_l[i][2] = float(text_l[i][2])
    return text_l
l_before = textFile("bif_before.txt")
l_after = textFile("bif_after.txt")

# Exercise 2: List
def ratio_bifurcation_distance(a, b, c, d):
    n_before = 0
    n_after = 0
    for i,el in enumerate(a):
        for j,el2 in enumerate(el):
            if a[i][0]==c and a[i][1]==d:
                n_before += a[i][2]
    for i,el in enumerate(b):
        for j,el2 in enumerate(el):
            if b[i][0]==c and b[i][1]==d:
                n_after += b[i][2]
    ratio = n_after/n_before
    return ratio         
print(ratio_bifurcation_distance(l_before, l_after, 5, "V3"))
            


