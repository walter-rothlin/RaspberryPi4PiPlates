# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 08:22:47 2019

@author: sara
"""

# Sara Steinegger
# 25.07.2019

# Combining datatypes

# Accessing a specific element
v = {'a': {'b': 5, 'd': 8, 'e': 3}, 'f': {'g': 5, 'h': [3, 4, ['z', 2]], 'c': 3}}   
v["f"]["h"][2][1] = 5
print(v)