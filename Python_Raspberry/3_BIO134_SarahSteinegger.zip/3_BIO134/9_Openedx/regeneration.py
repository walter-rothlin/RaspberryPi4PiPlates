# -*- coding: utf-8 -*-

import numpy as np
np.set_printoptions(threshold=np.nan)
import matplotlib.pyplot as plt

##Defining functions to get the information into lists, dictionaries and arrays, respectively
def list_from_file(filename):
    l = []
    fyle = open(filename)
    text = fyle.readlines()
    fyle.close()
    for line in text:
        sublist = line.split()
        sublist[0] = int(sublist[0])
        sublist[2] = float(sublist[2])
        l.append(sublist)
    return l

#for coupling ray name to an index number (D1: 0, D2: 1... D9:8, V9: 9, V8: 10, V1: 17)
def ray_dictionary():
    rays = {}
    for i in range(9):
        s = 'D' + str(i+1)
        rays[s] = i
    for i in range(9):
        s = 'V' + str(9-i)
        rays[s] = i + 9
    return rays

def list_to_array(lyst, number_of_fish, rays):
    a = np.zeros(shape = [len(rays), number_of_fish]) + np.NaN
    for sublist in lyst:
        fish = sublist[0]
        ray = sublist[1]
        bif = sublist[2]
        a[rays[ray], fish-1] = bif
    return a

##Defining functions for plotting

#for getting a list with ray names
def names_of_rays(rays):
    ray_names = 18*['']
    for ray in rays:
        ray_names[rays[ray]] = ray
    return ray_names

#for generating plot
def plotting(ratios, mean_ratios, ray_names):
    fig = plt.figure()
    ax = fig.add_subplot(111)
    for i in range(ratios.shape[1]):
        ax.plot(ratios[:, i],'.')
    ax.plot(mean_ratios,'k')
    plt.ylim([0, 1.6])
    plt.legend(['fish 1', 'fish 2', 'fish 3', 'fish 4', 'fish 5', 'fish 6', 'fish 7', 'mean'])
    plt.title('Change in bifurcation distances upon fin regeneration.')
    plt.xlabel('Ray')
    plt.ylabel('Relative change in bifurcation distance')
    ax.set_xticks(range(len(ray_names)))
    ax.set_xticklabels(ray_names)
    

##Calling functions  to generate arrays with data
l_before = list_from_file('bif_before.txt')
l_after = list_from_file('bif_after.txt')

rays = ray_dictionary()
number_of_fish = 7
a_before = list_to_array(l_before, number_of_fish, rays)
a_after = list_to_array(l_after, number_of_fish, rays)


##calculaing ratios and mean ratios using arrays
ratios = a_after / a_before
print('bifurcation distance ratios in fish 5:',ratios[:,5-1])
mean_ratios = np.nanmean(ratios, axis=1)
print('mean ratios:', mean_ratios)

##Calling functions to generate plot
ray_names = names_of_rays(rays)
plotting(ratios, mean_ratios, ray_names)



             

