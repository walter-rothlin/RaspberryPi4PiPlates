# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 08:03:40 2019

@author: sara
"""

# Sara Steinegger
# 25.07.2019

# Slicing

# Question 1
import numpy as np
a = np.array([[0, 1, 0, 0], [5, 0, 0, 0], [0, 0, 3, 0]])
print(a[:,1])
# Prints: [1 0 0]



# Question 2
import numpy as np
a = np.array([[0, 1, 0, 0], [5, 0, 0, 0], [0, 0, 3, 0]])
print(a[:][1]])
# This program yields an error



# Question 3
import numpy as np
a = np.array([[0, 1, 0, 0], [5, 0, 0, 0], [0, 0, 3, 0]])
print(a[:][1])
# Prints: [5 0 0 0]



# Question 4
l = [[0, 1, 0, 0], [5, 0, 0, 0], [0, 0, 3, 0]]
print(l[:][1])
# Prints: [5, 0, 0, 0]



# Question 5
l = [[0, 1, 0, 0], [5, 0, 0, 0], [0, 0, 3, 0]]
print(l[:,1])
# This program yoiels an error!