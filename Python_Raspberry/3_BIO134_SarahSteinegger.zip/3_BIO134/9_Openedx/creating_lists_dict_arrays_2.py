# -*- coding: utf-8 -*-

import numpy as np
np.set_printoptions(threshold=np.nan)

##Defining functions to get the information into lists, dictionaries and arrays, respectively
def list_from_file(filename):
    l = []
    fyle = open(filename)
    text = fyle.readlines()
    fyle.close()
    for i, line in enumerate(text):
        l.append([])
        sublist = line.split()
        l[i].append(int(sublist[0]))
        l[i].append(sublist[1])
        l[i].append(float(sublist[2]))
    return l

def list_to_dict(lyst):
    d = {}
    for i in range(len(lyst)):
        ray = lyst[i][1]
        d[ray] = {}
    for i in range(len(lyst)):
        fish = lyst[i][0]
        ray = lyst[i][1]
        bif = lyst[i][2]
        d[ray][fish] = bif
    return d

#for coupling ray name to an index number (D1: 0, D2: 1... D9:8, V9: 9, V8: 10, V1: 17)
def ray_dictionary():
    rays = {}
    for i in range(9):
        s = 'D' + str(i+1)
        rays[s] = i
    for i in range(9):
        s = 'V' + str(9-i)
        rays[s] = i + 9
    return rays

def list_to_array(lyst, number_of_fish, rays):
    a = np.zeros(shape = [len(rays), number_of_fish]) + np.NaN
    for i in range(len(lyst)):
        fish = lyst[i][0]
        row = rays[lyst[i][1]]
        bif = lyst[i][2]
        a[row, fish-1] = bif
    return a

##Calling functions and checking single elements 
l_before = list_from_file('bif_before.txt')
l_after = list_from_file('bif_after.txt')
print('l_after[36]:',l_after[36])

d_before = list_to_dict(l_before)
d_after = list_to_dict(l_after)
print("d_before['V9']:", d_before['V9'])

rays = ray_dictionary()
number_of_fish = 7
a_before = list_to_array(l_before, number_of_fish, rays)
a_after = list_to_array(l_after, number_of_fish, rays)
print('a_before[4,:]',a_before[4,:])
print('a_before[:,4]',a_before[:,4])
 

##calculaing ratio for V3 of fish 5

#using lists
def get_bif_distance(lyst, ray, fish):
    for i in range(len(lyst)):
        if lyst[i][0] == fish and lyst[i][1] == ray:
            bifurcation_distance = lyst[i][2]
    return bifurcation_distance
ratio = get_bif_distance(l_after, 'V3', 5) / get_bif_distance(l_before, 'V3', 5)
print('ratio V3, fish5, calculated with lists:', ratio)

#using dictionaries
ratio = d_after['V3'][5] / d_before['V3'][5]
print ('ratio V3, fish5, calculated with dictionaries:', ratio)

#using arrays
ratio = a_after[rays['V3'], 5-1] / a_before[rays['V3'], 5-1]
print ('ratio V3, fish5, calculated with arrays:', ratio)


             

