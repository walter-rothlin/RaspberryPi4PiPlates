# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 11:26:00 2019

@author: sara
"""

# Sara Steinegger
# 25.07.2019

# Fin Regeneration (dictionaries)
def textFile(text_file):
    text = open(text_file, "r")
    text_l = text.readlines()
    text.close()
    for i,el in enumerate(text_l):
       text_l[i] = el.split()
       for j in el:
           text_l[i][0] = int(text_l[i][0])
           text_l[i][2] = float(text_l[i][2])
    return text_l
l_before = textFile("bif_before.txt")
l_after = textFile("bif_after.txt")

print(l_after)

def list_into_dictionary(l):
    d = {}
    for i,el in enumerate(l):
        if l[i][1] not in d.keys():
            d[l[i][1]] = {l[i][0]:l[i][2]}
        else:
            d[l[i][1]].update({l[i][0]:l[i][2]})
    return d
dic_before = list_into_dictionary(l_before)
dic_after = list_into_dictionary(l_after)

print(dic_before["V9"])

def list_into_dictionary(l):
    d = {}
    for i,el in enumerate(l):
        if l[i][1] not in d.keys():
            d[l[i][1]] = {}
        d[l[i][1]][l[i][0]] = l[i][2]
    return d
dic_before = list_into_dictionary(l_before)
dic_after = list_into_dictionary(l_after)

print(dic_before["V9"])

# Calculation of the bifurcation ratio
ratio = dic_after["V3"][5]/dic_before["V3"][5]
print(ratio)


