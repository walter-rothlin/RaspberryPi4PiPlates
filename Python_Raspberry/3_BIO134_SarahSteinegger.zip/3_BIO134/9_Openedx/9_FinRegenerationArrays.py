# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 15:35:50 2019

@author: sara
"""

# Sara Steinegger
# 25.07.2019

# Fin Regeneration (arrays)

# Creating lists out of the data
import numpy as np
np.set_printoptions(threshold=np.nan)

def textFile(text_file):
    text = open(text_file, "r")
    text_l = text.readlines()
    text.close()
    for i,el in enumerate(text_l):
       text_l[i] = el.split()
       for j in el:
           text_l[i][0] = int(text_l[i][0])
           text_l[i][2] = float(text_l[i][2])
    return text_l
l_before = textFile("bif_before.txt")
l_after = textFile("bif_after.txt")

#for coupling ray name to an index number (D1: 0, D2: 1... D9:8, V9: 9, V8: 10, V1: 17)
def ray_dictionary(b):
   rays = {}
   for i in range(9): 
      s = 'D' + str(i+1)
      rays[s] = i 
   for i in range(9):
      s = 'V' + str(9-i)
      rays[s] = i + 9 
   return rays
   
#rays = ray_dictionary()
def list_into_array(l):
    a = np.zeros(shape=(18,7), dtype=float) + np.nan
    rac = ray_dictionary(l)
    for i in range(1,8):
        for j,el in enumerate(l):
            if l[j][0]==i:
                a[rac[l[j][1]],i-1] = l[j][2]
    return a
a_before = list_into_array(l_before)
a_after = list_into_array(l_after)

# Solution
#def list_to_array(lyst, number_of_fish, rays):
    #a = np.zeros(shape = [len(rays), number_of_fish]) + np.NaN
    #for sublist in lyst:
        #fish = sublist[0]
        #ray = sublist[1]
        #bif = sublist[2]
        #a[rays[ray], fish-1] = bif
    #return a

ratios = a_after/a_before
print("the bifurcation ratios (D1 - V1) for fish 5 are:", ratios[:,4])



