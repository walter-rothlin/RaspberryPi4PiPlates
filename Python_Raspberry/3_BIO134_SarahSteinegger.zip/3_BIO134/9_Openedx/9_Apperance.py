# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 11:44:52 2019

@author: sara
"""

# Sara Steinegger
# 23.07.2019

# Appearance

# Variable appearance 1
import numpy as np
a = np.array([[ 4.9734,5.8071],[ 1.9184,5.1771],[ 3.4267,3.8873]])
print(a)
# array



# Variable appearance 2
b = (8, 9, 22)
print(b)
# Tuple



# Variable appearance 3
c = [[4.9734, 5.8071], [1.9184, 5.1771], [3.4267, 3.8873]]
print(c)
# List



# Variable appearance 4
d = {'Lara': 20, 'Lionel': 21, 'Lars': 19}
print(d)
# dictionary
