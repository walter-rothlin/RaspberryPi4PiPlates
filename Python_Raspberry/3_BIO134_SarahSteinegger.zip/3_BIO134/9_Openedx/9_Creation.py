# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 11:55:32 2019

@author: sara
"""

# Sara Steinegger
# 23.07.2019

# Creation



# Creating lists
s = "abcdefghijk"
snew =[]

for i in range(0,len(s),4):
    snew.append(s[i]+s[i+1])
print(snew)

# Complete the code
s = 'abcdefghijk'
lnew =  []
for i in range(0, len(s), 4):
    lnew.append(s[i:i+2])
print(lnew)



# Creating strings
s = 'abcdefghijk'
snew = ""

for i in range(0,len(s),4):
    snew += s[i:i+2]
print(snew)

# Complete the code
s = 'abcdefghijk'
snew = ""
for i in range(0, len(s), 4):
    snew += s[i:i+2]
print(snew)



# Creating dictionaries
s = 'abcdefghijk'
dnew = {}

for i in range(0, len(s), 4):
    dnew[s[i:i+2]] = s[i+2:i+4]
print(dnew)

# Complete this code
s = 'abcdefghijk'
dnew = {}
for i in range(0, len(s), 4):
    dnew[s[i:i+2]] = s[i+2:i+4]
print(dnew)



# Create the following array
#[[ 0.  1.  0.  0.]
# [ 0.  0.  2.  0.]
# [ 0.  0.  0.  3.]]

import numpy as np
a = np.array([[0., 1., 0., 0.,], [0., 0., 2., 0.], [0., 0., 0., 3.]])
print(a)

# Complete the code
import numpy as np
anew = np.zeros(shape=(3,4), dtype=float)
for i in range(len(anew)):
    anew[i,i+1] = i + 1
print(anew)



