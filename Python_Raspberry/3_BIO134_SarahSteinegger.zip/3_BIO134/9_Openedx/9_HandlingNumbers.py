# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 08:35:16 2019

@author: sara
"""

# Sara Steinegger
# 25.07.2019

# Handling numbers

# Code with list
l = [4, 5, 3]
l[0] += 0.2
l[1] *= 1.5
l[2] /= 2
print(l)

# Code with dictionaries
d = {'a': 4, 'b': 5, 'c': 3}
d['a'] += 0.2
d['b'] *= 1.5
d['c'] /= 2
print(d)

# Code with arrays
import numpy as np
a = np.array([4, 5, 3])
a[0] += 0.2
a[1] *= 1.5
a[2] /= 2
print(a)



# Integer and floats in an array
import numpy as np
a = np.array([3, 6, 0])
a[0] = a[0] + 0.6
a = a / 3
a[2] += 2.2
a = a / 2
print(a)
# The new array contains floats!
# array_new = array_of_integers + float -> array_new contains floats
# array_new = array_of_integers * integer -> array_new contains integers
# array_new = array_of_integers * float -> array_new contains floats
# array_new = array_of_integers /integer -> array_new contains floats



# Dividing by zero:
# Lists yields an error
# Dictionaries yields an error
# Arrays retuns inf