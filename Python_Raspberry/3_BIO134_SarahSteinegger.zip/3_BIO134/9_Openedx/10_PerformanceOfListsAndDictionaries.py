# -*- coding: utf-8 -*-
"""
Created on Sat Jul 27 11:37:43 2019

@author: sara
"""

# Sara Steinegger
# 27.07.2019

# Performance of lists and dictionaries


# Code for short lists and dictionaries
#using lists
l1 = ['pear', 'apple', 'strawberry', 'apple']
l2 = ['grape', 'apple', 'melon', 'strawberry', 'orange']

common = []
for fruit in l1:
    if fruit in l2:
        if fruit not in common:
            common.append(fruit)

#using dictionaries
d1 = {'pear': [0], 'apple': [1, 3], 'strawberry': [2]}
d2 = {'grape': [0], 'apple': [1], 'melon': [2], 'strawberry': [3], 'orange': [4]}

common = []
for fruit in d1:
    if fruit in d2:
        if fruit not in common:
            common.append(fruit)
print(common)



# Code for long lists and dictionaries
# Creating long lists and dictionaries
import numpy.random as rd
import time

def random_list(length):
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    l = []
    for i in range(length):
        s = ''
        for j in range(5):
            s += alphabet[rd.randint(0,24)]
        l.append(s)
    return l

rd.seed(0)
l1 = random_list(10000)
l2 = random_list(10000)

time1 = time.time()
common = []
for element in l1:
    if element in l2:
        if element not in common:
            common.append(element)
time2 = time.time()

print(common)
print("Time:", time2-time1)
