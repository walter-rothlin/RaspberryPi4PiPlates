# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 20:39:09 2019

@author: sara
"""

# Sara Steinegger
# 11.07.2019

# Dice

# Random numbers and seeds
# This code simulates the rolling of a dice 30 times.
import numpy.random as rd
rd.seed(141)
for n in range(30):
    r = rd.randint(1,7)
    print(r)

# Extend the program to print the number of times a 6 was obtained
# The new code shows how many times the dice has been rolling!
import numpy.random as rd
rd.seed(141)
count = 0

for n in range(1, 31):
    r = rd.randint(1,7)
    if r==6:
        count +=1
    print(n, r)
print(count)

# Rolling dice repeated 1
# Simulate the game 10 times. The program should now print 10 numbers:
# the number of sixes each of the simulated games.
import numpy.random as rd
rd.seed(141)
count = 0

for g in range(1, 11):
    for n in range(30):
        r = rd.randint(1,7)
        if r==6:
            count +=1
    print("Simulated game:", g, ", number of sixes in this simulated game:", count)
    count = 0

# Rolling dice repeated 2
# Simulate the game 1000 times.
import numpy.random as rd
rd.seed(141)
count_1 = 0
count_2 = 0

for g in range(1000):
    for n in range(30):
        r = rd.randint(1,7)
        if r==6:
            count_1 += 1
    if count_1>=10:
        count_2 +=1
    count_1 = 0
print(count_2)
    





