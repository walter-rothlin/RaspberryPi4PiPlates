# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 21:07:11 2019

@author: sara
"""

# Sara Steinegger
# 11.07.2019

# Heads and Tails

# Consider the following program
# This simulates the tossing of a coin 1000 times.
import numpy.random as rd
rd.seed(0)
number_1 = 0
number_2 = 0
max_1 = 0
max_2 = 0

for n in range(1000):
    r = rd.randint(1,3)
    if r==1:
        if number_2 > max_2:
            max_2 = number_2
        number_2 = 0
        number_1 += 1
    else:
        if number_1 > max_1:
            max_1 = number_1
        number_1 = 0
        number_2 += 1
if max_1 > max_2:
    print(max_1)
else:
    print(max_2)

# Solution
from numpy.random import randint, seed
seed(0)
longest = 0
ones = 0
twos = 0

for n in range(1000):
    r = randint(1, 3)
    if r==1:
        ones+=1
        twos=0
    else:
        ones=0
        twos+=1
    if ones>longest:
        longest= ones
    if twos>longest:
        longest=twos
    print(r)
print("longest:", longest)

# Warm-up: Consecutive sequence
import numpy.random as rd
rd.seed(5)
number_1 = 0
sum_1 = 0

for n in range(500):
    r = rd.randint(1,3)
    if r==1:
        number_1 += 1
    else:
        number_1 = 0
    sum_1 += number_1
print(sum_1)


# Warm-up: Maximum
import numpy.random as rd
rd.seed(5)
max_1 = 0

for n in range(500):
    r = rd.randint(1,5000)
    if r > max_1:
        max_1 = r
    print(r)
print("The maximum is", max_1)







