# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 11:38:53 2019

@author: sara
"""

# Sara Steinegger
# 11.07.2019

# Nested loops
# Question 1
for i in range(3):
    for j in range(2):
        print(i, j)
print()

# Question 2
for i in range(6):
    print("hello")
    for i in range(3):
        print("hi")
    print("bye")
print()

# Question 3
for i in range(6):
    print("hello")
    if i <= 3:
        continue
    for j in range(3):
        print("hi")
    print("bye")
print()

# Question 4
for i in range(6):
    print("hello")
    if i <= 3:
        for j in range(3):
            print("hi")
        print("bye")
print()

# Question 5
for i in range(6):
    print("hello")
    break
    if i <= 3:
        for j in range(3):
            print("hi")
        print("bye")
print()

# Question 6
for i in range(6):
    print("hello")
    if i <= 3:
        for j in range(3):
            print("hi")
            break
        print("bye")
print()

# Question 7
for i in range(6):
    print("hello")
    if 0 <= 3:
        for i in range(3):
            print("hi")
        break
    print("bye")
print()
    










