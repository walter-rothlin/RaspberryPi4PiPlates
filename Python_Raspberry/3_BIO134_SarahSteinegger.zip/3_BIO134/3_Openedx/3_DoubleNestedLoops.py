# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 20:04:51 2019

@author: sara
"""

# Sara Steinegger
# 11.07.2019

# Double nested loops

# Question 1
counter = 0
for i in range(5):
    for j in range(3):
        for k in range(2):
            print("hello")
            counter +=1
print(counter)
print()

# Question 2
for i in range(5):
    for j in range(3):
        for k in range(2):
            print(i, j, k)
print()

# Question 3
for i in range(4):
    for j in range(4):
        for k in range(4):
            if i==j and j==k:
                print("hello")
print()

# Question 4
for i in range(4):
    for j in range(4):
        for k in range(4):
            if i==k:
                print("hello")
print()

# Question 5
for i in range(4):
    for j in range(4):
        for k in range(4):
            if j==k:
                print("hello")
    print(k)
print()

# Question 6
for i in range(4):
    for j in range(4):
        for k in range(4):
            if j==k:
                print("hello")
    print(i)
print()

# Question 7
for i in range(4):
    for j in range(i+1, 4):
        for k in range(4):
            if i==j:
                print("hello")
print()
                



                