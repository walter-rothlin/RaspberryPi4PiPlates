# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 20:25:04 2019

@author: sara
"""

# Sara Steinegger
#11.07.2019

# Counting Codons
bases = ['A','T','C','G']
for b1 in bases:
    for b2 in bases:
        for b3 in bases:
            print(b1+b2+b3)

# Counting Codons
# Modify the program so as to number the codons.
bases = ['A','T','C','G']
count = 0
for b1 in bases:
    for b2 in bases:
        for b3 in bases:
            count += 1
            print(count, b1+b2+b3)

# A subset of codons
# Modify the predicting program so that it outputs codons which
# 1. Have the same first and second bases, or the same second and third bases
# AND
# 2. Do not have three of the same bases!
bases = ['A','T','C','G']
count = 0
for b1 in bases:
    for b2 in bases:
        for b3 in bases:
            if (b1==b2 or b2==b3) and b1!=b3:
                    count += 1
                    print(count, b1+b2+b3)
