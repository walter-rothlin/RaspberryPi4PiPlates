# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 11:26:31 2019

@author: sara
"""

# Sara Steinegger
# 11.07.2019

# Questions: for and if
# Question 1
for i in range(6):
    if 3<i<=5:
        print("Yes")
# The program prints two times Yes

# Question 1
for i in range(6):
    if 3<i<=5:
        print("Yes")
    else:
        print("No")
# The program prints four times No
# and two times Yes
        
# Question 3
for i in range(6):
    if 3<i<=5:
        print("Yes")
    elif i==2:
        print("No")
# The program prints one time No
# and two times Yes

# Question 4
for i in range(6):
    if 3<i<=5:
        print("yes")
    elif i<2:
        print("No")
# The programn prints two times No
# and two times Yes

# Question 5
for i in range(6):
    if 3<i<=5:
        print("Yes")
    elif 2<=i<=4:
        print("No")
# The program prints two times Yes
# and two#  time No
        