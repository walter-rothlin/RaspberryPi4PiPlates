# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 07:56:05 2019

@author: sara
"""

# Sara Steinegger
# 12.07.2019

# Turing's card problem
# 130
import numpy.random as rd
at_least_130 = 0

for i in range(10000):
    correct = 0
    for j in range(400):
        r = rd.randint(1, 5)
        if r==1:
            correct += 1
    if correct >= 130:
        at_least_130 +=1
print(at_least_130)



# 117
import numpy.random as rd
at_least_117 = 0

for i in range(10000):
    correct = 0
    for j in range(400):
        r = rd.randint(1, 5)
        if r==1:
            correct += 1
    if correct >= 117:
        at_least_117 +=1
print(at_least_117)

